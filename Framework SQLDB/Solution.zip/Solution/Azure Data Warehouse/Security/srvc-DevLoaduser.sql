﻿--CREATE USER [srvc-DevLoaduser] FOR LOGIN [srvc-DevLoaduser]
--   WITH DEFAULT_SCHEMA = [brtl];

