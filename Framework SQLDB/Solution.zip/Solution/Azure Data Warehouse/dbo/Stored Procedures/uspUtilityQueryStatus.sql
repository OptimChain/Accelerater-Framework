﻿-----------------------------------------------------------------------------------------
--
--  File:  uspUtlityQueryStatus.sql
--
--  Purpose:  Determine the status of current queries.
--
--  Modification History:
--
--    Date		Author							Comment
--  ----------	------------------------------	-----------------------------------------
--  10/18/2017	Ken Mears						Created.
--	12/7/2017	Alan Campbell					Standardized for the Framework.
--
--
-- Developed by Neudesic, LLC.
-----------------------------------------------------------------------------------------

--DROP PROCEDURE [dbo].[uspUtilityQueryStatus]
CREATE PROCEDURE [dbo].[uspUtilityQueryStatus]
AS
-- Monitor Connections
SELECT *
FROM sys.dm_pdw_exec_sessions
WHERE [status] <> 'Closed'
AND session_id <> session_id();

-- Monitor Failed Query Execution
SELECT  *
FROM    sys.dm_pdw_exec_requests r
WHERE [status] = 'Failed'
AND session_id <> session_id()
ORDER BY start_time DESC;

SELECT *
FROM sys.dm_pdw_exec_sessions
WHERE session_id = 'SID19972'

--KILL 'SID5794'

-- Monitor Query Execution
SELECT  *
FROM    sys.dm_pdw_exec_requests r
WHERE [status] NOT IN ('Completed', 'Cancelled', 'Failed')
AND session_id <> session_id();

-- Monitor query plan for given query
SELECT * FROM sys.dm_pdw_request_steps
WHERE request_id IN ('QID472649')
ORDER BY step_index;

-- Find the information about all the workers completing a Data Movement Step.
SELECT * FROM sys.dm_pdw_dms_workers
WHERE request_id = 'QID472649' AND step_index = 21;

-- Find the distribution run times for a SQL step.
SELECT * FROM sys.dm_pdw_sql_requests
WHERE request_id = 'QID472649' AND step_index = 21
ORDER BY end_time DESC;

-- Find top 10 queries longest running queries
SELECT TOP 10 * 
FROM sys.dm_pdw_exec_requests 
ORDER BY total_elapsed_time DESC;

-- Monitor Query Waits
SELECT waits.session_id,
      waits.request_id,  
      requests.command,
      requests.status,
      requests.start_time,  
      waits.type,
      waits.state,
      waits.object_type,
      waits.object_name
FROM   sys.dm_pdw_waits waits
   JOIN  sys.dm_pdw_exec_requests requests
   ON waits.request_id=requests.request_id
WHERE waits.request_id IN ('QID472649')
ORDER BY waits.object_name, waits.object_type, waits.state;
GO