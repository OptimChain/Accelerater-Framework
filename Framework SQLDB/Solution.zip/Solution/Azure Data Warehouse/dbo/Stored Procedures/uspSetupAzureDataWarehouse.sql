﻿-----------------------------------------------------------------------------------------
--
--  File:  uspSetupAzureDataWarehouse.sql
--
--  Purpose:  Setup Azure Data Warehouse as needed.
--
--  Modification History:
--
--    Date		Author							Comment
--  ----------	------------------------------	-----------------------------------------
--  10/18/2017	Ken Mears						Created.
--	12/7/2017	Alan Campbell					Standardized for the Framework.
--  08/08/2018	Mike Sherrill					Modified for Framework on spg (to use BIFrameworkWebApp)
--
-- Developed by Neudesic, LLC.
-----------------------------------------------------------------------------------------

--DROP PROCEDURE [dbo].[uspSetupAzureDataWarehouse]
CREATE PROCEDURE [dbo].[uspSetupAzureDataWarehouse]
AS
	-- A: Create a master key.
	-- Only necessary if one does not already exist.
	-- Required to encrypt the credential secret in the next step.

	CREATE MASTER KEY;

	-- B: Create a database scoped credential
	-- IDENTITY: Provide any string, it is not used for authentication to Azure storage.
	-- SECRET: Provide your Azure storage account key.

	EXEC ('CREATE DATABASE SCOPED CREDENTIAL ADLCredential WITH IDENTITY = ''f8abbd7b-49d3-4025-bd00-90f2adc4fb92@https://login.microsoftonline.com/4bc7b452-73c9-4301-ace5-fff7e1d3f97f/oauth2/token'', SECRET = ''91lcKmqqTENNqSEFfA3XVf2tKsIp3pNfre5TmKJBAnQ=''')

	--Application ID (Service Principal ID/Client ID): f8abbd7b-49d3-4025-bd00-90f2adc4fb92
	--Secret: 91lcKmqqTENNqSEFfA3XVf2tKsIp3pNfre5TmKJBAnQ=
	--Tenant (Directory) ID: 0dec83f0-8d0a-4036-bdaa-08866d76cf19 (not used)
	--OAuth 2.0 Endpoint: https://login.microsoftonline.com/4bc7b452-73c9-4301-ace5-fff7e1d3f97f/oauth2/token

	CREATE EXTERNAL DATA SOURCE AzureDataLakeStore
	WITH (
			TYPE = HADOOP,
			LOCATION = 'adl://neuframework.azuredatalakestore.net',
			CREDENTIAL = ADLCredential
		 );

	CREATE EXTERNAL FILE FORMAT [ORCFormat] 
	WITH (  
		FORMAT_TYPE = ORC,  
		DATA_COMPRESSION = 'org.apache.hadoop.io.compress.DefaultCodec'  
	);

	CREATE EXTERNAL FILE FORMAT [CSVFormat]
	WITH (
	  FORMAT_TYPE = DELIMITEDTEXT,
	  FORMAT_OPTIONS (
					  FIELD_TERMINATOR = ',',
					  STRING_DELIMITER = N'"'
					  ),
	  DATA_COMPRESSION = N'org.apache.hadoop.io.compress.GzipCodec'
	);

	CREATE EXTERNAL FILE FORMAT [CSVFormatHeader] 
	WITH (
		FORMAT_TYPE = DELIMITEDTEXT,
		FORMAT_OPTIONS (
						FIELD_TERMINATOR = N',',
						STRING_DELIMITER = N'"',
						FIRST_ROW = 2,  -- Only valid in Azure SQL DW
						USE_TYPE_DEFAULT = False
						),
		DATA_COMPRESSION = N'org.apache.hadoop.io.compress.GzipCodec'
	);

	CREATE EXTERNAL FILE FORMAT [TABFormat]
	WITH (
		FORMAT_TYPE = DELIMITEDTEXT,
		FORMAT_OPTIONS (
						FIELD_TERMINATOR = N'\t',
						FIRST_ROW = 2,
						USE_TYPE_DEFAULT = False
						),
		DATA_COMPRESSION = N'org.apache.hadoop.io.compress.GzipCodec'
	);
	
	CREATE EXTERNAL FILE FORMAT [TABFormatHeader]
	WITH (
		FORMAT_TYPE = DELIMITEDTEXT,
		FORMAT_OPTIONS (
						FIELD_TERMINATOR = N'\t',
						FIRST_ROW = 2,
						USE_TYPE_DEFAULT = False
						),
		DATA_COMPRESSION = N'org.apache.hadoop.io.compress.GzipCodec'
	);

	EXEC dbo.uspCreateExternalTables 'Initial', ''
GO
