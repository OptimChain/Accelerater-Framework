﻿CREATE PROC [dbo].[uspDimDate] @StartDate [date],@EndDate [date] AS
BEGIN

SET NOCOUNT ON

DECLARE @aDate	    date

SET @aDate = @StartDate;

	WHILE @aDate <= @EndDate
	BEGIN

	--IF NOT EXISTS (SELECT * FROM DimDate WHERE DateKey = CONVERT(datetime, LTRIM(STR(DATEPART(m,@aDate))) + '/' + LTRIM(STR(DATEPART(d,@aDate))) + '/' + LTRIM(STR(DATEPART(yyyy,@aDate))))
	
	INSERT INTO [brtl].DimDate
		(DateKey,
		 DayNumberOfWeek,
		 DayNumberOfMonth,
		 DayNumberOfYear,
		 WeekNumberOfYear,
		 CalendarMonth,
		 CalendarQuarter,
		 CalendarSemester,
		 CalendarYear,
		 FiscalMonth,
		 FiscalQuarter,
		 FiscalSemester,
		 FiscalYear,
		 IsHoliday)
	SELECT 
		   @aDate AS DateKey,
		   CAST(CASE DATEPART(dw, @aDate)
			 WHEN 1 THEN 7
			 WHEN 2 THEN 1
			 WHEN 3 THEN 2
			 WHEN 4 THEN 3
			 WHEN 5 THEN 4
			 WHEN 6 THEN 5
			 WHEN 7 THEN 6
			END as tinyint) AS DayNumberOfWeek,
		   CAST(DATEPART(d, @aDate) as tinyint) AS DayNumberOfMonth,
		   CAST(DATEPART(dy, @aDate) as smallint) AS DayNumberOfYear,
		   CAST(DATEPART(wk, @aDate) as tinyint) AS WeekNumberOfYear,
		   CAST(DATEPART(m, @aDate) as tinyint) AS CalendarMonth,
		   CAST(CASE DATEPART(m, @aDate)
			 WHEN 1 THEN 1
			 WHEN 2 THEN 1
			 WHEN 3 THEN 1
			 WHEN 4 THEN 2
			 WHEN 5 THEN 2
			 WHEN 6 THEN 2
			 WHEN 7 THEN 3
			 WHEN 8 THEN 3
			 WHEN 9 THEN 3
			 WHEN 10 THEN 4
			 WHEN 11 THEN 4
			 WHEN 12 THEN 4
		   END as tinyint) AS CalendarQuarter,
		   CAST(CASE DATEPART(m, @aDate)
			 WHEN 1 THEN 1
			 WHEN 2 THEN 1
			 WHEN 3 THEN 1
			 WHEN 4 THEN 1
			 WHEN 5 THEN 1
			 WHEN 6 THEN 1
			 WHEN 7 THEN 2
			 WHEN 8 THEN 2
			 WHEN 9 THEN 2
			 WHEN 10 THEN 2
			 WHEN 11 THEN 2
			 WHEN 12 THEN 2
		   END as tinyint) AS CalendarSemester,
		   DATEPART(yyyy, @aDate) AS CalendarYear,
		   CAST(CASE DATEPART(m, @aDate)
			 WHEN 1 THEN 8
			 WHEN 2 THEN 9
			 WHEN 3 THEN 10
			 WHEN 4 THEN 11
			 WHEN 5 THEN 12
			 WHEN 6 THEN 1
			 WHEN 7 THEN 2
			 WHEN 8 THEN 3
			 WHEN 9 THEN 4
			 WHEN 10 THEN 5
			 WHEN 11 THEN 6
			 WHEN 12 THEN 7
		   END as tinyint) AS FiscalMonth,
		   CAST(CASE DATEPART(m, @aDate)
			 WHEN 1 THEN 3
			 WHEN 2 THEN 3
			 WHEN 3 THEN 4
			 WHEN 4 THEN 4
			 WHEN 5 THEN 4
			 WHEN 6 THEN 1
			 WHEN 7 THEN 1
			 WHEN 8 THEN 1
			 WHEN 9 THEN 2
			 WHEN 10 THEN 2
			 WHEN 11 THEN 2
			 WHEN 12 THEN 3
		   END as tinyint) AS FiscalQuarter,
		   CAST(CASE DATEPART(m, @aDate)
			 WHEN 1 THEN 2
			 WHEN 2 THEN 2
			 WHEN 3 THEN 2
			 WHEN 4 THEN 2
			 WHEN 5 THEN 2
			 WHEN 6 THEN 1
			 WHEN 7 THEN 1
			 WHEN 8 THEN 1
			 WHEN 9 THEN 1
			 WHEN 10 THEN 1
			 WHEN 11 THEN 1
			 WHEN 12 THEN 2
		   END as tinyint) AS FiscalSemester,
		   CASE DATEPART(m, @aDate)
			 WHEN 1 THEN CONVERT(integer, LTRIM(DATEPART(yyyy, @aDate)))
			 WHEN 2 THEN CONVERT(integer, LTRIM(DATEPART(yyyy, @aDate)))
			 WHEN 3 THEN CONVERT(integer, LTRIM(DATEPART(yyyy, @aDate)))
			 WHEN 4 THEN CONVERT(integer, LTRIM(DATEPART(yyyy, @aDate)))
			 WHEN 5 THEN CONVERT(integer, LTRIM(DATEPART(yyyy, @aDate)))
			 WHEN 6 THEN CONVERT(integer, LTRIM(DATEPART(yyyy, @aDate))) + 1
			 WHEN 7 THEN CONVERT(integer, LTRIM(DATEPART(yyyy, @aDate))) + 1
			 WHEN 8 THEN CONVERT(integer, LTRIM(DATEPART(yyyy, @aDate))) + 1
			 WHEN 9 THEN CONVERT(integer, LTRIM(DATEPART(yyyy, @aDate))) + 1
			 WHEN 10 THEN CONVERT(integer, LTRIM(DATEPART(yyyy, @aDate))) + 1
			 WHEN 11 THEN CONVERT(integer, LTRIM(DATEPART(yyyy, @aDate))) + 1
			 WHEN 12 THEN CONVERT(integer, LTRIM(DATEPART(yyyy, @aDate))) + 1
		   END AS FiscalYear,
		   CAST(0 as bit) as IsHoliday
  
	   SET @aDate = DATEADD(day, 1, @aDate)       

	END 

	
	--UPDATE DimDate
	--  SET IsHoliday = 1
	--WHERE DateKey IN
	--	(
	--		 '1/1/2015'
	--		,'5/25/2015'
	--		,'7/3/2015'
	--		,'9/7/2015'
	--		,'11/26/2015'
	--		,'12/25/2015'
	--		,'1/1/2016'
	--		,'5/30/2016'
	--		,'7/4/2016'
	--		,'9/5/2016'
	--		,'11/24/2016'
	--		,'12/26/2016'
	--		,'1/2/2017'
	--		,'5/29/2017'
	--		,'7/4/2017'
	--		,'9/4/2017'
	--		,'11/23/2017'
	--		,'12/25/2017'
	--		,'1/1/2018'
	--		,'5/28/2018'
	--		,'7/4/2018'
	--		,'9/3/2018'
	--		,'11/22/2018'
	--		,'12/25/2018'
	--		,'1/1/2019'
	--	)   

END