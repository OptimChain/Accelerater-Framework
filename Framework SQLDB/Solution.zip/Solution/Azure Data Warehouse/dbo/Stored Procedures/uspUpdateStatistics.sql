﻿-----------------------------------------------------------------------------------------
--
--  File:  uspUpdateStatistics.sql
--
--  Purpose:  Update Statistics on a Table in Azure Data Warehouse.
--
--  Modification History:
--
--    Date		Author							Comment
--  ----------	------------------------------	-----------------------------------------
--  10/18/2017	Ken Mears						Created.
--	12/7/2017	Alan Campbell					Standardized for the Framework.
--
--
-- Developed by Neudesic, LLC.
-----------------------------------------------------------------------------------------

--DROP PROCEDURE [dbo].[uspUpdateStatistics]
CREATE PROCEDURE [dbo].[uspUpdateStatistics]
(   @update_type    tinyint -- 1 default 2 Fullscan 3 Sample
,   @sample_pct     tinyint
,	@tableName		varchar(50)
)
AS
IF @update_type NOT IN (1,2,3,4)
BEGIN;
    THROW 151000,'Invalid value for @update_type parameter. Valid range 1 (default), 2 (fullscan), 3 (sample) or 4 (resample).',1;
END;

IF @sample_pct IS NULL
BEGIN;
    SET @sample_pct = 20;
END;

IF OBJECT_ID('tempdb..#stats_ddl') IS NOT NULL
BEGIN
	DROP TABLE #stats_ddl
END

IF @tableName IS NULL
BEGIN
	CREATE TABLE #stats_ddl
	WITH
	(
		DISTRIBUTION = HASH([seq_nmbr])
	)
	AS
	WITH T
	AS
	(
	SELECT
			sm.[name]                                                                AS [schema_name]
	,        tb.[name]                                                                AS [table_name]
	,        st.[name]                                                                AS [stats_name]
	,        st.[has_filter]                                                            AS [stats_is_filtered]
	,       ROW_NUMBER()
			OVER(ORDER BY (SELECT NULL))                                            AS [seq_nmbr]
	,                                 QUOTENAME(sm.[name])+'.'+QUOTENAME(tb.[name])  AS [two_part_name]
	,        QUOTENAME(DB_NAME())+'.'+QUOTENAME(sm.[name])+'.'+QUOTENAME(tb.[name])  AS [three_part_name]
	FROM    sys.objects            AS ob
	JOIN    sys.stats            AS st    ON    ob.[object_id]        = st.[object_id]
	JOIN    sys.stats_columns    AS sc    ON    st.[stats_id]        = sc.[stats_id]
										AND st.[object_id]        = sc.[object_id]
	JOIN    sys.columns            AS co    ON    sc.[column_id]        = co.[column_id]
										AND    sc.[object_id]        = co.[object_id]
	JOIN    sys.tables            AS tb    ON    co.[object_id]        = tb.[object_id]
	JOIN    sys.schemas            AS sm    ON    tb.[schema_id]        = sm.[schema_id]
	WHERE    1=1
	AND        st.[user_created]   = 1
	GROUP BY
			sm.[name]
	,        tb.[name]
	,        st.[name]
	,        st.[filter_definition]
	,        st.[has_filter]
	)
	SELECT
		CASE @update_type
		WHEN 1
		THEN 'UPDATE STATISTICS '+[two_part_name]+'('+[stats_name]+');'
		WHEN 2
		THEN 'UPDATE STATISTICS '+[two_part_name]+'('+[stats_name]+') WITH FULLSCAN;'
		WHEN 3
		THEN 'UPDATE STATISTICS '+[two_part_name]+'('+[stats_name]+') WITH SAMPLE '+CAST(@sample_pct AS VARCHAR(20))+' PERCENT;'
		WHEN 4
		THEN 'UPDATE STATISTICS '+[two_part_name]+'('+[stats_name]+') WITH RESAMPLE;'
		END AS [update_stats_ddl]
	,   [seq_nmbr]
	FROM    T
	;
END
ELSE
BEGIN
	CREATE TABLE #stats_ddl
	WITH
	(
		DISTRIBUTION = HASH([seq_nmbr])
	)
	AS
	WITH T
	AS
	(
	SELECT
			sm.[name]                                                                AS [schema_name]
	,        tb.[name]                                                                AS [table_name]
	,        st.[name]                                                                AS [stats_name]
	,        st.[has_filter]                                                            AS [stats_is_filtered]
	,       ROW_NUMBER()
			OVER(ORDER BY (SELECT NULL))                                            AS [seq_nmbr]
	,                                 QUOTENAME(sm.[name])+'.'+QUOTENAME(tb.[name])  AS [two_part_name]
	,        QUOTENAME(DB_NAME())+'.'+QUOTENAME(sm.[name])+'.'+QUOTENAME(tb.[name])  AS [three_part_name]
	FROM    sys.objects            AS ob
	JOIN    sys.stats            AS st    ON    ob.[object_id]        = st.[object_id]
	JOIN    sys.stats_columns    AS sc    ON    st.[stats_id]        = sc.[stats_id]
										AND st.[object_id]        = sc.[object_id]
	JOIN    sys.columns            AS co    ON    sc.[column_id]        = co.[column_id]
										AND    sc.[object_id]        = co.[object_id]
	JOIN    sys.tables            AS tb    ON    co.[object_id]        = tb.[object_id]
	JOIN    sys.schemas            AS sm    ON    tb.[schema_id]        = sm.[schema_id]
	WHERE   1=1
	AND     st.[user_created]   = 1
	AND		tb.[name] = @tableName
	GROUP BY
			sm.[name]
	,        tb.[name]
	,        st.[name]
	,        st.[filter_definition]
	,        st.[has_filter]
	)
	SELECT
		CASE @update_type
		WHEN 1
		THEN 'UPDATE STATISTICS '+[two_part_name]+'('+[stats_name]+');'
		WHEN 2
		THEN 'UPDATE STATISTICS '+[two_part_name]+'('+[stats_name]+') WITH FULLSCAN;'
		WHEN 3
		THEN 'UPDATE STATISTICS '+[two_part_name]+'('+[stats_name]+') WITH SAMPLE '+CAST(@sample_pct AS VARCHAR(20))+' PERCENT;'
		WHEN 4
		THEN 'UPDATE STATISTICS '+[two_part_name]+'('+[stats_name]+') WITH RESAMPLE;'
		END AS [update_stats_ddl]
	,   [seq_nmbr]
	FROM    T
	;
END

DECLARE @i INT              = 1
,       @t INT              = (SELECT COUNT(*) FROM #stats_ddl)
,       @s NVARCHAR(4000)   = N''
;

WHILE @i <= @t
BEGIN
	SET @s=(SELECT update_stats_ddl FROM #stats_ddl WHERE seq_nmbr = @i);

	PRINT @s
	EXEC sp_executesql @s
	SET @i+=1;
END

DROP TABLE #stats_ddl;