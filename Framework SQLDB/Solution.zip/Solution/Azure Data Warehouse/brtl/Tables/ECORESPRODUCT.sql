﻿CREATE TABLE [brtl].[ECORESPRODUCT] (
    [PRODUCTMASTER]                         BIGINT          NULL,
    [RETAITOTALWEIGHT]                      BIGINT          NULL,
    [VARIANTCONFIGURATIONTECHNOLOGY]        BIGINT          NULL,
    [RETAILCOLORGROUPID]                    NVARCHAR (2048) NULL,
    [RETAILSIZEGROUPID]                     NVARCHAR (2048) NULL,
    [RETAILSTYLEGROUPID]                    NVARCHAR (2048) NULL,
    [ISPRODUCTVARIANTUNITCONVERSIONENABLED] BIGINT          NULL,
    [INSTANCERELATIONTYPE]                  BIGINT          NULL,
    [DISPLAYPRODUCTNUMBER]                  NVARCHAR (2048) NULL,
    [SEARCHNAME]                            NVARCHAR (2048) NULL,
    [PRODUCTTYPE]                           BIGINT          NULL,
    [PDSCWPRODUCT]                          BIGINT          NULL,
    [MODIFIEDBY]                            NVARCHAR (2048) NULL,
    [RECVERSION]                            BIGINT          NULL,
    [RELATIONTYPE]                          BIGINT          NULL,
    [PARTITION]                             BIGINT          NULL,
    [RECID]                                 BIGINT          NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

