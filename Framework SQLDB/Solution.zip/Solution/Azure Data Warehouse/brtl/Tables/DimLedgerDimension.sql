﻿CREATE TABLE [brtl].[DimLedgerDimension] (
    [LedgerDimension]    BIGINT NULL,
    [_1_BusinessChannel] BIGINT NULL,
    [_2_Store]           BIGINT NULL,
    [_3_CostCenter]      BIGINT NULL,
    [_4_ItemGroup]       BIGINT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

