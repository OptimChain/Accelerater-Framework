﻿CREATE TABLE [brtl].[DimLocation] (
    [WarehouseCode] NVARCHAR (2048) NULL,
    [Warehouse]     NVARCHAR (2048) NULL,
    [SiteCode]      NVARCHAR (2048) NULL,
    [Site]          NVARCHAR (2048) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

