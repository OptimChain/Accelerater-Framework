﻿CREATE TABLE [brtl].[DimProductCategory] (
    [CategoryId]   BIGINT          NULL,
    [ItemId]       BIGINT          NULL,
    [ProductKey]   BIGINT          NULL,
    [CategoryKey]  BIGINT          NULL,
    [CategoryType] NVARCHAR (2048) NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

