﻿CREATE TABLE [brtl].[Market_Basket_Analysis] (
    [antecedent] NVARCHAR (2048) NOT NULL,
    [consequent] NVARCHAR (2048) NOT NULL,
    [confidence] FLOAT (53)      NOT NULL,
    [lift]       FLOAT (53)      NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

