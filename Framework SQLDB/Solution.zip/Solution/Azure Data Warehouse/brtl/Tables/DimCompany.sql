﻿CREATE TABLE [brtl].[DimCompany] (
    [CompanyKey]       BIGINT          NULL,
    [CompanyCode]      NVARCHAR (2048) NULL,
    [CompanyName]      NVARCHAR (2048) NULL,
    [Process_DateTime] DATETIME2 (7)   NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

