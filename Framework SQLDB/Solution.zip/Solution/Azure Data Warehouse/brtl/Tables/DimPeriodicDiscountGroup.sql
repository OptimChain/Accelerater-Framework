﻿CREATE TABLE [brtl].[DimPeriodicDiscountGroup] (
    [PeriodicDiscountTypeCode]  INT             NULL,
    [PeriodicDiscountType]      NVARCHAR (2048) NULL,
    [RecordId]                  BIGINT          NULL,
    [CompanyCode]               NVARCHAR (2048) NULL,
    [PeriodicDiscountGroupCode] NVARCHAR (2048) NULL,
    [PeriodicDiscountGroup]     NVARCHAR (2048) NULL,
    [PeriodicDiscountStatus]    NVARCHAR (2048) NULL,
    [StartDate]                 NVARCHAR (2048) NOT NULL,
    [EndDate]                   NVARCHAR (2048) NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

