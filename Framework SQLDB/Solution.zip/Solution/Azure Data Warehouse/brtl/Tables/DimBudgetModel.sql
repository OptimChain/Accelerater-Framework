﻿CREATE TABLE [brtl].[DimBudgetModel] (
    [BudgetModelKey]     BIGINT          NULL,
    [BudgetModel]        NVARCHAR (2048) NULL,
    [BudgetSub-model]    NVARCHAR (2048) NULL,
    [BudgetModelType]    NVARCHAR (2048) NULL,
    [BudgetModelName]    NVARCHAR (2048) NULL,
    [BudgetModelBlocked] NVARCHAR (2048) NULL,
    [CompanyCode]        NVARCHAR (2048) NULL,
    [Process_DateTime]   DATETIME2 (7)   NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

