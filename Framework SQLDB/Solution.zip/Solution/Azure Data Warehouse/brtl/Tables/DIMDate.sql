﻿CREATE TABLE [brtl].[DimDate] (
    [DateKey]          DATE     NOT NULL,
    [IsHoliday]        BIT      NOT NULL,
    [DayNumberOfWeek]  TINYINT  NOT NULL,
    [DayNumberOfMonth] TINYINT  NOT NULL,
    [DayNumberOfYear]  SMALLINT NOT NULL,
    [WeekNumberOfYear] TINYINT  NOT NULL,
    [CalendarQuarter]  TINYINT  NOT NULL,
    [CalendarSemester] TINYINT  NOT NULL,
    [CalendarMonth]    TINYINT  NOT NULL,
    [CalendarYear]     INT      NOT NULL,
    [FiscalQuarter]    TINYINT  NOT NULL,
    [FiscalSemester]   TINYINT  NOT NULL,
    [FiscalMonth]      TINYINT  NOT NULL,
    [FiscalYear]       INT      NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);



