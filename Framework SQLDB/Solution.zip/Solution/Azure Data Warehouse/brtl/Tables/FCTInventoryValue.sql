﻿CREATE TABLE [brtl].[FCTInventoryValue] (
    [RecordType]            INT             NOT NULL,
    [RecordId]              BIGINT          NULL,
    [CompanyCode]           NVARCHAR (2048) NULL,
    [ItemCode]              NVARCHAR (2048) NULL,
    [InventoryDimensionId]  NVARCHAR (2048) NULL,
    [TransactionDate]       NVARCHAR (2048) NULL,
    [IssueStatus]           NVARCHAR (2048) NULL,
    [ReceiptStatus]         NVARCHAR (2048) NULL,
    [TransactionType]       NVARCHAR (2048) NULL,
    [InventoryReference]    NVARCHAR (2048) NULL,
    [UoM]                   NVARCHAR (2048) NULL,
    [Quantity]              FLOAT (53)      NULL,
    [CurrencyCode]          NVARCHAR (2048) NULL,
    [CostAmount]            FLOAT (53)      NULL,
    [PostingType]           NVARCHAR (2048) NOT NULL,
    [VoucherNumber]         NVARCHAR (2048) NULL,
    [LedgerDimensionId]     BIGINT          NULL,
    [DefaultDimensionId]    BIGINT          NULL,
    [CategoryId]            BIGINT          NULL,
    [TransferOrderRecordID] BIGINT          NULL,
    [Created_By]            NVARCHAR (2048) NOT NULL,
    [Modified_By]           NVARCHAR (2048) NOT NULL,
    [Last_Created]          NVARCHAR (2048) NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

