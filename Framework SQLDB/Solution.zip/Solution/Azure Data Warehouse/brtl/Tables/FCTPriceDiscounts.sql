﻿CREATE TABLE [brtl].[FCTPriceDiscounts] (
    [Record_ID]              BIGINT          NULL,
    [Company_Code]           NVARCHAR (2048) NULL,
    [Item_Code]              NVARCHAR (2048) NULL,
    [Inventory_Dimension_ID] NVARCHAR (2048) NULL,
    [Account_Code]           NVARCHAR (2048) NOT NULL,
    [Account_Relation]       NVARCHAR (2048) NULL,
    [Customer_Name]          NVARCHAR (2048) NULL,
    [From_Date]              NVARCHAR (2048) NULL,
    [To_Date]                NVARCHAR (2048) NULL,
    [Price]                  FLOAT (53)      NULL,
    [Currency_Code]          NVARCHAR (2048) NULL,
    [Relation_ID]            BIGINT          NULL,
    [Relation]               NVARCHAR (2048) NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

