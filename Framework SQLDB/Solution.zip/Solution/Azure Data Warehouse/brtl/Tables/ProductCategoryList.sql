﻿CREATE TABLE [brtl].[ProductCategoryList] (
    [CATEGORY]          BIGINT          NULL,
    [CATEGORYHIERARCHY] BIGINT          NULL,
    [MODIFIEDDATETIME]  NVARCHAR (2048) NULL,
    [PARTITION]         BIGINT          NULL,
    [PRODUCT]           BIGINT          NULL,
    [RECID]             BIGINT          NULL,
    [RECVERSION]        BIGINT          NULL,
    [dateLoaded]        DATETIME2 (7)   NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

