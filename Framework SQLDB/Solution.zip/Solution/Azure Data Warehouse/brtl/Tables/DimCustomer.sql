﻿CREATE TABLE [brtl].[DimCustomer] (
    [CustomerKey]             BIGINT          NULL,
    [CompanyCode]             NVARCHAR (2048) NULL,
    [CustomerCode]            NVARCHAR (2048) NULL,
    [CustomerName]            NVARCHAR (2048) NULL,
    [CustomerGroupCode]       NVARCHAR (2048) NULL,
    [CustomerGroup]           NVARCHAR (2048) NULL,
    [ABCCode]                 NVARCHAR (2048) NULL,
    [CreditLimit]             FLOAT (53)      NULL,
    [CreditRating]            NVARCHAR (2048) NULL,
    [PaymentTermsCode]        NVARCHAR (2048) NULL,
    [PaymenyTerms]            NVARCHAR (2048) NULL,
    [ModeofDeliveryCode]      NVARCHAR (2048) NULL,
    [ModeofDelivery]          NVARCHAR (2048) NULL,
    [PriceGroupCode]          NVARCHAR (2048) NULL,
    [PriceGroup]              NVARCHAR (2048) NULL,
    [CustomerCity]            NVARCHAR (2048) NULL,
    [CustomerState]           NVARCHAR (2048) NULL,
    [CustomerZipCode]         NVARCHAR (2048) NULL,
    [CustomerCountryorRegion] NVARCHAR (2048) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

