﻿CREATE TABLE [brtl].[FCTInventoryTransPosting] (
    [DATAAREAID]             NVARCHAR (2048) NULL,
    [DEFAULTDIMENSION]       BIGINT          NULL,
    [INVENTTRANSORIGIN]      BIGINT          NULL,
    [INVENTTRANSPOSTINGTYPE] BIGINT          NULL,
    [ISPOSTED]               BIGINT          NULL,
    [ITEMID]                 NVARCHAR (2048) NULL,
    [LEDGERDIMENSION]        BIGINT          NULL,
    [OFFSETLEDGERDIMENSION]  BIGINT          NULL,
    [PARTITION]              BIGINT          NULL,
    [POSTINGTYPE]            BIGINT          NULL,
    [POSTINGTYPEOFFSET]      BIGINT          NULL,
    [PROJID]                 NVARCHAR (2048) NULL,
    [RECID]                  BIGINT          NULL,
    [RECVERSION]             BIGINT          NULL,
    [TRANSBEGINTIME]         NVARCHAR (2048) NULL,
    [TRANSBEGINTIMETZID]     BIGINT          NULL,
    [TRANSDATE]              NVARCHAR (2048) NULL,
    [VOUCHER]                NVARCHAR (2048) NULL,
    [Created_By]             NVARCHAR (2048) NOT NULL,
    [Modified_By]            NVARCHAR (2048) NOT NULL,
    [Last_Created]           NVARCHAR (2048) NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

