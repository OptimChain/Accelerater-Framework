﻿CREATE TABLE [brtl].[DimCurrency] (
    [CurrencyKey]      BIGINT          NULL,
    [CurrencyCode]     NVARCHAR (2048) NULL,
    [Currency]         NVARCHAR (2048) NULL,
    [Process_DateTime] DATETIME2 (7)   NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

