﻿CREATE TABLE [brtl].[FCTCategoryBudget] (
    [Level3]        NVARCHAR (2048) NULL,
    [COGS]          NVARCHAR (2048) NULL,
    [Date]          NVARCHAR (2048) NULL,
    [GP_Amt]        NVARCHAR (2048) NULL,
    [GP_Pct]        NVARCHAR (2048) NULL,
    [Sales]         NVARCHAR (2048) NULL,
    [ProcessedDate] DATETIME2 (7)   NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

