﻿CREATE TABLE [brtl].[DimTime] (
    [Hour]          NVARCHAR (2048) NULL,
    [HourOrder]     BIGINT          NULL,
    [Interval]      NVARCHAR (2048) NULL,
    [IntervalOrder] BIGINT          NULL,
    [TimeKey]       BIGINT          NULL,
    [dateLoaded]    DATETIME2 (7)   NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

