﻿CREATE TABLE [brtl].[FCTInventoryBudgetSales] (
    [Apr]        FLOAT (53)      NULL,
    [Aug]        FLOAT (53)      NULL,
    [Feb]        FLOAT (53)      NULL,
    [Jan]        FLOAT (53)      NULL,
    [Jul]        FLOAT (53)      NULL,
    [Jun]        FLOAT (53)      NULL,
    [Level2]     NVARCHAR (2048) NULL,
    [Level3]     NVARCHAR (2048) NULL,
    [Mar]        FLOAT (53)      NULL,
    [May]        FLOAT (53)      NULL,
    [Nov]        FLOAT (53)      NULL,
    [Oct]        FLOAT (53)      NULL,
    [Sep]        FLOAT (53)      NULL,
    [dateLoaded] DATETIME2 (7)   NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

