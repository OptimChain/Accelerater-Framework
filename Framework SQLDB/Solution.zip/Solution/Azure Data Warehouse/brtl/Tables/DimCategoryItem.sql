﻿CREATE TABLE [brtl].[DimCategoryItem] (
    [CategoryId]           BIGINT          NULL,
    [ProductNumber]        NVARCHAR (2048) NULL,
    [ProductKey]           BIGINT          NULL,
    [CategoryHierarchyKey] BIGINT          NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

