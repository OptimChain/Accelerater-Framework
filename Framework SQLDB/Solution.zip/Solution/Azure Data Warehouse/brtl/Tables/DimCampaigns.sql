﻿CREATE TABLE [brtl].[DimCampaigns] (
    [CampaignKey]          BIGINT          NULL,
    [CampaignHierarchyKey] BIGINT          NOT NULL,
    [CampaignID]           NVARCHAR (2048) NULL,
    [CampaignName]         NVARCHAR (2048) NULL,
    [CampaignDescription]  NVARCHAR (2048) NULL,
    [CampaignStart]        DATE            NULL,
    [CampaignEnd]          DATE            NULL,
    [CampaignType]         NVARCHAR (2048) NULL,
    [CampaignStatus]       NVARCHAR (2048) NOT NULL,
    [CampaignBlockNumber]  DECIMAL (18, 6) NULL,
    [CampaignEstCost]      DECIMAL (18, 6) NULL,
    [CampaignGM]           DECIMAL (18, 6) NULL,
    [CampaignEstSales]     DECIMAL (18, 6) NULL,
    [Process_DateTime]     DATETIME2 (7)   NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

