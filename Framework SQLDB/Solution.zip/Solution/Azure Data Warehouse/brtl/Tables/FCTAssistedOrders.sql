﻿CREATE TABLE [brtl].[FCTAssistedOrders] (
    [3rdPartyOrderNumber] NVARCHAR (2048) NULL,
    [StoreNumber]         NVARCHAR (2048) NULL,
    [Vendor]              NVARCHAR (2048) NULL,
    [Date]                NVARCHAR (2048) NULL,
    [ItemNumber]          NVARCHAR (2048) NULL,
    [Barcode]             NVARCHAR (2048) NULL,
    [ProductName]         NVARCHAR (2048) NULL,
    [Qty]                 NVARCHAR (2048) NULL,
    [Created_By]          NVARCHAR (2048) NOT NULL,
    [Modified_By]         NVARCHAR (2048) NOT NULL,
    [Last_Created]        NVARCHAR (2048) NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

