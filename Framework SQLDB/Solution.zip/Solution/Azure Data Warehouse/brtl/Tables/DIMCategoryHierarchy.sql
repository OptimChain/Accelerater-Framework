﻿CREATE TABLE [brtl].[DIMCategoryHierarchy] (
    [Level1Name] NVARCHAR (2048) NULL,
    [Level1]     BIGINT          NULL,
    [Level2Name] NVARCHAR (2048) NULL,
    [Level2]     BIGINT          NULL,
    [Level3Name] NVARCHAR (2048) NULL,
    [CAT3LEVEL]  BIGINT          NULL,
    [Level4Name] NVARCHAR (2048) NULL,
    [CAT4LEVEL]  BIGINT          NULL,
    [Level5Name] NVARCHAR (2048) NULL,
    [CAT5LEVEL]  BIGINT          NULL,
    [LevelRECID] BIGINT          NULL,
    [PRODUCT]    BIGINT          NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

