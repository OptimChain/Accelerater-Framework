﻿CREATE VIEW [brtl].[FactPriceDiscountsView]
AS select 
[$Table].[Record_ID] as [Record Id],

[$Table].[Company_Code] as [Company Code],
    [$Table].[Item_Code] as [Item Code],
    [$Table].[Inventory_Dimension_Id] as [Inventory Dimension Id],
    [$Table].[Account_Code] as [Account Code],
    [$Table].[Account_Relation] as [Account Relation],
    [$Table].[Customer_Name] as [Customer Name],
    [$Table].[From_Date] as [From Date],
    [$Table].[To_Date] as [To Date],
    [$Table].[Price] as [Price],
    [$Table].[Currency_Code] as [Currency Code],
    [$Table].[Relation_Id] as [Relation Id],
    [$Table].[Relation] as [Relation]
   -- [$Table].[ea_Process_DateTime] as [ea_Process_DateTime]
from [brtl].[FCTPriceDiscounts]  as [$Table];