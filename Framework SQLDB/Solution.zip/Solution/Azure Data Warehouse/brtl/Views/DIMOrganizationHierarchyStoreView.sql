﻿CREATE VIEW [brtl].[DIMOrganizationHierarchyStoreView]
AS select
	[Level1], 
	[Organization],
	[Level2],
	[DistrictName] as [District Name],
	[Level3], 
	[StoreName] as [Store Name],
	[StoreNumber] as [Store Code],
	[Active]
	from [brtl].[DIMOrganizationHierarchyStore];