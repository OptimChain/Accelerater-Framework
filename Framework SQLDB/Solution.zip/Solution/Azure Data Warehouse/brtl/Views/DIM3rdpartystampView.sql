﻿CREATE VIEW [brtl].[DIM3rdpartystampView] AS SELECT DISTINCT
	 TOPO
	,ECL_3PTYDEMANDFCST
FROM [brtl].[3rdpartystamp] WITH (NOLOCK);