﻿CREATE VIEW [brtl].[FCTInventoryTransferView]
AS SELECT  
*
FROM [brtl].[FCTInventoryTransfer] WITH (NOLOCK);