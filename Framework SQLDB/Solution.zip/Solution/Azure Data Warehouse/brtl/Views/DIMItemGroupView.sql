﻿CREATE VIEW [brtl].[DIMItemGroupView]
AS SELECT
*
FROM [brtl].[DimItemGroup] WITH (NOLOCK);