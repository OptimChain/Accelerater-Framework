﻿CREATE VIEW [brtl].[DIMCategoryHierarchyView]
AS select
--[$Table].[Category Hierarchy Key] as [Category Hierarchy Key],
    [$Table].[LevelRECID] as [Category Id],
    [$Table].[Level1] as [Level 1],
    [$Table].[Level2] as [Level 2],
    [$Table].[CAT3LEVEL] as [Level 3],
    [$Table].[CAT4LEVEL] as [Level 4],
    [$Table].[CAT5LEVEL] as [Level 5],
[$Table].[Level1Name] as [Level1 Name],
[$Table].[Level2Name] as [Level2 Name],
[$Table].[Level3Name] as [Level3 Name],
[$Table].[Level4Name] as [Level4 Name],
[$Table].[Level5Name] as [Level5 Name],
[$Table].[PRODUCT] as [Prouct]
    --[$Table].[ea_Process_DateTime] as [ea_Process_DateTime],
    --[$Table].[Category Manager] as [Category Manager]
from [brtl].[DimCategoryHierarchy] as [$Table];