﻿CREATE VIEW [brtl].[DIMPeriodicDiscountGroupView]
AS SELECT
-- [$Table].[Periodic Discount Group Key] as [Periodic Discount Group Key],
    [$Table].[PeriodicDiscountTypeCode] as [Periodic Discount Type Code],
    [$Table].[PeriodicDiscountType] as [Periodic Discount Type],
	[$Table].[RecordId] as [Record Id],
    [$Table].[CompanyCode] as [Company Code],
    [$Table].[PeriodicDiscountGroupCode] as [Periodic Discount Group Code],
    [$Table].[PeriodicDiscountGroup] as [Periodic Discount Group],
    [$Table].[PeriodicDiscountStatus] as [Periodic Discount Status],
    [$Table].[StartDate] as [Start Date],
    [$Table].[EndDate] as [End Date]
    --[$Table].[ea_Process_DateTime] as [ea_Process_DateTime]
 
FROM [brtl].[DimPeriodicDiscountGroup] as [$Table] WITH (NOLOCK);