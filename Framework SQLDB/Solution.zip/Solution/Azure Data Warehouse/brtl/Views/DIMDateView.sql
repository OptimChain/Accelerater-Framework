﻿CREATE VIEW [brtl].[DIMDateView]
AS SELECT  
*
FROM [brtl].[DIMDate] WITH (NOLOCK);