﻿CREATE VIEW [brtl].[FCTAssistedOrdersView]
AS SELECT  
*
FROM [brtl].[FCTAssistedOrders] WITH (NOLOCK);