﻿CREATE VIEW [brtl].[FCTInventoryBudgetSalesView]
AS SELECT  
*
FROM [brtl].[FCTInventoryBudgetSales] WITH (NOLOCK);