﻿CREATE VIEW [brtl].[DIMCampaignsView]
AS select [$Table].[CampaignKey] as [Campaign Key],
    [$Table].[CampaignHierarchyKey] as [Campaign Heirarchy Key],
    [$Table].[CampaignID] as [Campaign ID],
    [$Table].[CampaignName] as [Campaign Name],
    [$Table].[CampaignDescription] as [Campaign Description],
    [$Table].[CampaignStart] as [Campaign Start],
    [$Table].[CampaignEnd] as [Campaign End],
    [$Table].[CampaignType] as [Campaign Type],
    [$Table].[CampaignStatus] as [Campaign Status],
    [$Table].[CampaignBlockNumber] as [Campaign Block Number],
    [$Table].[CampaignEstCost] as [Campaign Est Cost],
    [$Table].[CampaignGM] as [Campaign GM],
    [$Table].[CampaignEstSales] as [Campaign Est Sales],
    [$Table].[Process_DateTime] as [Process_DateTime]
from [brtl].[DimCampaigns] as [$Table] WITH (NOLOCK);