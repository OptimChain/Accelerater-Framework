﻿CREATE VIEW [brtl].[FCTPlanOrderFirmLogView]
AS SELECT  
*
FROM [brtl].[PlanOrderFirmLog] WITH (NOLOCK);