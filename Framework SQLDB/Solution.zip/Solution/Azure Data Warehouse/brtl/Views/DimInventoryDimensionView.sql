﻿CREATE VIEW [brtl].[DimInventoryDimensionView]
AS SELECT distinct
[InventoryDimensionKey] as[Inventory Dimension Key]
      ,[CompanyCode] as      [Company Code]
      ,[InventoryDimensionId] as      [Inventory Dimension Id]
      ,[InventorySiteCode] as      [Inventory Site Code]
      ,[InventorySite] as      [Inventory Site]
      ,[WarehouseCode] as      [Warehouse Code]
      ,[Warehouse] as     [Warehouse]
      ,[SizeCode] as      [Size Code]
      ,[ColorCode] as      [Color Code]
      ,[StyleCode] as      [Style Code]
      ,[ConfigurationCode] as      [Configuration Code]
      ,[ItemBarCode] as      [ItemBar Code]
      ,[InventoryStatus] as      [Inventory Status]
      ,[InventoryLocation] as      [Inventory Location]


  FROM [brtl].[DimInventoryDimension];