﻿CREATE VIEW [brtl].[FCTInventoryJournalTransView]
AS SELECT  
	*
FROM [brtl].[FCTInventoryJournalTrans] WITH (NOLOCK);