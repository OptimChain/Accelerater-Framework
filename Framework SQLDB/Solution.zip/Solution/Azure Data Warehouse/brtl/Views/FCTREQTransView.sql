﻿CREATE VIEW [brtl].[FCTREQTransView]
AS SELECT  
*
FROM [brtl].[FCTREQTrans] WITH (NOLOCK);