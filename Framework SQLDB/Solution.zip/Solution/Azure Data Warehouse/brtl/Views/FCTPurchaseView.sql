﻿CREATE VIEW [brtl].[FCTPurchaseView]
AS SELECT  
*
FROM [brtl].[FCTPurchase] WITH (NOLOCK);