﻿CREATE VIEW [brtl].[FCTRetailCampaignDiscountView]
AS SELECT  
*
FROM [brtl].[FCTRetailCampaignDiscount] WITH (NOLOCK);