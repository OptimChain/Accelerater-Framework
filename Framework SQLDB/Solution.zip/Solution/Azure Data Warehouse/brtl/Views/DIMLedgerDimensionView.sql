﻿CREATE VIEW [brtl].[DIMLedgerDimensionView]
AS select 
--[$Table].[Ledger Dimension Key] as [Ledger Dimension Key],
    [$Table].[LedgerDimension] as [LedgerDimensionId],
    [$Table].[_1_BusinessChannel] as [_1_BusinessChannel Key],
    [$Table].[_2_Store] as [_2_Store Key],
    [$Table].[_3_CostCenter] as [_3_CostCenter Key],
   -- [$Table].[ea_Process_DateTime] as [ea_Process_DateTime],
    [$Table].[_4_ItemGroup] as [_4_ItemGroup Key]
from [brtl].[DimLedgerDimension] as [$Table] WITH (NOLOCK);