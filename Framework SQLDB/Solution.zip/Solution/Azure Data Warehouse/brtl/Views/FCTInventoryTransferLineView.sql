﻿CREATE VIEW [brtl].[FCTInventoryTransferLineView]
AS SELECT  
*
FROM [brtl].[FCTInventoryTransferLine] WITH (NOLOCK);