﻿CREATE VIEW [brtl].[DIMRetailTransactionView]
AS SELECT 
  [RecordId] as [Record Id]
      ,[CompanyCode] as   [Company Code]
      ,[StoreCode] as     [Store Code]
      ,[TerminalCode] as      [Terminal Code]
      ,[TransactionCode] as      [Transaction Code]
      ,[ReceiptNumber] as      [Receipt Number]
      ,[StatementNumber] as      [Statement Number]
      ,[StatementCode] as      [Statement Code]
      ,[SalesOrderNumber] as      [Sales Order Number]
      ,[TransactionType] as      [Transaction Type]
      ,[EntryStatus] as      [Entry Status]
      ,[Created_By] as      [Created_By]
      ,[Modified_By] as      [Modified_By]
      ,[Last_Created] as      [Last_Created]
      ,[Last_Modified] as      [Last_Modified]


FROM brtl.DimRetailTransaction  WITH (NOLOCK) WHERE [Last_Modified] >= '1900-01-01' AND [Last_Modified] < '9999-12-31';