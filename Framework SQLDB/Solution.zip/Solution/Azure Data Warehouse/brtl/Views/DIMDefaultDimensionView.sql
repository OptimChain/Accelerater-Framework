﻿CREATE VIEW [brtl].[DIMDefaultDimensionView]
AS select distinct
--[$Table].[Default Dimension Key] as [Default Dimension Key],
    [$Table].[DefaultDimension] as [Default Dimension Id],
    [$Table].[_1_BusinessChannel] as [_1_BusinessChannel Key],
    [$Table].[_2_Store] as [_2_Store Key],
    [$Table].[_3_CostCenter] as [_3_CostCenter Key],
    [$Table].[_4_ItemGroup] as [_4_ItemGroup Key]
    --[$Table].[ea_Process_DateTime] as [ea_Process_DateTime]
from [brtl].[DimDefaultDimension] as [$Table] WITH (NOLOCK);