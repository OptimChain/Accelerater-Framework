﻿CREATE VIEW [brtl].[DIMInventoryConfigView]
AS select [_].[RecordId] as [Record Id],
    [_].[CompanyCode] as [Company Code],
    [_].[ItemCode] as [Item Code],
    [_].[InventoryConfigCode] as [Product Config Code],
    [_].[InventoryConfig] as [Product Config]
   -- [_].[ea_Process_DateTime] as [ea_Process_DateTime]
from [brtl].[DIMInventoryConfig] as [_];