﻿CREATE VIEW [brtl].[DIMLocationView]
AS SELECT
[WarehouseCode] as [Warehouse Code]
,[Warehouse]
,[SiteCode] as [Site Code]
,[Site]
FROM [brtl].[DimLocation] WITH (NOLOCK);