﻿CREATE VIEW [brtl].[FCTBTLTransferReleaseHistoryLogView]
AS SELECT 
*
FROM [brtl].[BTLTransferReleaseHistoryLog] WITH (NOLOCK);