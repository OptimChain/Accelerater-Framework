﻿CREATE VIEW [brtl].[FCTInventoryTransPostingView]
AS SELECT  
*
FROM [brtl].[FCTInventoryTransPosting] WITH (NOLOCK);