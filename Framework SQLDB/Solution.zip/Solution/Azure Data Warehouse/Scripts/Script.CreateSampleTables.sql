﻿-----------------------------------------------------------------------------------------
--
--  File:  Script.CreateSampleTables.sql
--
--  Purpose:  Create sample tables in Azure Data Warehouse.
--
--  Modification History:
--
--    Date		Author							Comment
--  ----------	------------------------------	-----------------------------------------
--  08/02/2018	Alan Campbell					Created.
--
--
-- Developed by Neudesic, LLC.
-----------------------------------------------------------------------------------------

-- Code commented to avoid syntax errors in the project.

/*


CREATE TABLE [dbo].[DimCustomer] 
(
    [CustomerKey]           INT              IDENTITY (1, 1) NOT NULL,
    [CustomerID]            NVARCHAR (20)    NOT NULL,
    [CustomerFirstName]     NVARCHAR (50)    NOT NULL,
    [CustomerLastName]      NVARCHAR (50)    NOT NULL,
    [CustomerCity]          NVARCHAR (100)   NOT NULL,
    [CustomerState]         NVARCHAR (50)    NOT NULL,
    [CustomerBirthDate]     DATE             NULL,
    [CustomerMaritalStatus] NVARCHAR (50)    NOT NULL,
    [CustomerGender]        NVARCHAR (50)    NOT NULL,
    [CustomerYearlyIncome]  MONEY            NULL,
    [CustomerEducation]     NVARCHAR (50)    NOT NULL,
    [CustomerOccupation]    NVARCHAR (50)    NOT NULL,
    [CustomerType]          NVARCHAR (50)    NOT NULL,
    [IsActive]              BIT              NOT NULL,
    [IsCurrent]             BIT              NOT NULL,
    [IsDeleted]             BIT              NOT NULL,
    [EffectiveDate]         DATETIME         NOT NULL,
    [ExpirationDate]        DATETIME         NULL,
    [ChangingHashbyte]      VARBINARY (8000) NOT NULL,
    [HistoricalHashbyte]    VARBINARY (8000) NOT NULL,
    [CreatedDate]           DATETIME         NOT NULL,
    [ModifiedDate]          DATETIME         NULL,
    [InsertAuditKey]        INT              NOT NULL,
    [UpdateAuditKey]        INT              NULL
)
WITH
	(
		CLUSTERED INDEX (CustomerKey),
		DISTRIBUTION = HASH(CustomerID)
	)

-- Create Statistics on join, filter or grouping columns for performance.

CREATE STATISTICS CustomerKey ON DimCustomer (CustomerKey)
CREATE STATISTICS CustomerType ON DimCustomer (CustomerType)


CREATE TABLE [dbo].[DimDate] 
(
    [DateKey]           DATE     NOT NULL,
    [DayDate]           DATE     NOT NULL,
    [IsHoliday]         BIT      NOT NULL,
    [DayNumberOfWeek]   TINYINT  NOT NULL,
    [DayNumberOfMonth]  TINYINT  NOT NULL,
    [DayNumberOfYear]   SMALLINT NOT NULL,
    [WeekNumberOfYear]  TINYINT  NOT NULL,
    [MonthNumberOfYear] TINYINT  NOT NULL,
    [CalendarQuarter]   TINYINT  NOT NULL,
    [CalendarSemester]  TINYINT  NOT NULL,
    [CalendarYear]      INT      NOT NULL,
    [FiscalQuarter]     TINYINT  NOT NULL,
    [FiscalSemester]    TINYINT  NOT NULL,
    [FiscalYear]        INT      NOT NULL
)
WITH
	(
		CLUSTERED INDEX (DateKey),
		DISTRIBUTION = HASH(DateKey)
	)

CREATE STATISTICS DateKey ON DimDate (DateKey)

CREATE TABLE [dbo].[DimProduct] 
(
    [ProductKey]             INT              IDENTITY (1, 1) NOT NULL,
    [ProductID]              NVARCHAR (20)    NOT NULL,
    [ProductLabel]           NVARCHAR (50)    NOT NULL,
    [ProductName]            NVARCHAR (100)   NOT NULL,
    [ProductSubcategoryName] NVARCHAR (50)    NOT NULL,
    [ProductCategoryName]    NVARCHAR (50)    NOT NULL,
    [ProductColor]           NVARCHAR (50)    NOT NULL,
    [ProductUnitCost]        MONEY            NOT NULL,
    [ProductUnitPrice]       MONEY            NOT NULL,
    [IsActive]               BIT              NOT NULL,
    [IsCurrent]              BIT              NOT NULL,
    [IsDeleted]              BIT              NOT NULL,
    [EffectiveDate]          DATETIME         NOT NULL,
    [ExpirationDate]         DATETIME         NULL,
    [ChangingHashbyte]       VARBINARY (8000) NOT NULL,
    [HistoricalHashbyte]     VARBINARY (8000) NOT NULL,
    [CreatedDate]            DATETIME         NOT NULL,
    [ModifiedDate]           DATETIME         NULL,
    [InsertAuditKey]         INT              NOT NULL,
    [UpdateAuditKey]         INT              NULL
)
WITH
	(
		CLUSTERED INDEX (ProductKey),
		DISTRIBUTION = HASH(ProductID)
	)

CREATE STATISTICS ProductKey ON DimProduct (ProductKey)
CREATE STATISTICS ProductSubcategoryName ON DimProduct (ProductSubcategoryName)
CREATE STATISTICS ProductCategoryName ON DimProduct (ProductCategoryName)

CREATE TABLE [dbo].[DimStore] 
(
    [StoreKey]           INT              IDENTITY (1, 1) NOT NULL,
    [StoreID]            NVARCHAR (20)    NOT NULL,
    [StoreName]          NVARCHAR (100)   NOT NULL,
    [StoreCity]          NVARCHAR (100)   NOT NULL,
    [StoreState]         NVARCHAR (50)    NOT NULL,
    [StorePostalCode]    NVARCHAR (10)    NULL,
    [StoreType]          NVARCHAR (50)    NOT NULL,
    [StoreSize]          INT              NULL,
    [StoreStatus]        NVARCHAR (50)    NOT NULL,
    [IsActive]           BIT              NOT NULL,
    [IsCurrent]          BIT              NOT NULL,
    [IsDeleted]          BIT              NOT NULL,
    [EffectiveDate]      DATETIME         NOT NULL,
    [ExpirationDate]     DATETIME         NULL,
    [ChangingHashbyte]   VARBINARY (8000) NOT NULL,
    [HistoricalHashbyte] VARBINARY (8000) NOT NULL,
    [CreatedDate]        DATETIME         NOT NULL,
    [ModifiedDate]       DATETIME         NULL,
    [InsertAuditKey]     INT              NOT NULL,
    [UpdateAuditKey]     INT              NULL
)
WITH
	(
		CLUSTERED INDEX (StoreKey),
		DISTRIBUTION = REPLICATE
	)

CREATE STATISTICS StoreKey ON DimStore (StoreKey)

CREATE TABLE [dbo].[FactSales] 
(
    [SalesKey]       BIGINT         IDENTITY (1, 1) NOT NULL,
    [SalesID]        NVARCHAR (20)  NOT NULL,
    [SalesLineID]    NVARCHAR (20)  NOT NULL,
    [OrderDateKey]   DATE           NOT NULL,
    [StoreKey]       INT            NOT NULL,
    [CustomerKey]    INT            NOT NULL,
    [ProductKey]     INT            NOT NULL,
    [SalesQuantity]  DECIMAL (6, 2) NOT NULL,
    [SalesUnitCost]  MONEY          NOT NULL,
    [SalesUnitPrice] MONEY          NOT NULL,
    [SalesAmount]    MONEY          NOT NULL,
    [CreatedDate]    DATETIME       NOT NULL,
    [ModifiedDate]   DATETIME       NULL,
    [InsertAuditKey] INT            NOT NULL,
    [UpdateAuditKey] INT            NULL
)
WITH
	(
		CLUSTERED COLUMNSTORE INDEX,
		DISTRIBUTION = HASH(OrderDateKey)
	)

-- Create some nonclustered indexes on joining columns

CREATE INDEX IX_FactSales_OrderDateKey ON FactSales (OrderDateKey)
CREATE INDEX IX_FactSales_StoreKey ON FactSales (StoreKey)
CREATE INDEX IX_FactSales_CustomerKey ON FactSales (CustomerKey)
CREATE INDEX IX_FactSales_ProductKey ON FactSales (ProductKey)

CREATE STATISTICS SalesKey ON FactSales (SalesKey)
CREATE STATISTICS OrderDateKey ON FactSales (OrderDateKey)
CREATE STATISTICS StoreKey ON FactSales (StoreKey)
CREATE STATISTICS CustomerKey ON FactSales (CustomerKey)
CREATE STATISTICS ProductKey ON FactSales (ProductKey)

*/