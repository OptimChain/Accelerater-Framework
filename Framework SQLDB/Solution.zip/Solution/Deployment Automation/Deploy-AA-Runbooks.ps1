<#

	NEUDESIC AZURE FRAMEWORK

    DESCRIPTION
        Populate Tables in Azure Data Warehouse from local Visual Studio code.

    MODIFICATION HISTORY

	  DATE		AUTHOR					NOTES
	---------	----------------------	---------------------------------------------------------
	10/18/2017	Ken Mears				Created.
	2/9/2018	Ken Mears				Standardized for the Framework.
        
#>

Param(
    [Parameter(Position=0,Mandatory=$true)]
    [ValidateNotNull()]
    [ValidateSet("Dev", "Test", "Prod")]
    [System.String]$Environment, #$env:COMPUTERNAME
    [Parameter(Position=1,Mandatory=$true,HelpMessage="Should a prompt to login appear? Acceptable values are Yes or No")]
    [ValidateNotNull()]
    [System.String]$PromptForLogin
)

If ($PromptForLogin -eq "Yes") {
    Login-AzureRmAccount
    Select-AzureRmSubscription -SubscriptionName $Environment
}

# Set Data Factory variables
    
switch ($Environment) {
    "Dev" {
	    $resourceGroupName = "neudesic-da-dev-eus2-mgt-rg"
	    $automationName = "neudesic-da-dev-eus2-mgt-aa"
        $envAbbrv = "-dev-"
        $serverName = "neudesicdadeveus2sas"
    }
    "Test" {
	    $resourceGroupName = "neudesic-da-tst-eus2-mgt-rg"
	    $automationName = "neudesic-da-tst-eus2-mgt-aa"
        $envAbbrv = "-tst-"
        $serverName = "neudesicdatsteus2sas"
    }
    "Prod" {
	    $resourceGroupName = "neudesic-da-prd-eus2-mgt-rg"
	    $automationName = "neudesic-da-prd-eus2-mgt-aa"
        $envAbbrv = "-prd-"
        $serverName = "neudesicdaprdeus2sas"
    }
    default {
	    $resourceGroupName = "neudesic-da-dev-eus2-mgt-rg"
	    $automationName = "neudesic-da-dev-eus2-mgt-aa"
        $envAbbrv = "-dev-"
        $serverName = "neudesicdadeveus2sas"
    }
}

$DeploymentFolder = [Environment]::GetEnvironmentVariable("DeploymentFolder","User")

If ($DeploymentFolder -eq $null) {
    $DeploymentFolder = Read-Host -Prompt "Please enter your solution folder's full path"
    [Environment]::SetEnvironmentVariable("DeploymentFolder", $DeploymentFolder, "User")
    Write-Host "Deployment folder set to..." -ForegroundColor Green
    $DeploymentFolder = [Environment]::GetEnvironmentVariable("DeploymentFolder","User")
    Write-Host $DeploymentFolder -ForegroundColor Yellow
}

Write-Host "Azure Automation Settings" -ForegroundColor Yellow
Write-Host "Resource Group: $($resourceGroupName)" -ForegroundColor Yellow
Write-Host "Service Name : $($automationName)" -ForegroundColor Yellow
Write-Host

#Compare-Object $(Get-Content c:\scripts\x.txt) $(Get-Content c:\scripts\y.txt)

Get-ChildItem "$DeploymentFolder\PowerShell Library\Azure Automation Scripts\*" -Include *.ps1, *.graphrunbook  | 
Foreach-Object {
    If ($ignored -notcontains $_.BaseName) {
        Write-Host "Deploying runbook $($_.BaseName)..." -ForegroundColor Yellow

        $content = [IO.File]::ReadAllText($_.FullName)
        $content = $content.Replace("-dev-", $envAbbrv)
        $content = $content.Replace("-tst-", $envAbbrv)
        $content = $content.Replace("-prd-", $envAbbrv)
        $content = $content.Replace("e470dadeveus2sas", $serverName)
        $content = $content.Replace("e470datsteus2sas", $serverName)
        $content = $content.Replace("e470daprdeus2sas", $serverName)
        [IO.File]::WriteAllText($_.FullName, $content.TrimEnd())

        $rb = Get-AzureRmAutomationRunbook -AutomationAccountName $automationName -Name $_.BaseName -ResourceGroupName $resourceGroupName -ErrorAction SilentlyContinue
        $rbType = "PowerShellWorkflow"
        If ($rb.State) {
            Write-Host "$($_.BaseName) found... replacing." -ForegroundColor Yellow
            If ($rb.RunbookType -eq "Script") {
                $rbType = "PowerShell"
            } else {
                $rbType = $rb.RunbookType
                If ($rbType -eq "GraphPowerShellWorkflow") {
                    $rbType = "GraphicalPowerShellWorkflow"
                }
            }
        } else {
            Write-Host "$($_.BaseName) not found... creating...." -ForegroundColor Yellow
            If ($_.Extension -eq ".ps1") {
                $rbType = "PowerShellWorkflow"
            } else {
                $rbType = "GraphicalPowerShellWorkflow"
            }
        }
        Import-AzureRmAutomationRunbook -Name $_.BaseName -Path $_.FullName -Type $rbType -Published -Force -AutomationAccountName $automationName -ResourceGroupName $resourceGroupName
    }
}

Write-Host "Press any key to continue ..."

$x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")