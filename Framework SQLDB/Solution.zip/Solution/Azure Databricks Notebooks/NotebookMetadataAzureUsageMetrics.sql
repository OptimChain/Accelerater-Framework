DECLARE @ContainerExecutionGroupName VARCHAR(255) = 'azureusagemetrics';
DECLARE @ContainerName varchar(255) = lower(@ContainerExecutionGroupName);
DECLARE @DataFactoryName VARCHAR(255) = 'TBD';
DECLARE @NotebookName varchar(100) = '%azureusagemetrics%'

--DELETE NotebookExecutionPlan
DELETE NotebookExecutionPlan
FROM NotebookExecutionPlan p
JOIN Notebook n ON p.NotebookKey = n.NotebookKey
JOIN Container c ON p.ContainerKey = c.ContainerKey
WHERE c.ContainerName = @ContainerName AND n.NotebookName like @NotebookName

--DELETE NotebookParameter
DELETE NotebookParameter
FROM NotebookParameter p
JOIN Notebook n ON p.NotebookKey = n.NotebookKey
WHERE NotebookName like @ContainerName+'%' AND n.NotebookName like @NotebookName

--DELETE NotebookExecutionGroup
/*
DELETE NotebookExecutionGroup
FROM NotebookExecutionGroup neg
JOIN ContainerExecutionGroup ceg ON ceg.ContainerExecutionGroupKey = neg.ContainerExecutionGroupKey
JOIN Container c on ceg.ContainerKey = c.ContainerKey
WHERE c.ContainerName = @ContainerName
*/

DECLARE @NotebookExecutionGroupName varchar(255) = @ContainerExecutionGroupName+' Ingest'

EXEC dbo.uspInsertNotebookParameters @NotebookName = 'azureusagemetrics_PowerBI_AuditLog_Ingest',@NotebookExecutionGroupName=@NotebookExecutionGroupName,@DataFactoryName=@DataFactoryName,@ContainerName=@ContainerName,@ContainerExecutionGroupName=@ContainerExecutionGroupName,@NotebookOrder=10,@NumPartitions=2,@QueryZoneSchemaName='PowerBI',@QueryZoneTableName='PowerBI_AuditLog',@ExternalDataPath='',@RawDataPath='/Raw/PowerBI',@QueryZoneNotebookPath='/Framework/Query Zone Processing - Overwrite Delta Lake';
EXEC dbo.uspInsertNotebookParameters @NotebookName = 'APS_azureusagemetrics_PowerBI_AuditLog_Summary_Ingest',@NotebookExecutionGroupName=@NotebookExecutionGroupName,@DataFactoryName=@DataFactoryName,@ContainerName=@ContainerName,@ContainerExecutionGroupName=@ContainerExecutionGroupName,@NotebookOrder=10,@NumPartitions=2,@QueryZoneSchemaName='PowerBI',@QueryZoneTableName='PowerBI_AuditLog_Summary',@ExternalDataPath='',@RawDataPath='/Raw/PowerBIPowerBI_AuditLog_Summary',@QueryZoneNotebookPath='/Framework/Query Zone Processing - Overwrite Delta Lake';

SELECT @NotebookExecutionGroupName = @ContainerExecutionGroupName+' Enrich and Publish'

EXEC dbo.uspInsertNotebookParameters @NotebookName = 'azureusagemetrics_PowerBI_AuditLog_Enrich',@NotebookExecutionGroupName=@NotebookExecutionGroupName,@DataFactoryName=@DataFactoryName,@ContainerName=@ContainerName,@ContainerExecutionGroupName=@ContainerExecutionGroupName,@NotebookOrder=10,@NumPartitions=2,@QueryZoneSchemaName='cgs',@QueryZoneTableName='PowerBI_AuditLog',@ExternalDataPath='',@RawDataPath='',@QueryZoneNotebookPath='/Query Zone Processing - Enrich PowerBI_AuditLog',@SummaryZoneNotebookPath='',@SanctionedZoneNotebookPath='',@VacuumRetentionHours=168;

SELECT @NotebookExecutionGroupName = @ContainerExecutionGroupName+' Sanction and Publish'
