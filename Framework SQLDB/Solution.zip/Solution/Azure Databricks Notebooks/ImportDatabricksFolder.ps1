﻿# Run the Install only once
# Install-Module azure.databricks.cicd.tools
# Import-Module azure.databricks.cicd.tools
#Install-Module Az.KeyVault

$VaultName = 'rsm-entdata-dev'


#$Ctx = New-AzStorageContext -StorageAccountName rsmentdatalakedev -StorageAccountKey "61CEoSr4NUt7vinCw2XICSoSBV9J21L9kcv/rUk46iFCqp6cJwxDOztpOT+ln12bzX3xWvcLzZfVlQWFEAg/8Q=="

$FrameworkBearerToken = Get-AzKeyVaultSecret -vaultName $VaultName -name "DatabricksFrameworkAdminToken" -AsPlainText
$ContainerBearerToken = Get-AzKeyVaultSecret -vaultName $VaultName -name "DatabricksDataAdminToken" -AsPlainText
$Region = "Central US"


Import-DatabricksFolder -BearerToken $FrameworkBearerToken -Region $Region -LocalPath 'C:\Users\E080151\Source\repos\Neudesic\Azure Data Analytics\Solution\Azure Databricks Notebooks\Framework' -DatabricksPath '/Framework'

Import-DatabricksFolder -BearerToken $ContainerBearerToken -Region $Region -LocalPath 'C:\Users\E080151\Source\repos\Neudesic\Azure Data Analytics\Solution\Azure Databricks Notebooks\Container\' -DatabricksPath '/rsm'

