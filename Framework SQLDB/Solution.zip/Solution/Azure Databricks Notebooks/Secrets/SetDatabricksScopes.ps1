﻿#Container Secrets

$SubscriptionId = "d1837fe2-2596-4d4b-9242-fdea4caf40ea"
Select-AzSubscription -SubscriptionId $SubscriptionId


$KeyVaultName = "rsm-entdata-dev"
$Region = "CentralUS"



$ContainerToken = Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "DatabricksDataAdminToken" -AsPlainText
$FrameworkToken = Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "DatabricksFrameworkAdminToken" -AsPlainText




Connect-Databricks -BearerToken $ContainerToken -Region $Region

Add-DatabricksSecretScope -BearerToken $ContainerToken -Region $Region -ScopeName rsmadmin
Add-DatabricksSecretScope -BearerToken $ContainerToken -Region $Region -ScopeName rsmcontribute
Add-DatabricksSecretScope -BearerToken $ContainerToken -Region $Region -ScopeName rsmpublish
Add-DatabricksSecretScope -BearerToken $ContainerToken -Region $Region -ScopeName rsmread



Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmadmin -SecretName ADLSGen2StorageAccountName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ADLSName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmadmin -SecretName ADLSTenantID -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ADLSTenantID" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmadmin -SecretName SQLFrameworkServerName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkServerName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmadmin -SecretName SQLFrameworkDatabaseName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkDatabaseName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmadmin -SecretName SQLFrameworkUserName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkUserName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmadmin -SecretName SQLFrameworkPassword -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkPassword" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmadmin -SecretName SQLDWDatabaseName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWDatabaseName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmadmin -SecretName SQLDWServerName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWServerName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmadmin -SecretName SQLDWUserName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWUserName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmadmin -SecretName SQLDWPassword -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWPassword" -AsPlainText)


Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmcontribute -SecretName ADLSGen2StorageAccountName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ADLSName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmcontribute -SecretName ADLSTenantID -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ADLSTenantID" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmcontribute -SecretName SQLFrameworkServerName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkServerName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmcontribute -SecretName SQLFrameworkDatabaseName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkDatabaseName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmcontribute -SecretName SQLFrameworkUserName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkUserName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmcontribute -SecretName SQLFrameworkPassword -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkPassword" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmcontribute -SecretName SQLDWDatabaseName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWDatabaseName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmcontribute -SecretName SQLDWServerName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWServerName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmcontribute -SecretName SQLDWUserName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWUserName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmcontribute -SecretName SQLDWPassword -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWPassword" -AsPlainText)

Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmpublish -SecretName ADLSGen2StorageAccountName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ADLSName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmpublish -SecretName ADLSTenantID -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ADLSTenantID" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmpublish -SecretName SQLFrameworkServerName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkServerName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmpublish -SecretName SQLFrameworkDatabaseName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkDatabaseName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmpublish -SecretName SQLFrameworkUserName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkUserName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmpublish -SecretName SQLFrameworkPassword -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkPassword" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmpublish -SecretName SQLDWDatabaseName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWDatabaseName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmpublish -SecretName SQLDWServerName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWServerName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmpublish -SecretName SQLDWUserName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWUserName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmpublish -SecretName SQLDWPassword -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWPassword" -AsPlainText)


Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmread -SecretName ADLSGen2StorageAccountName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ADLSName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmread -SecretName ADLSTenantID -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ADLSTenantID" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmread -SecretName SQLFrameworkServerName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkServerName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmread -SecretName SQLFrameworkDatabaseName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkDatabaseName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmread -SecretName SQLFrameworkUserName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkUserName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmread -SecretName SQLFrameworkPassword -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkPassword" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmread -SecretName SQLDWDatabaseName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWDatabaseName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmread -SecretName SQLDWServerName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWServerName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmread -SecretName SQLDWUserName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWUserName" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmread -SecretName SQLDWPassword -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWPassword" -AsPlainText)



Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmadmin -SecretName ADLSClientID -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "AdminADLSClientID" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmadmin -SecretName ADLSCredential -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "AdminADLSCredential" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmContribute -SecretName ADLSClientID -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ContributeADLSClientID" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmcontribute -SecretName ADLSCredential -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ContributeADLSCredential" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmpublish -SecretName ADLSClientID -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "PublishADLSClientID" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmpublish -SecretName ADLSCredential -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "PublishADLSCredential" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmread -SecretName ADLSClientID -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ReadADLSClientID" -AsPlainText)
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName rsmread -SecretName ADLSCredential -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ReadADLSCredential" -AsPlainText)





#ACLs
#Set-DatabricksPermission -BearerToken  $ContainerToken  -Principal AzureAD-da-tst-rsm-Admin -PermissionLevel Read -DatabricksObjectType secretScope - rsmadmin
#Set-DatabricksPermission -BearerToken  $ContainerToken  -Principal AzureAD-da-tst-rsm-Contribute -PermissionLevel Read -DatabricksObjectType secretScope -DatabricksObjectId rsmcontribute
#Set-DatabricksPermission -BearerToken  $ContainerToken  -Principal AzureAD-da-tst-rsm-Publish -PermissionLevel Read -DatabricksObjectType secretScope -DatabricksObjectId rsmpublish
#Set-DatabricksPermission -BearerToken  $ContainerToken  -Principal AzureAD-da-tst-rsm-Read -PermissionLevel Read -DatabricksObjectType secretScope -DatabricksObjectId rsmread

#Framework Secrets

Add-DatabricksSecretScope -BearerToken $FrameworkToken -Region $Region -ScopeName framework

Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName framework -SecretName ADLSStorageAccountName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ADLSStorageAccountKey" -AsPlainText)
Set-DatabricksSecret -BearerToken $FrameworkToken -ScopeName framework -SecretName ADLSGen2StorageAccountName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ADLSName" -AsPlainText)
Set-DatabricksSecret -BearerToken $FrameworkToken -ScopeName framework -SecretName ADLSTenantID -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ADLSTenantID" -AsPlainText)
Set-DatabricksSecret -BearerToken $FrameworkToken -ScopeName framework -SecretName SQLFrameworkServerName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkServerName" -AsPlainText)
Set-DatabricksSecret -BearerToken $FrameworkToken -ScopeName framework -SecretName SQLFrameworkDatabaseName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkDatabaseName" -AsPlainText)
Set-DatabricksSecret -BearerToken $FrameworkToken -ScopeName framework -SecretName SQLFrameworkUserName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkUserName" -AsPlainText)
Set-DatabricksSecret -BearerToken $FrameworkToken -ScopeName framework -SecretName SQLFrameworkPassword -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkPassword" -AsPlainText)
Set-DatabricksSecret -BearerToken $FrameworkToken -ScopeName framework -SecretName SQLDWDatabaseName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWDatabaseName" -AsPlainText)
Set-DatabricksSecret -BearerToken $FrameworkToken -ScopeName framework -SecretName SQLDWServerName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWServerName" -AsPlainText)
Set-DatabricksSecret -BearerToken $FrameworkToken -ScopeName framework -SecretName SQLDWUserName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWUserName" -AsPlainText)
Set-DatabricksSecret -BearerToken $FrameworkToken -ScopeName framework -SecretName SQLDWPassword -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWPassword" -AsPlainText)

Set-DatabricksSecret -BearerToken $FrameworkToken -ScopeName framework -SecretName ADLSGen2StorageAccountKey -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ADLSStorageAccountKey" -AsPlainText)
Set-DatabricksSecret -BearerToken $FrameworkToken -ScopeName framework -SecretName ADLSClientID -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "AdminADLSClientID" -AsPlainText)
Set-DatabricksSecret -BearerToken $FrameworkToken -ScopeName framework -SecretName ADLSCredential -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "AdminADLSCredential" -AsPlainText)


