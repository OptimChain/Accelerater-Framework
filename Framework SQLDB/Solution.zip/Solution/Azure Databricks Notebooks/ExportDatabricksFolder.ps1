﻿# Run the Install only once
#Install-Module azure.databricks.cicd.tools -Scope CurrentUser
#Connect-AzAccount
#Connect-Databricks
Import-Module azure.databricks.cicd.tools
#Update-Module -Name azure.databricks.cicd.tools

$VaultName = 'rsm-entdata-dev'
$Region = 'Central US'

$FrameworkBearerToken = Get-AzKeyVaultSecret -vaultName $VaultName -name "DatabricksFrameworkAdminToken" -AsPlainText
$ContainerBearerToken = Get-AzKeyVaultSecret -vaultName $VaultName -name "DatabricksDataAdminToken" -AsPlainText

Export-DatabricksFolder -BearerToken $FrameworkBearerToken -Region $Region -LocalOutputPath 'C:\Users\E080151\source\repos\Neudesic\Azure Data Analytics\Solution\Azure Databricks Notebooks\Framework' -ExportPath '/Framework'

Export-DatabricksFolder -BearerToken $ContainerBearerToken -Region $Region -LocalOutputPath 'C:\Users\E080151\source\repos\Neudesic\Azure Data Analytics\Solution\Azure Databricks Notebooks\Container' -ExportPath '/rsm'

