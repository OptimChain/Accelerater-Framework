 
 dbutils.fs.rm("dbfs:/user/hive/warehouse/brtl.db/purchtable_data_delta_to_upsert", True)

# COMMAND ----------

 dbutils.fs.ls("dbfs:/user/hive/warehouse/brtl.db")

# COMMAND ----------

# MAGIC %run /Framework/Secrets-Databricks-Cache

# COMMAND ----------

# MAGIC %run /Framework/Neudesic_Framework_Functions

# COMMAND ----------

containerName = "brtl"
tableName = "INVENTTRANS"
fullPathPrefix = "abfss://" + containerName + "@" + adlsgen2storageaccountname + ".dfs.core.windows.net" 
enrichedPath = fullPathPrefix + "/Query/Enriched/" + tableName
spark.sql("CREATE TABLE INVENTTRANSTest USING DELTA LOCATION 'abfss://brtl@dadevwus2analyticsdl.dfs.core.windows.net/Query/Enriched/INVENTTRANS'")

# COMMAND ----------

containerName = "brtl"
tableName = "INVENTTRANS"
fullPathPrefix = "abfss://" + containerName + "@" + adlsgen2storageaccountname + ".dfs.core.windows.net" 
CurrentStatePath = fullPathPrefix + "/Query/CurrentState/" + tableName
spark.sql("CREATE TABLE INVENTTRANSTestCS USING DELTA LOCATION 'abfss://brtl@dadevwus2analyticsdl.dfs.core.windows.net/Query/CurrentState/INVENTTRANS'")

# COMMAND ----------

# MAGIC %sql
# MAGIC select COUNT(1) AS EnrichCount from INVENTTRANSTest

# COMMAND ----------

# MAGIC %sql
# MAGIC select COUNT(1) AS CurrentStateCount from INVENTTRANSTestCS