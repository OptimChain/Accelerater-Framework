﻿
function new-KeyVaultSecret ($secretName, $secretValue) {
    az keyvault secret set `
        --vault-name $keyVaultName `
        --name $secretName `
        --value (ConvertTo-SecureString -String $secretValue -AsPlainText -Force)
}

new-KeyVaultSecret "ADLSName" rsmentdatalakedev
new-KeyVaultSecret "ADLSStorageAccountKey" "61CEoSr4NUt7vinCw2XICSoSBV9J21L9kcv/rUk46iFCqp6cJwxDOztpOT+ln12bzX3xWvcLzZfVlQWFEAg/8Q=="
new-KeyVaultSecret "ADLSTenantId" 1e3e71be-fcca-4284-9031-688cc8f37b6b
new-KeyVaultSecret "SQLFrameworkConnectionString" Server=tcp:rsm-entdata-dev.database.windows.net, 1433; Initial Catalog=rsm_ed_fw_db; Persist Security Info=False; User ID=BartellAdmin; Password='REDACTED'/[659; MultipleActiveResultSets=False; Encrypt=True; TrustServerCertificate=False; Connection Timeout=30;
new-KeyVaultSecret "SQLFrameworkServerName" "rsm-entdata-dev.database.windows.net"
new-KeyVaultSecret "SQLFrameworkDatabaseName" rsm_ed_fw_db
new-KeyVaultSecret "SQLFrameworkPassword" #REDACTED
new-KeyVaultSecret "SQLFrameworkUserName" BartellAdmin
new-KeyVaultSecret "SQLDWServerName" "rsmentdatadev-ondemand.sql.azuresynapse.net"
new-KeyVaultSecret "SQLDWDatabaseName" rsmentdatadev
new-KeyVaultSecret "SQLDWPassword" $SQLDWServerPassword
new-KeyVaultSecret "SQLDWUserName" $SQLDWServerUserName
new-KeyVaultSecret "DatabricksFrameworkAdminToken" "Update manually"  
new-KeyVaultSecret "DatabricksDataAdminToken" "Update manually"