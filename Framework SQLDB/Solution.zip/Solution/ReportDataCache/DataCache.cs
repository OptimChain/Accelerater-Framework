﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace DataCache
{
    /// <summary>
    /// This class stores key value pairs in a Dictionary object.
    /// </summary>
    public static class DataCache
    {
        private static volatile Dictionary<string, string> _cacheStorage = new Dictionary<string, string>();

        /// <summary>
        /// Lock sync object.
        /// </summary>
        private static object _sync = new object();

        /// <summary>
        /// Initializes the class.
        /// </summary>
        static DataCache()
        {
            lock (_sync)
            {

            }
        }

        /// <summary>
        /// Gets the number of items cached.
        /// </summary>
        /// <value>The count.</value>
        public static int Count
        {
            get { lock (_sync) { return _cacheStorage.Count; } }
        }

        /// <summary>
        /// Saves the value for specified key on cache.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="value">The value.</param>
        public static void Set(string key, string value)
        {
            lock (_sync)
            {
            if (!_cacheStorage.ContainsKey(key))
            {

                _cacheStorage[key] = value;
            }
            else
            {
                throw new ArgumentException("The Element or Item already exists in the cache", key);
            }
            }
        }

        /// <summary>
        /// Gets the specified key.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <returns></returns>
        public static string Get(string key)
        {
            lock (_sync)
            {
            try
            {
                return _cacheStorage[key];
            }

            catch (KeyNotFoundException)
            {
                throw new ArgumentException("The Element or Item does not exist in the cache", key);

            }

            }
        }

        public static void Clear()
        {
            lock (_sync)
            {
                _cacheStorage.Clear();
            }
        }
    }
}

