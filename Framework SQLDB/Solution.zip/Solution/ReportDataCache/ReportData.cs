﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Security.Permissions;
using System.Configuration;

namespace ReportDataCache
{
    public class ReportData
    {

        public string GetDataElement(int ReportKey, string ReportElementName)
        {
            string sElement = "";

            //Get connection string from web.config file for Report Server
            string connectString = ConfigurationManager.AppSettings.Get("ConnectionString");

            string queryString = "SELECT r.ReportKey, e.ReportElementName, e.ReportElementValue " +
                    "FROM dbo.Report AS r " +
                    "JOIN dbo.ReportLayout AS l ON r.ReportLayoutKey = l.ReportLayoutKey " +
                    "JOIN dbo.ReportElement AS e ON l.ReportLayoutKey = e.ReportLayoutKey " +

                    "UNION ALL " +

                    "SELECT r.ReportKey, i.ReportItemName, i.ReportItemValue " +
                    "FROM dbo.Report AS r " +
                    "JOIN dbo.ReportContent AS c ON r.ReportContentKey = c.ReportContentKey " +
                    "JOIN dbo.ReportItem AS i ON c.ReportContentKey = i.ReportContentKey " +

                    "UNION ALL " +

                    "SELECT ReportKey, ReportElementName, ReportElementValue " +
                    "FROM " +
                    "( " +
                    "SELECT ReportKey, CAST(ReportName AS VARCHAR(600)) AS ReportName, " +
                           "CAST(ReportDescription AS VARCHAR(600)) AS ReportDescription, " +
                           "CAST(ReportComment AS VARCHAR(600)) AS ReportComment, " +
                           "CAST(ReportFileName AS VARCHAR(600)) AS SSRSFilename " +
                    "FROM dbo.Report " +
                    ") t " +
                    "UNPIVOT " +
                    "( " +
                    "ReportElementValue " +
                    "FOR ReportElementName " +
                    "IN (ReportName, ReportDescription, ReportComment, SSRSFilename) " +
                    ") AS unpvt";

                if (DataCache.DataCache.Count == 0)
                {

                    System.Data.SqlClient.SqlClientPermission pSql = new SqlClientPermission(System.Security.Permissions.PermissionState.Unrestricted);
                    pSql.Assert();

                    //If running report in report designer, get hard-coded connectstring value. 
                    //Report designer is not able to access the report server web.config file
                    if (connectString == null)
                    {
                        connectString = "Data Source=localhost;" +
                            "Initial Catalog=neuFramework;" +
                            "Integrated Security=yes";
                    }

                    SqlConnection _cn = new SqlConnection(connectString);

                    SqlCommand cmd = new SqlCommand(queryString, _cn);

                    _cn.Open();

                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        DataCache.DataCache.Set(reader["ReportKey"].ToString() + "|" + reader["ReportElementName"].ToString(), reader["ReportElementValue"].ToString());
                    }

                    reader.Close();

                    _cn.Close();

                    sElement = DataCache.DataCache.Get(ReportKey + "|" + ReportElementName);
                }
                else
                {
                    sElement = DataCache.DataCache.Get(ReportKey + "|" + ReportElementName);
                }

                return sElement;
            }

        public string ClearCache()
        {
            DataCache.DataCache.Clear();
            return "Data Cache Refreshed";
        }
    }
}