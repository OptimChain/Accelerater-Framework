﻿/*********************************************************************************************************************
	File: 	Script.SetupNeudesicSQLAccount.sql

	Desc: 	Utility script to setup a neudesic SQL account if needed.

	Auth: 	Alan Campbell
	Date: 	08/01/2018

	NOTE:	
         

	==================================================================================================================
    Change History
	==================================================================================================================
	Date		Author						Description
	----------- ---------------------------	--------------------------------------------------------------------------
	08/01/2018	Alan Campbell				Created.			
**********************************************************************************************************************/

USE Master
GO
CREATE LOGIN [neudesic] WITH PASSWORD=N'pass@word1'
GO
CREATE USER [neudesic] FROM LOGIN [neudesic];
GO

EXEC sp_addRoleMember 'dbmanager', 'neudesic';
EXEC sp_addRoleMember 'loginmanager', 'neudesic'
GO

USE Retail
GO
CREATE USER [neudesic] FROM LOGIN [neudesic];
EXEC sp_addRoleMember 'db_owner', 'neudesic';
GO

USE Staging
GO
CREATE USER [neudesic] FROM LOGIN [neudesic];
EXEC sp_addRoleMember 'db_owner', 'neudesic';
GO

USE [Data Warehouse]
GO
CREATE USER [neudesic] FROM LOGIN [neudesic];
EXEC sp_addRoleMember 'db_owner', 'neudesic';
GO

USE Framework
GO
CREATE USER [neudesic] FROM LOGIN [neudesic];
EXEC sp_addRoleMember 'db_owner', 'neudesic';
GO

USE SSISDB
GO
CREATE USER [neudesic] FROM LOGIN [neudesic];
EXEC sp_addRoleMember 'db_owner', 'neudesic';
GO
EXEC sp_addRoleMember 'ssis_admin', 'neudesic';
GO

USE neuframeworkadw
GO
CREATE USER [neudesic] FROM LOGIN [neudesic];
EXEC sp_addRoleMember 'db_owner', 'neudesic';
GO