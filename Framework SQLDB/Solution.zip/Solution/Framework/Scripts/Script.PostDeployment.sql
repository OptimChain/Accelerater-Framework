﻿/*********************************************************************************************************************
	File: 	Script.PostDeploymentScript.sql

	Desc: 	Post Deployment script.

	Auth: 	Alan Campbell
	Date: 	03/16/2016

	NOTE:	
         

	==================================================================================================================
    Change History
	==================================================================================================================
	Date		Author						Description
	----------- ---------------------------	--------------------------------------------------------------------------
	03/16/2016	Alan Campbell				Created.			
**********************************************************************************************************************/

-- Hydrate Metadata
:r ..\Data\DataSourceType.data.sql
:r ..\Data\DataSource.data.sql

:r ..\Data\System.data.sql
:r ..\Data\SystemActivityType.data.sql
:r ..\Data\SystemParameter.data.sql


:r ..\Data\Container.data.sql
:r ..\Data\ContainerType.data.sql
:r ..\Data\ContainerParameter.data.sql
:r ..\Data\ContainerActivityType.data.sql
--:r ..\Data\ContainerExecutionGroup.data.sql
--:r ..\Data\ContainerCAExecutionPlan.data.sql
--:r ..\Data\ContainerNBExecutionPlan.data.sql

--:r ..\Data\DataMapping.data.sql
--:r ..\Data\Package.data.sql
--:r ..\Data\PackageExecutionGroup.data.sql
--:r ..\Data\PackageLoadPlan.data.sql
--:r ..\Data\PackageExecutionPlan.data.sql


--:r ..\Data\TestGroup.data.sql
--:r ..\Data\TestMapping.data.sql

--:r ..\Data\Model.data.sql
--:r ..\Data\Entity.data.sql
--:r ..\Data\EntityRelationship.data.sql
--:r ..\Data\Attribute.data.sql


--:r ..\Data\DataFactory.data.sql

--:r ..\Data\PipeLine.data.sql
--:r ..\Data\PipeLineExecutionGroup.data.sql
--:r ..\framework\PipeLineExecutionPlan.data.sql
--:r ..\databricks\PipeLineExecutionPlan.data.sql

--:r ..\Data\CopyActivityDataType.data.sql
--:r ..\Data\CopyActivityDataSQLScript.data.sql
--:r ..\Data\CopyActivityDataFileSystem.data.sql
--:r ..\Data\CopyActivityDataADLS.data.sql

--:r ..\Data\CopyActivitySink.data.sql
--:r ..\Data\CopyActivityExecutionGroup.data.sql
--:r ..\framework\CopyActivityExecutionPlan.data.sql
--:r ..\databricks\CopyActivityExecutionPlan.data.sql


--:r ..\Data\StoredProcedure.data.sql
--:r ..\Data\StoredProcedureExecutionGroup.data.sql
--:r ..\framework\StoredProcedureExecutionPlan.data.sql
--:r ..\databricks\StoredProcedureExecutionPlan.data.sql

--:r ..\Data\Notebook.data.sql
--:r ..\Data\NotebookExecutionGroup.data.sql
--:r ..\framework\NotebookExecutionPlan.data.sql
--:r ..\Data\NotebookParameter.data.sql
--:r ..\databricks\NotebookExecutionPlan.data.sql

--exec dbo.uspGenerateTestCases

---- Report Metadata

--:r ..\Data\ReportContent.data.sql
--:r ..\Data\ReportLayout.data.sql
--:r ..\Data\ReportItem.data.sql
--:r ..\Data\ReportElement.data.sql
--:r ..\Data\Report.data.sql

---- Security

--CREATE USER [ReportUser] FOR LOGIN [ReportUser]
--GO
--ALTER ROLE [db_datareader] ADD MEMBER [ReportUser]
--GO





