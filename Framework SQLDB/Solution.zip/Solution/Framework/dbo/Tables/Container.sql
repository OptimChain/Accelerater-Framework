﻿CREATE TABLE [dbo].[Container](
	[ContainerKey] INT IDENTITY(1,1) NOT NULL,
	[ContainerName] [varchar](255) NOT NULL,
	[SystemKey] INT NOT NULL,
	[ContainerTypeKey] INT NOT NULL,
	[ContainerDate] datetime NULL,
	[ContainerCreatedBy] [varchar](255) NULL,
	[CreatedDate] datetime NOT NULL,
	[ModifiedDate] datetime NULL,
 CONSTRAINT [PKs] PRIMARY KEY CLUSTERED 
(
	[ContainerKey] ASC
))
GO