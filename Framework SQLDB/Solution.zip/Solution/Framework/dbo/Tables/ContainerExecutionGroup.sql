﻿CREATE TABLE [dbo].[ContainerExecutionGroup] (
    [ContainerExecutionGroupKey]  INT           IDENTITY (1, 1) NOT NULL,
    [ContainerExecutionGroupName] VARCHAR (100) NOT NULL,
	[ContainerKey]				INT NOT NULL,
    [IsActive]                 BIT           NOT NULL,
    [IsEmailEnabled]           BIT           NOT NULL,
    [CreatedDate]              DATETIME      NOT NULL,
    [ModifiedDate]             DATETIME      NULL,
    CONSTRAINT [PKceg] PRIMARY KEY CLUSTERED ([ContainerExecutionGroupKey] ASC),
	
);


GO
CREATE UNIQUE NONCLUSTERED INDEX [AK_ContainerExecutionGroup]
    ON [dbo].[ContainerExecutionGroup]([ContainerExecutionGroupName] ASC);

