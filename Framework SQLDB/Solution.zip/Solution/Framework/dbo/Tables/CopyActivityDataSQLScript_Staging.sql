﻿CREATE TABLE [dbo].[CopyActivityDataSQLScript_Staging] (
    [SQL DATA SCRIPT] NVARCHAR (MAX) NULL
);

