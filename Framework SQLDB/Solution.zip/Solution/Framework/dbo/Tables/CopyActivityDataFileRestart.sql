﻿CREATE TABLE [dbo].[CopyActivityDataFileRestart] (
    [CopyActivityFileRestartKey] BIGINT        IDENTITY (1, 1) NOT NULL,
    [FileDate]                   DATETIME      NULL,
    [CopyActivitySinkName]       VARCHAR (100) NULL,
    [CreatedDate]                DATETIME      NULL,
    [IsActive]                   BIT           NULL,
    CONSTRAINT [PKcadfs] PRIMARY KEY CLUSTERED ([CopyActivityFileRestartKey] ASC)
);

