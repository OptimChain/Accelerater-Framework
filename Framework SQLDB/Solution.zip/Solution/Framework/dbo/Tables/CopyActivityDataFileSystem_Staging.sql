﻿CREATE TABLE [dbo].[CopyActivityDataFileSystem_Staging] (
    [SQL DATA SCRIPT] NVARCHAR (MAX) NULL
);

