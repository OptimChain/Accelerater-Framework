CREATE TABLE [dbo].[CopyActivityDataSQLScript] (
    [CopyActivityDataSQLScriptKey]         INT           IDENTITY (1, 1) NOT NULL,
    [CopyActivityDataSQLScriptName]        VARCHAR (100) NULL,
    [CopyActivityDataSqlScript]            VARCHAR (MAX) NULL,
    [CopyActivityDataIncrementalSqlScript] VARCHAR (MAX) NULL,
    [IsIncrementalLoad]                    BIT           NULL,
    [IsActive]                             BIT           NULL,
    [LastRunDate]                          DATETIME2 (7) NULL,
    [CreateDate]                           DATE          NULL,
    [ModifiedDate]                         DATE          NULL,
    [ModifiedUser]                         VARCHAR (100) NULL,
    CONSTRAINT [PKCopyActivityDataSQLScriptKey] PRIMARY KEY CLUSTERED ([CopyActivityDataSQLScriptKey] ASC)
);






GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_CopyActivityDataSQLScript]
    ON [dbo].[CopyActivityDataSQLScript]([CopyActivityDataSQLScriptName] ASC);

