﻿CREATE TABLE [dbo].[Attribute] (
    [AttributeKey]			INT					NOT NULL,
    [AttributeName]			VARCHAR (255)		NOT NULL,
	[AttributeDescription]	VARCHAR (4000)		NOT NULL,
	[EntityKey]				INT					NOT NULL,
	[CreatedDate]			DATETIME			NOT NULL,
    [ModifiedDate]			DATETIME			NULL,
    CONSTRAINT [PK_Attribute] PRIMARY KEY CLUSTERED ([AttributeKey] ASC),
	CONSTRAINT [FK_Attribute_Entity] FOREIGN KEY ([EntityKey]) REFERENCES [dbo].[Entity] ([EntityKey])
);
