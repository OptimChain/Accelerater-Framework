﻿CREATE TABLE [dbo].[CopyActivityExecutionGroup] (
    [CopyActivityExecutionGroupKey]  INT          IDENTITY (1, 1) NOT NULL,
    [CopyActivityExecutionGroupName] VARCHAR (100) NOT NULL,
    [IsActive]                       BIT          NOT NULL,
    [IsEmailEnabled]                 BIT          NOT NULL,
    [CreatedDate]                    DATETIME     NOT NULL,
    [ModifiedDate]                   DATETIME     NULL,
    CONSTRAINT [PKcaeg] PRIMARY KEY CLUSTERED ([CopyActivityExecutionGroupKey] ASC)
);


GO
CREATE UNIQUE NONCLUSTERED INDEX [AK_CopyActivityExecutionGroup]
    ON [dbo].[CopyActivityExecutionGroup]([CopyActivityExecutionGroupName] ASC);

