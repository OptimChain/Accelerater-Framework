﻿CREATE TABLE [dbo].[CopyActivityErrorLog] (
    [CopyActivityErrorLogKey]     BIGINT         IDENTITY (1, 1) NOT NULL,
    [CopyActivityExecutionLogKey]       BIGINT         NOT NULL,
    [SourceName]             VARCHAR (255)  NOT NULL,
    [ErrorCode]              INT            NULL,
    [ErrorDescription]       VARCHAR (2000) NULL,
    [CreatedDate]            DATETIME       NOT NULL,
    [ModifiedDate]           DATETIME       NULL,
    CONSTRAINT [PKcaerrorlog] PRIMARY KEY CLUSTERED ([CopyActivityErrorLogKey] ASC),
    CONSTRAINT [RefCopyActivityExecutionLog] FOREIGN KEY ([CopyActivityExecutionLogKey]) REFERENCES [dbo].[CopyActivityExecutionLog] ([CopyActivityExecutionLogKey])
);


GO
CREATE NONCLUSTERED INDEX [Refcael]
    ON [dbo].[CopyActivityErrorLog]([CopyActivityExecutionLogKey] ASC);