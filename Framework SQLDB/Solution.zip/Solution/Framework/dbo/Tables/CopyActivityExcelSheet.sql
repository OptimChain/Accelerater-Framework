﻿CREATE TABLE [dbo].[CopyActivityExcelSheet] (
    [Id]                   INT           IDENTITY (1, 1) NOT NULL,
    [CopyActivitySinkName] VARCHAR (100) NOT NULL,
    [Sheet_Name]           VARCHAR (50)  NOT NULL,
    [CreatedDate]          DATETIME2 (3) NOT NULL,
    [ModifiedDate]         DATETIME2 (3) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

