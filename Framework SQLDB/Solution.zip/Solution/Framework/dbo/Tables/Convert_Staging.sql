﻿CREATE TABLE [dbo].[Convert_Staging] (
    [Convert] NVARCHAR (MAX) NULL
);

