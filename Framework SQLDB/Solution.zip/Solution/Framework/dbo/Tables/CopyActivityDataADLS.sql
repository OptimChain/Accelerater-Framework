﻿CREATE TABLE [dbo].[CopyActivityDataADLS] (
    [CopyActivityDataADLSKey]                INT            IDENTITY (1, 1) NOT NULL,
    [CopyActivityDataADLSName]               VARCHAR (100)  NULL,
    [CopyActivityDataADLSFolderPath] VARCHAR (1000) NULL,
    [CopyActivityDataADLSFileName]   VARCHAR (100)  NULL,
    [IsActive]                       BIT            NULL,
    [LastRunDate]                    DATETIME2 (7)  NULL,
    [CreateDate]                     DATE           NULL,
    [ModifiedDate]                   DATE           NULL,
    [ModifiedUser]                   VARCHAR (100)  NULL,
    CONSTRAINT [PKCopyActivityDataADLSKey] PRIMARY KEY CLUSTERED ([CopyActivityDataADLSKey] ASC)
);

GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_CopyActivityDataADLS] 
	ON [dbo].[CopyActivityDataADLS]([CopyActivityDataADLSName] ASC);
