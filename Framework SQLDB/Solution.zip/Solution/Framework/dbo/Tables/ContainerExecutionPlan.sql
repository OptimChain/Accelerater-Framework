﻿CREATE TABLE [dbo].[ContainerExecutionPlan] (
    [ContainerKey]               INT      NOT NULL,
    [DataFactoryKey]          INT      NOT NULL,
    [ContainerExecutionGroupKey] INT      NOT NULL,
    [ExecutionGroupKey]          INT      NOT NULL, -- used to be SystemGroupKey.  (from CopyActivityExecutionGroup or NotebookExecutionGroup)
    [ContainerActivityTypeKey]      INT      NOT NULL,
    [ContainerOrder]             INT      NOT NULL,
    [IsActive]                BIT      NOT NULL,
    [IsEmailEnabled]          BIT      NOT NULL,
    [IsRestart]               BIT      NOT NULL,
    [CreatedDate]             DATETIME NOT NULL,
    [ModifiedDate]            DATETIME NULL,
    CONSTRAINT [PKsep] PRIMARY KEY CLUSTERED ([ContainerKey] ASC, [DataFactoryKey] ASC, [ContainerExecutionGroupKey] ASC, [ExecutionGroupKey] ASC, [ContainerActivityTypeKey] ASC, [ContainerOrder] ASC)
);

