﻿CREATE TABLE [dbo].[CopyActivityExcelSpreadSheets] (
    [ID]                   INT           NOT NULL,
    [ExcelName]            NVARCHAR (50) NULL,
    [ExcelSpreadsheetName] NVARCHAR (50) NULL,
    [IsActive]             INT           NOT NULL,
    CONSTRAINT [PK_ExcelSpreadSheets] PRIMARY KEY CLUSTERED ([ID] ASC)
);

