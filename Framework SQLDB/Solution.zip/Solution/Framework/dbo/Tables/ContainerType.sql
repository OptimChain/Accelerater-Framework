﻿CREATE TABLE [dbo].[ContainerType](
	[ContainerTypeKey] INT IDENTITY(1,1) NOT NULL,
	[ContainerTypeName] [varchar](255) NOT NULL,
	[ContainerTypeDate] datetime NULL,
	[ContainerTypeCreatedBy] [varchar](255) NULL,
	[CreatedDate] datetime NOT NULL,
	[ModifiedDate] datetime NULL,
 CONSTRAINT [PKcg] PRIMARY KEY CLUSTERED 
(
	[ContainerTypeKey] ASC
))
GO