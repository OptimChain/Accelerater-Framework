CREATE TABLE [dbo].[CopyActivityDataFileSystem] (
    [CopyActivityDataFileSystemKey]        INT            IDENTITY (1, 1) NOT NULL,
    [CopyActivityDataFileSystemName]       VARCHAR (100)  NULL,
    [CopyActivityDataFileSystemFolderPath] VARCHAR (1000) NULL,
    [CopyActivityDataFileSystemFileName]   VARCHAR (100)  NULL,
    [IsActive]                             BIT            NULL,
    [LastRunDate]                          DATETIME2 (7)  NULL,
    [CreateDate]                           DATE           NULL,
    [ModifiedDate]                         DATE           NULL,
    [ModifiedUser]                         VARCHAR (100)  NULL,
    CONSTRAINT [PKCopyActivityDataFileSystemKey] PRIMARY KEY CLUSTERED ([CopyActivityDataFileSystemKey] ASC)
);





GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_CopyActivityDataFileSystem]
    ON [dbo].[CopyActivityDataFileSystem]([CopyActivityDataFileSystemName] ASC);

