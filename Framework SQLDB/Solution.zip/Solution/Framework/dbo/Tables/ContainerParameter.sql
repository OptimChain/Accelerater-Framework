﻿CREATE TABLE [dbo].[ContainerParameter] (
    [ContainerParameterKey]   INT           IDENTITY (1, 1) NOT NULL,
	[ContainerKey]			  INT NOT NULL,
    [ContainerParameterName]  VARCHAR (50)  NOT NULL,
    [ContainerParameterValue] VARCHAR (100) NOT NULL,
    [CreatedDate]          DATETIME      NOT NULL,
    [ModifiedDate]         DATETIME      NULL,
    CONSTRAINT [PK_ContainerParameter] PRIMARY KEY CLUSTERED ([ContainerParameterKey] ASC)
);

