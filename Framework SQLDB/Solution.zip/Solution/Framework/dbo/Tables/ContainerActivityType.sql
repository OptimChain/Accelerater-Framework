﻿CREATE TABLE [dbo].[ContainerActivityType] (
    [ContainerActivityTypeKey]  INT          IDENTITY (1, 1) NOT NULL,
    [ContainerActivityTypeName] VARCHAR (20) NOT NULL,
    [CreatedDate]         DATETIME     NOT NULL,
    [ModifiedDate]        DATETIME     NULL,
    CONSTRAINT [PKsgt] PRIMARY KEY CLUSTERED ([ContainerActivityTypeKey] ASC)
);

