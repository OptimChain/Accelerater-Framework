﻿CREATE TABLE [dbo].[CopyActivityDataADLS_Staging] (
    [SQL Script To Merge] NVARCHAR (MAX) NULL
);

