﻿DELETE FROM dbo.PipeLineExecutionPlan
WHERE DataFactoryKey in(select DataFactoryKey from DataFactory where DataFactoryName = 'am-da-env-adf-01')
GO

INSERT INTO dbo.PipeLineExecutionPlan
SELECT p.PipeLineKey, peg.PipeLineExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM PipeLine p, DataFactory d, Container pr
	 ,PipeLineExecutionGroup peg
		--ON peg.PipeLineExecutionGroupName = 'masterDatabricks'  -- PipeLine Execution Group
WHERE peg.PipeLineExecutionGroupName = 'Prism'  and p.PipelineName like 'Prism%'
	AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL 
SELECT p.PipeLineKey, peg.PipeLineExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM PipeLine p, DataFactory d, Container pr
	 ,PipeLineExecutionGroup peg
		--ON peg.PipeLineExecutionGroupName = 'masterDatabricks'  -- PipeLine Execution Group
WHERE peg.PipeLineExecutionGroupName = 'Coms'  and p.PipelineName like 'Coms%'
	AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Coms'
UNION ALL
SELECT p.PipeLineKey, peg.PipeLineExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM PipeLine p, DataFactory d, Container pr
	 ,PipeLineExecutionGroup peg
		--ON peg.PipeLineExecutionGroupName = 'masterDatabricks'  -- PipeLine Execution Group
WHERE peg.PipeLineExecutionGroupName = 'GP'  and p.PipelineName like 'GP%'
	AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'GP'
 UNION ALL
SELECT p.PipeLineKey, peg.PipeLineExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM PipeLine p, DataFactory d, Container pr
	 ,PipeLineExecutionGroup peg
		--ON peg.PipeLineExecutionGroupName = 'masterDatabricks'  -- PipeLine Execution Group
WHERE peg.PipeLineExecutionGroupName = 'Medb'  and p.PipelineName like 'Medb%'
	AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Medb'
UNION ALL
SELECT p.PipeLineKey, peg.PipeLineExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM PipeLine p, DataFactory d, Container pr
	 ,PipeLineExecutionGroup peg
		--ON peg.PipeLineExecutionGroupName = 'masterDatabricks'  -- PipeLine Execution Group
WHERE peg.PipeLineExecutionGroupName = 'Workday'  and p.PipelineName like 'Workday%'
	AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Workday'
Order by p.PipeLineKey

GO
