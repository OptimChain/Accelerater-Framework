﻿




/*********************************************************************************************************************
	File: 	StoredProcedureExecutionPlan.data.sql

	Desc: 	Data hydration script.

	Auth: 	Joseph Barth
	Date: 	09/11/2018

	NOTE:	
         

	==================================================================================================================
    Change History
	==================================================================================================================
	Date		Author						Description
	----------- ---------------------------	--------------------------------------------------------------------------
	08/16/2018  Joseph Barth				Created.	
	09/18/2018	Alan Campbell				Added some new stored procedures that align better with other examples we
	                                        have in the Framework.
**********************************************************************************************************************/

-----------------------------------------------------------------------------------
-- Instead of MERGE, using these statements to add StoredProcedures to the Execution Plan
-- without having to lookup keys for StoredProcedure and StoredProcedureExecutionGroup.
-----------------------------------------------------------------------------------




DELETE FROM dbo.StoredProcedureExecutionPlan
WHERE DataFactoryKey in(select DataFactoryKey from DataFactory where DataFactoryName = 'am-da-env-adf-01')
GO


INSERT INTO dbo.StoredProcedureExecutionPlan

-- SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,0,1,0,1,GetDate(),NULL
--FROM StoredProcedure p, DataFactory d, Container pr
--  INNER JOIN StoredProcedureExecutionGroup peg
--  ON peg.StoredProcedureExecutionGroupName = 'dbo' 
--WHERE p.StoredProcedureName = 'dbo.uspDimCompany'  
-- AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'dbo'
--UNION ALL
-- SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,0,1,0,1,GetDate(),NULL
--FROM StoredProcedure p, DataFactory d, Container pr
--  INNER JOIN StoredProcedureExecutionGroup peg
--  ON peg.StoredProcedureExecutionGroupName = 'dbo' 
--WHERE p.StoredProcedureName = 'dbo.uspDimDate'  
-- AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'dbo'
--UNION ALL
-- SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,0,1,0,1,GetDate(),NULL
--FROM StoredProcedure p, DataFactory d, Container pr
--  INNER JOIN StoredProcedureExecutionGroup peg
--  ON peg.StoredProcedureExecutionGroupName = 'dbo' 
--WHERE p.StoredProcedureName = 'dbo.uspDimState'  
-- AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'dbo'
--UNION ALL
-- SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,0,1,0,1,GetDate(),NULL
--FROM StoredProcedure p, DataFactory d, Container pr
--  INNER JOIN StoredProcedureExecutionGroup peg
--  ON peg.StoredProcedureExecutionGroupName = 'dbo' 
--WHERE p.StoredProcedureName = 'dbo.uspDimContainer'  
-- AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'dbo'
--UNION ALL
-- SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,0,1,0,1,GetDate(),NULL
--FROM StoredProcedure p, DataFactory d, Container pr
--  INNER JOIN StoredProcedureExecutionGroup peg
--  ON peg.StoredProcedureExecutionGroupName = 'dbo' 
--WHERE p.StoredProcedureName = 'dbo.uspDimEmployee'  
-- AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'dbo'
--UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'GP_DimA' 
WHERE p.StoredProcedureName = 'GPAmus.uspDimSite'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'GP'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,20,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Coms_DimA' 
WHERE p.StoredProcedureName = 'ComsMillsEntOps.uspDimCompanyLocation' 
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Coms'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,20,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Coms_DimB' 
WHERE p.StoredProcedureName = 'ComsMillsEntOps.uspDimBasis'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Coms'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_DimA' 
WHERE p.StoredProcedureName = 'PrismBinService.uspDimBin'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Coms_DimA' 
WHERE p.StoredProcedureName = 'ComsMillsEntOps.uspDimCommodityMarket'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Coms'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'GP_DimA' 
WHERE p.StoredProcedureName = 'GPAmus.uspDimCustomer'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'GP'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_DimA' 
WHERE p.StoredProcedureName = 'PrismPackFactorService.uspDimGrainType'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_DimA' 
WHERE p.StoredProcedureName = 'PrismDowntimeService.uspDimMillDowntimeReason'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_DimA' 
WHERE p.StoredProcedureName = 'PrismMillingMasterDataService.uspDimMillUnit'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_DimA' 
WHERE p.StoredProcedureName = 'PrismDowntimeService.uspDimPackDowntimeReason'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,20,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_DimB' 
WHERE p.StoredProcedureName = 'PrismPackMasterDataService.uspDimPackLine'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,20,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_DimB' 
WHERE p.StoredProcedureName = 'PrismQualityService.uspDimSifter'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_DimA' 
WHERE p.StoredProcedureName = 'PrismGrainMixService.uspDimGrainMixBlend'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'GP_DimA' 
WHERE p.StoredProcedureName = 'GPAmus.uspDimVendor'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'GP'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_DimA' 
WHERE p.StoredProcedureName = 'PrismMaterialService.uspDimUnitOfMeasureSchedule'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,20,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_DimB' 
WHERE p.StoredProcedureName = 'PrismGrainMixService.uspDimGrainMix'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,20,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_DimB' 
WHERE p.StoredProcedureName = 'PrismPackFactorService.uspDimGrainPackFactor'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,20,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'GP_DimB' 
WHERE p.StoredProcedureName = 'GPAmus.uspDimCustomerAddress'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'GP'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,20,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Coms_DimC' 
WHERE p.StoredProcedureName = 'ComsMillsEntOps.uspDimItemFeedXref'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Coms'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,20,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Coms_DimC' 
WHERE p.StoredProcedureName = 'ComsMillsEntOps.uspDimItemMixXref'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Coms'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,20,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_DimB' 
WHERE p.StoredProcedureName = 'PrismMillingMasterDataService.uspDimMillUnitTarget'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,20,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_DimB' 
WHERE p.StoredProcedureName = 'PrismMaterialService.uspDimUnitOfMeasureConversion'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,20,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'GP_DimB' 
WHERE p.StoredProcedureName = 'GPAmus.uspDimVendorAddress'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'GP'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,20,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_DimB' 
WHERE p.StoredProcedureName = 'PrismMaterialService.uspDimItem'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
 UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,20,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Coms_DimC' 
WHERE p.StoredProcedureName = 'PrismMaterialService.uspDimItem'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Coms'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,20,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_DimB' 
WHERE p.StoredProcedureName = 'PrismGrainMixService.uspDimGrainMixBlendComponent'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,30,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Coms_FactA' 
WHERE p.StoredProcedureName = 'ComsMillsEntOps.uspFactItemMix'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Coms'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,30,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_FactA' 
WHERE p.StoredProcedureName = 'PrismPackingService.uspFactLot'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,30,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Coms_FactA' 
WHERE p.StoredProcedureName = 'ComsMillsEntOps.uspFactMarkToMarket'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Coms'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,30,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Coms_FactA' 
WHERE p.StoredProcedureName = 'ComsMillsEntOps.uspFactMarkToMarketRange'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Coms'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,30,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_FactA' 
WHERE p.StoredProcedureName = 'PrismProductionRunService.uspFactMillProductionRun'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,30,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_FactA' 
WHERE p.StoredProcedureName = 'PrismProductionRunService.uspFactMillProductionQualitySample'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,30,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_FactA' 
WHERE p.StoredProcedureName = 'PrismSchedulingService.uspFactMillUnitSchedule'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,30,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_FactA' 
WHERE p.StoredProcedureName = 'PrismOrderService.uspFactOrder'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,30,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_FactA' 
WHERE p.StoredProcedureName = 'PrismTemperTransferService.uspFactTemperTransferProductionRun'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,40,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_FactB' 
WHERE p.StoredProcedureName = 'PrismPackingService.uspFactPackProductionRun'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,40,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_FactB' 
WHERE p.StoredProcedureName = 'PrismProductionRunService.uspFactMillProductionTemperBin'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,40,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_FactB' 
WHERE p.StoredProcedureName = 'PrismProductionRunService.uspFactMillProductionTemperTransfer'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,40,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_FactB' 
WHERE p.StoredProcedureName = 'PrismProductionRunService.uspFactMillProductionQualityReading'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,40,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_FactB' 
WHERE p.StoredProcedureName = 'PrismProductionRunService.uspFactMillProductionBin'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,40,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_FactB' 
WHERE p.StoredProcedureName = 'PrismProductionRunService.uspFactMillProductionDowntime'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,40,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_FactB' 
WHERE p.StoredProcedureName = 'PrismShippingService.uspFactLoadOut'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,40,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_FactB' 
WHERE p.StoredProcedureName = 'PrismShippingService.uspFactLoadOutProduct'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,40,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_FactB' 
WHERE p.StoredProcedureName = 'PrismSchedulingService.uspFactBulkSchedule'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,40,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_FactB' 
WHERE p.StoredProcedureName = 'PrismTemperTransferService.uspFactTemperTransferProductionBin'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,40,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_FactB' 
WHERE p.StoredProcedureName = 'PrismTemperTransferService.uspFactTemperTransferProductionSample'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,40,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_FactB' 
WHERE p.StoredProcedureName = 'PrismShippingService.uspFactLoadOutSeal'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,40,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_FactB' 
WHERE p.StoredProcedureName = 'PrismQualityService.uspFactTailings'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,50,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_FactC' 
WHERE p.StoredProcedureName = 'PrismQualityService.uspFactCOA'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,50,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_FactC' 
WHERE p.StoredProcedureName = 'PrismPackingService.uspFactEmptyBagLotTracking'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,50,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_FactC' 
WHERE p.StoredProcedureName = 'PrismShippingService.uspFactLoadOutProductLot'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,50,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_FactC' 
WHERE p.StoredProcedureName = 'PrismPackingService.uspFactPackProductionDowntime'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,50,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_FactC' 
WHERE p.StoredProcedureName = 'PrismPackingService.uspFactPackProductionBin'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,50,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Prism_FactC' 
WHERE p.StoredProcedureName = 'PrismSchedulingService.uspFactPackSchedule'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Prism'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,30,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Coms_FactA' 
WHERE p.StoredProcedureName = 'ComsMillsEntOps.uspFactFuturesFreight'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Coms'
UNION ALL
 SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,30,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
  INNER JOIN StoredProcedureExecutionGroup peg
  ON peg.StoredProcedureExecutionGroupName = 'Coms_FactA' 
WHERE p.StoredProcedureName = 'ComsMillsEntOps.uspFactFutures'  
 AND d.DataFactoryName = 'am-da-env-adf-01' and pr.ContainerName = 'Coms'
GO



