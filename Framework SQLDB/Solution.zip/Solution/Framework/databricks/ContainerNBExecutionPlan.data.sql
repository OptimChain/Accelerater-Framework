

/*********************************************************************************************************************
	File: 	SystemNBExecutionPlan.data.sql

	Desc: 	Data hydration script.

	Auth: 	Joseph Barth
	Date: 	01/17/2019

	NOTE:	
         

	==================================================================================================================
    Change History
	==================================================================================================================
	Date		Author						Description
	----------- ---------------------------	--------------------------------------------------------------------------
	10/26/2018  Joseph Barth				Created.	
	06/11/2019	Mike Sherrill				Modified for CLA Containers
**********************************************************************************************************************/

-----------------------------------------------------------------------------------
-- Instead of MERGE, using these statements to add SystemExecutionPlans to the Execution Plan
-- without having to lookup keys for System and SystemExecutionGroup.
-----------------------------------------------------------------------------------
DECLARE @DataFactoryName			as varchar(50) = 'am-da-env-adf-01'
DECLARE @SystemGroupTypeName        as varchar(50) = 'Notebook'

Delete se from dbo.SystemExecutionPlan se
inner join  [SystemExecutionGroup] seg on se.SystemExecutionGroupKey=seg.SystemExecutionGroupKey
where seg.SystemExecutionGroupName like '%Stage Process%'
  
INSERT INTO dbo.SystemExecutionPlan
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'Prism BinServiceStage'  -- CopyActivitySink Execution Group 
	AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'Prism'
	AND seg.SystemExecutionGroupName = 'Prism Stage Process'
	AND sgt.SystemGroupTypeName = @SystemGroupTypeName
UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'Prism DocumentServiceStage'  -- CopyActivitySink Execution Group 
	AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'Prism'
	AND seg.SystemExecutionGroupName = 'Prism Stage Process'
	AND sgt.SystemGroupTypeName = @SystemGroupTypeName
UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'Prism DowntimeServiceStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'Prism'
 AND seg.SystemExecutionGroupName = 'Prism Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName 
 UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'Prism GrainInventoryServiceStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'Prism'
 AND seg.SystemExecutionGroupName = 'Prism Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName 
 UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'Prism GrainMixServiceStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'Prism'
 AND seg.SystemExecutionGroupName = 'Prism Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName 
 UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'Prism GrainReceiptServiceStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'Prism'
 AND seg.SystemExecutionGroupName = 'Prism Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName 
 UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'Prism GrainTransferServiceStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'Prism'
 AND seg.SystemExecutionGroupName = 'Prism Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName 
 UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'Prism LocationServiceStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'Prism'
 AND seg.SystemExecutionGroupName = 'Prism Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName 
 UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'Prism MaterialServiceStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'Prism'
 AND seg.SystemExecutionGroupName = 'Prism Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName 
 UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'Prism MillingBinInventoryServiceStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'Prism'
 AND seg.SystemExecutionGroupName = 'Prism Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName 
 UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'Prism MillingMasterDataServiceStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'Prism'
 AND seg.SystemExecutionGroupName = 'Prism Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName 
 UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'Prism OrderServiceStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'Prism'
 AND seg.SystemExecutionGroupName = 'Prism Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName 
 UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'Prism PackFactorServiceStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'Prism'
 AND seg.SystemExecutionGroupName = 'Prism Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName 
 UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'Prism PackingServiceStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'Prism'
 AND seg.SystemExecutionGroupName = 'Prism Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName 
 UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'Prism PackMasterDataServiceStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'Prism'
 AND seg.SystemExecutionGroupName = 'Prism Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName 
 UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'Prism PersonnelAndContactServiceStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'Prism'
 AND seg.SystemExecutionGroupName = 'Prism Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName 
 UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'Prism ProductionRunServiceStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'Prism'
 AND seg.SystemExecutionGroupName = 'Prism Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName 
 UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'Prism QualityServiceStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'Prism'
 AND seg.SystemExecutionGroupName = 'Prism Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName 
 UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'Prism SchedulingServiceStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'Prism'
 AND seg.SystemExecutionGroupName = 'Prism Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName 
 UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'Prism ShippingMasterDataServiceStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'Prism'
 AND seg.SystemExecutionGroupName = 'Prism Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName 
 UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'Prism ShippingServiceStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'Prism'
 AND seg.SystemExecutionGroupName = 'Prism Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName 
 UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'Prism TemperTransferServiceStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'Prism'
 AND seg.SystemExecutionGroupName = 'Prism Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName 
 UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'Coms MillsEntOpsStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'Coms'
 AND seg.SystemExecutionGroupName = 'Coms Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName
  UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'GP AmusStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'GP'
 AND seg.SystemExecutionGroupName = 'GP Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName 
 UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'GP AmcanStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'GP'
 AND seg.SystemExecutionGroupName = 'GP Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName 
 UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'GP CcgStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'GP'
 AND seg.SystemExecutionGroupName = 'GP Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName 
 UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'GP MolprStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'GP'
 AND seg.SystemExecutionGroupName = 'GP Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName 
 UNION ALL
SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'GP MriceStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'GP'
 AND seg.SystemExecutionGroupName = 'GP Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName 

 UNION ALL

 SELECT pr.SystemKey,d.DataFactoryKey,seg.SystemExecutionGroupKey, neg.NotebookExecutionGroupKey,sgt.[SystemGroupTypeKey],10,1,0,1,GetDate(),NULL
FROM NotebookExecutionGroup neg,DataFactory d, System pr,SystemGroupType sgt,[SystemExecutionGroup] seg
WHERE neg.NotebookExecutionGroupName = 'Medb MedbStage'  
 AND d.DataFactoryName = @DataFactoryName and pr.SystemName = 'Medb'
 AND seg.SystemExecutionGroupName = 'Medb Stage Process'
 AND sgt.SystemGroupTypeName = @SystemGroupTypeName 
 



GO