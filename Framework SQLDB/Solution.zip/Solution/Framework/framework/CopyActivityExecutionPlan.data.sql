﻿--/*********************************************************************************************************************
--	File: 	CopyActivityExecutionPlan.data.sql

--	Desc: 	Data hydration script.

--	Auth: 	Joseph Barth
--	Date: 	08/07/2018

--	NOTE:	
         

--	==================================================================================================================
--    Change History
--	==================================================================================================================
--	Date		Author						Description
--	----------- ---------------------------	--------------------------------------------------------------------------
--	08/07/2018  Joseph Barth				Created.			
--**********************************************************************************************************************/

-------------------------------------------------------------------------------------
---- Instead of MERGE, using these statements to add CopyActivitys to the Execution Plan
---- without having to lookup keys for CopyActivitySink and CopyActivityExecutionGroup.
-------------------------------------------------------------------------------------
DECLARE @DataFactoryName			as varchar(50) = 'neu-pe-fwk-df-01'

DELETE FROM dbo.CopyActivityExecutionPlan 
WHERE DataFactoryKey in(select DataFactoryKey from DataFactory where DataFactoryName = @DataFactoryName)
and ContainerKey in (select ContainerKey from Container where ContainerName = 'Retail')


--INSERT INTO dbo.CopyActivityExecutionPlan
--SELECT p.[CopyActivitySinkKey], peg.CopyActivityExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
--FROM CopyActivitySink p, DataFactory d, Container pr
--	 INNER JOIN CopyActivityExecutionGroup peg
--		ON peg.CopyActivityExecutionGroupName = 'Sales IT Group Dim'  -- CopyActivitySink Execution Group
--WHERE p.[CopyActivitySinkName] = 'SQL Load saleslt_Store'  -- CopyActivitySink Name
--	 AND d.DataFactoryName = 'adfFramework' and pr.ContainerName = 'Framework'
--UNION ALL
--SELECT p.[CopyActivitySinkKey], peg.CopyActivityExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
--FROM CopyActivitySink p, DataFactory d, Container pr
--	 INNER JOIN CopyActivityExecutionGroup peg
--		ON peg.CopyActivityExecutionGroupName = 'Sales IT Group Dim'  -- CopyActivitySink Execution Group
--WHERE p.[CopyActivitySinkName] = 'SQL Load saleslt_customer'  -- CopyActivitySink Name
--	 AND d.DataFactoryName = 'adfFramework' and pr.ContainerName = 'Framework'
--UNION ALL
--SELECT p.[CopyActivitySinkKey], peg.CopyActivityExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
--FROM CopyActivitySink p, DataFactory d, Container pr
--	 INNER JOIN CopyActivityExecutionGroup peg
--		ON peg.CopyActivityExecutionGroupName = 'Sales IT Group Dim'  -- CopyActivitySink Execution Group
--WHERE p.[CopyActivitySinkName] = 'SQL Load saleslt_product'  -- CopyActivitySink Name
--	 AND d.DataFactoryName = 'adfFramework' and pr.ContainerName = 'Framework'
--UNION ALL
--SELECT p.[CopyActivitySinkKey], peg.CopyActivityExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
--FROM CopyActivitySink p, DataFactory d, Container pr
--	 INNER JOIN CopyActivityExecutionGroup peg
--		ON peg.CopyActivityExecutionGroupName = 'Sales IT Group Fact'  -- CopyActivitySink Execution Group
--WHERE p.[CopyActivitySinkName] = 'SQL Load saleslt_order'  -- CopyActivitySink Name
--	 AND d.DataFactoryName = 'adfFramework' and pr.ContainerName = 'Framework'
--GO


 INSERT INTO dbo.CopyActivityExecutionPlan
  SELECT p.[CopyActivitySinkKey], peg.CopyActivityExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL 
  FROM CopyActivitySink p, DataFactory d, Container pr 
    INNER JOIN CopyActivityExecutionGroup peg 
    ON peg.CopyActivityExecutionGroupName = 'Retail'  -- CopyActivitySink Execution Group 
  WHERE p.[CopyActivitySinkName] = 'Retail_Store'  -- CopyActivitySink Name 
    AND d.DataFactoryName = @DataFactoryName and pr.ContainerName = 'Retail'
UNION ALL 
  SELECT p.[CopyActivitySinkKey], peg.CopyActivityExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL 
  FROM CopyActivitySink p, DataFactory d, Container pr 
    INNER JOIN CopyActivityExecutionGroup peg 
    ON peg.CopyActivityExecutionGroupName = 'Retail'  -- CopyActivitySink Execution Group 
  WHERE p.[CopyActivitySinkName] = 'Retail_Product'  -- CopyActivitySink Name 
    AND d.DataFactoryName = @DataFactoryName and pr.ContainerName = 'Retail'
UNION ALL 
  SELECT p.[CopyActivitySinkKey], peg.CopyActivityExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL 
  FROM CopyActivitySink p, DataFactory d, Container pr 
    INNER JOIN CopyActivityExecutionGroup peg 
    ON peg.CopyActivityExecutionGroupName = 'Retail'  -- CopyActivitySink Execution Group 
  WHERE p.[CopyActivitySinkName] = 'Retail_Customer'  -- CopyActivitySink Name 
    AND d.DataFactoryName = @DataFactoryName and pr.ContainerName = 'Retail'
UNION ALL 
  SELECT p.[CopyActivitySinkKey], peg.CopyActivityExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL 
  FROM CopyActivitySink p, DataFactory d, Container pr 
    INNER JOIN CopyActivityExecutionGroup peg 
    ON peg.CopyActivityExecutionGroupName = 'Retail'  -- CopyActivitySink Execution Group 
  WHERE p.[CopyActivitySinkName] = 'Retail_Sales'  -- CopyActivitySink Name 
    AND d.DataFactoryName = @DataFactoryName and pr.ContainerName = 'Retail'

GO