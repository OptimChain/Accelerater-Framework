﻿/*********************************************************************************************************************
	File: 	StoredProcedureExecutionPlan.data.sql

	Desc: 	Data hydration script.

	Auth: 	Joseph Barth
	Date: 	09/11/2018

	NOTE:	
         

	==================================================================================================================
    Change History
	==================================================================================================================
	Date		Author						Description
	----------- ---------------------------	--------------------------------------------------------------------------
	08/16/2018  Joseph Barth				Created.	
	09/18/2018	Alan Campbell				Added some new stored procedures that align better with other examples we
	                                        have in the Framework.
**********************************************************************************************************************/

-----------------------------------------------------------------------------------
-- Instead of MERGE, using these statements to add StoredProcedures to the Execution Plan
-- without having to lookup keys for StoredProcedure and StoredProcedureExecutionGroup.
-----------------------------------------------------------------------------------

DELETE FROM dbo.StoredProcedureExecutionPlan
WHERE DataFactoryKey in(select DataFactoryKey from DataFactory where DataFactoryName = 'adfFramework')
and ContainerKey in (select ContainerKey from Container where ContainerName = 'Framework')
GO


INSERT INTO dbo.StoredProcedureExecutionPlan
SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
	 INNER JOIN StoredProcedureExecutionGroup peg
		ON peg.StoredProcedureExecutionGroupName = 'dim external load'  -- StoredProcedure Execution Group
WHERE p.StoredProcedureName = 'uspImportExternalTableCustomer'  -- StoredProcedure Name
	AND d.DataFactoryName = 'adfFramework' and pr.ContainerName = 'Framework'
UNION
SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
	 INNER JOIN StoredProcedureExecutionGroup peg
		ON peg.StoredProcedureExecutionGroupName = 'dim external load'  -- StoredProcedure Execution Group
WHERE p.StoredProcedureName = 'uspImportExternalTableProduct'  -- StoredProcedure Name
	AND d.DataFactoryName = 'adfFramework' and pr.ContainerName = 'Framework'
UNION
SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
	 INNER JOIN StoredProcedureExecutionGroup peg
		ON peg.StoredProcedureExecutionGroupName = 'dim external load'  -- StoredProcedure Execution Group
WHERE p.StoredProcedureName = 'uspImportExternalTableStore'  -- StoredProcedure Name
	AND d.DataFactoryName = 'adfFramework' and pr.ContainerName = 'Framework'
UNION
SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
	 INNER JOIN StoredProcedureExecutionGroup peg
		ON peg.StoredProcedureExecutionGroupName = 'fact external load'  -- StoredProcedure Execution Group
WHERE p.StoredProcedureName = 'uspImportExternalTableOrders'  -- StoredProcedure Name
	AND d.DataFactoryName = 'adfFramework' and pr.ContainerName = 'Framework'
GO

INSERT INTO dbo.StoredProcedureExecutionPlan
SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
	 INNER JOIN StoredProcedureExecutionGroup peg
		ON peg.StoredProcedureExecutionGroupName = 'External A'  -- StoredProcedure Execution Group
WHERE p.StoredProcedureName = 'Retail.uspCreateExternalTables'  -- StoredProcedure Name
	AND d.DataFactoryName = 'adfFramework' and pr.ContainerName = 'Framework'
UNION
SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
	 INNER JOIN StoredProcedureExecutionGroup peg
		ON peg.StoredProcedureExecutionGroupName = 'Staging A'  -- StoredProcedure Execution Group
WHERE p.StoredProcedureName = 'Retail.uspCreateStagingFromExternalTables'  -- StoredProcedure Name
	AND d.DataFactoryName = 'adfFramework' and pr.ContainerName = 'Framework'
UNION
SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
	 INNER JOIN StoredProcedureExecutionGroup peg
		ON peg.StoredProcedureExecutionGroupName = 'Dimension A'  -- StoredProcedure Execution Group
WHERE p.StoredProcedureName = 'Retail.uspDimCustomer'  -- StoredProcedure Name
	AND d.DataFactoryName = 'adfFramework' and pr.ContainerName = 'Framework'
UNION
SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
	 INNER JOIN StoredProcedureExecutionGroup peg
		ON peg.StoredProcedureExecutionGroupName = 'Dimension A'  -- StoredProcedure Execution Group
WHERE p.StoredProcedureName = 'Retail.uspDimProduct'  -- StoredProcedure Name
	AND d.DataFactoryName = 'adfFramework' and pr.ContainerName = 'Framework'
UNION
SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
	 INNER JOIN StoredProcedureExecutionGroup peg
		ON peg.StoredProcedureExecutionGroupName = 'Dimension A'  -- StoredProcedure Execution Group
WHERE p.StoredProcedureName = 'Retail.uspDimStore'  -- StoredProcedure Name
	AND d.DataFactoryName = 'adfFramework' and pr.ContainerName = 'Framework'
UNION
SELECT p.StoredProcedureKey, peg.StoredProcedureExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM StoredProcedure p, DataFactory d, Container pr
	 INNER JOIN StoredProcedureExecutionGroup peg
		ON peg.StoredProcedureExecutionGroupName = 'Fact A'  -- StoredProcedure Execution Group
WHERE p.StoredProcedureName = 'Retail.uspFactSales'  -- StoredProcedure Name
	AND d.DataFactoryName = 'adfFramework' and pr.ContainerName = 'Framework'
GO
