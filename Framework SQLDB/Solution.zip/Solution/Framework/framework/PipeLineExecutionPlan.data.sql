﻿
DELETE FROM dbo.PipeLineExecutionPlan
WHERE DataFactoryKey in(select DataFactoryKey from DataFactory where DataFactoryName = 'neu-pe-fwk-df-01')
and ContainerKey in (select ContainerKey from Container where ContainerName = 'Retail')
GO

INSERT INTO dbo.PipeLineExecutionPlan
SELECT p.PipeLineKey, peg.PipeLineExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
FROM PipeLine p, DataFactory d, Container pr
	 INNER JOIN PipeLineExecutionGroup peg
		ON peg.PipeLineExecutionGroupName = 'Retail'  -- PipeLine Execution Group
WHERE p.PipeLineName = 'RetailCopy'  -- PipeLine Name
	AND d.DataFactoryName = 'neu-pe-fwk-df-01' and pr.ContainerName = 'Retail'
--UNION ALL
--SELECT p.PipeLineKey, peg.PipeLineExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
--FROM PipeLine p, DataFactory d, Container pr
--	 INNER JOIN PipeLineExecutionGroup peg
--		ON peg.PipeLineExecutionGroupName = 'neuMaster'  -- PipeLine Execution Group
--WHERE p.PipeLineName = 'neuStgFact'  -- PipeLine Name
--	AND d.DataFactoryName = 'adfFramework' and pr.ContainerName = 'Framework'
--UNION ALL
--SELECT p.PipeLineKey, peg.PipeLineExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
--FROM PipeLine p, DataFactory d, Container pr
--	 INNER JOIN PipeLineExecutionGroup peg
--		ON peg.PipeLineExecutionGroupName = 'neuMaster'  -- PipeLine Execution Group
--WHERE p.PipeLineName = 'neuDimension'  -- PipeLine Name
--	AND d.DataFactoryName = 'adfFramework' and pr.ContainerName = 'Framework'
--UNION ALL

--SELECT p.PipeLineKey, peg.PipeLineExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL
--FROM PipeLine p, DataFactory d, Container pr
--	 INNER JOIN PipeLineExecutionGroup peg
--		ON peg.PipeLineExecutionGroupName = 'neuMaster'  -- PipeLine Execution Group
--WHERE p.PipeLineName = 'neuFact'  -- PipeLine Name
--	AND d.DataFactoryName = 'adfFramework' and pr.ContainerName = 'Framework'


GO