﻿


/*********************************************************************************************************************
	File: 	ContainerCAExecutionPlan.data.sql

	Desc: 	Data hydration script.

	Auth: 	Joseph Barth
	Date: 	01/17/2019

	NOTE:	
         

	==================================================================================================================
    Change History
	==================================================================================================================
	Date		Author						Description
	----------- ---------------------------	--------------------------------------------------------------------------
	10/26/2018  Joseph Barth				Created.	
	06/11/2019	Mike Sherrill				Modified for CLA Containers
**********************************************************************************************************************/

-----------------------------------------------------------------------------------
-- Instead of MERGE, using these statements to add ContainerExecutionPlans to the Execution Plan
-- without having to lookup keys for Container and ContainerExecutionGroup.
-----------------------------------------------------------------------------------

DECLARE @DataFactoryName			as varchar(50) = 'neu-pe-fwk-df-01'
DECLARE @ContainerActivityTypeName        as varchar(50) = 'CopyActivity'

Delete se from dbo.ContainerExecutionPlan se
inner join  [ContainerExecutionGroup] seg on se.ContainerExecutionGroupKey=seg.ContainerExecutionGroupKey
where seg.ContainerExecutionGroupName like '%Copy Process%'
  

INSERT INTO dbo.ContainerExecutionPlan
SELECT pr.ContainerKey,d.DataFactoryKey,seg.ContainerExecutionGroupKey, peg.CopyActivityExecutionGroupKey,sgt.[ContainerTypeKey],10,1,0,1,GetDate(),NULL
FROM CopyActivityExecutionGroup peg,DataFactory d, Container pr,ContainerType sgt,[ContainerExecutionGroup] seg
WHERE peg.CopyActivityExecutionGroupName = 'Retail'  -- CopyActivitySink Execution Group 
	AND d.DataFactoryName = @DataFactoryName and pr.ContainerName = 'Retail'
	AND seg.ContainerExecutionGroupName = 'Retail Copy Process'
	AND sgt.ContainerActivityTypeName = @ContainerActivityTypeName



GO
