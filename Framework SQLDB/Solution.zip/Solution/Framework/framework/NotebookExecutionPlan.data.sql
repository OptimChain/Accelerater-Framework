﻿/*********************************************************************************************************************
	File: 	NotebookExecutionPlan.data.sql

	Desc: 	Data hydration script.

	Auth: 	Joseph Barth
	Date: 	09/11/2018

	NOTE:	
         

	==================================================================================================================
    Change History
	==================================================================================================================
	Date		Author						Description
	----------- ---------------------------	--------------------------------------------------------------------------
	10/26/2018  Joseph Barth				Created.	
**********************************************************************************************************************/

-----------------------------------------------------------------------------------
-- Instead of MERGE, using these statements to add Notebooks to the Execution Plan
-- without having to lookup keys for Notebook and NotebookExecutionGroup.
-----------------------------------------------------------------------------------


DELETE FROM dbo.NotebookExecutionPlan
WHERE DataFactoryKey IN (SELECT DataFactoryKey FROM DataFactory WHERE DataFactoryName = 'neu-pe-fwk-df-01')
  
INSERT INTO dbo.NotebookExecutionPlan
SELECT p.NotebookKey, peg.NotebookExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL  
  FROM Notebook p, DataFactory d, Container pr  
    INNER JOIN NotebookExecutionGroup peg  
    ON peg.NotebookExecutionGroupName = 'Retail'  -- Notebook Execution Group  
  WHERE p.NotebookName = 'Retail_Store'  -- Notebook Name  
   AND d.DataFactoryName = 'neu-pe-fwk-df-01' AND pr.ContainerName = 'Retail'  

UNION ALL 
   SELECT p.NotebookKey, peg.NotebookExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL  
  FROM Notebook p, DataFactory d, Container pr  
    INNER JOIN NotebookExecutionGroup peg  
    ON peg.NotebookExecutionGroupName = 'Retail'  -- Notebook Execution Group  
  WHERE p.NotebookName = 'Retail_Product'  -- Notebook Name  
   AND d.DataFactoryName = 'neu-pe-fwk-df-01' AND pr.ContainerName = 'Retail'  

UNION ALL 
   SELECT p.NotebookKey, peg.NotebookExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL  
  FROM Notebook p, DataFactory d, Container pr  
    INNER JOIN NotebookExecutionGroup peg  
    ON peg.NotebookExecutionGroupName = 'Retail'  -- Notebook Execution Group  
  WHERE p.NotebookName = 'Retail_Customer'  -- Notebook Name  
   AND d.DataFactoryName = 'neu-pe-fwk-df-01' AND pr.ContainerName = 'Retail'  

UNION ALL 
   SELECT p.NotebookKey, peg.NotebookExecutionGroupKey,d.DataFactoryKey,pr.ContainerKey,10,1,0,1,GetDate(),NULL  
  FROM Notebook p, DataFactory d, Container pr  
    INNER JOIN NotebookExecutionGroup peg  
    ON peg.NotebookExecutionGroupName = 'Retail'  -- Notebook Execution Group  
  WHERE p.NotebookName = 'Retail_Sales'  -- Notebook Name  
   AND d.DataFactoryName = 'neu-pe-fwk-df-01' AND pr.ContainerName = 'Retail'  

