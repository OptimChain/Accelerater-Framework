﻿CREATE USER [srvc-DADevDBDatawriter]
    WITH PASSWORD = N'geLxk,ec:b7rut8WVmkctxktmsFT7_&#$!~<Ppbbeyb`eYu|';

