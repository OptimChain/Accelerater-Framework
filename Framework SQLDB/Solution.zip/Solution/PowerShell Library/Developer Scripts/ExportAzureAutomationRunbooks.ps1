﻿#Connect-AzAccount
Set-AzContext -Subscriptionid "16a7664f-6f09-49b7-9a0e-16b261e08d19"
$AutomationAccountName = "da-dev-dc01-mgt-aa"
$ResourceGroupName = "da-dev-dc01-mgt-rg"
$OutputFolder = "C:\Users\mike.sherrill\Desktop\Deployment\AzureAutomationRunbooks\Da-Dev"

$AllRunbooks = Get-AzAutomationRunbook -AutomationAccountName $AutomationAccountName -ResourceGroupName $ResourceGroupName

$AllRunbooks | Export-AzAutomationRunbook -OutputFolder $OutputFolder