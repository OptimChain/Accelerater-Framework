﻿# Run the Install only once
#Install-Module azure.databricks.cicd.tools
Import-Module azure.databricks.cicd.tools
#Update-Module -Name azure.databricks.cicd.tools

$BearerToken = “dapi016749002d276e7abdaf9442768172ab“  #Dev Container
#$BearerToken = “dapib0ccfa6f18871dcfd341be20accec47b“  #Prd Container

$Region = "northcentralus"

Export-DatabricksFolder -BearerToken $BearerToken -Region $Region -LocalOutputPath 'C:\Users\mike.sherrill\source\repos\CLADataLakeFramework\notebooks\Container\Client000000001' -ExportPath '/Client000000001'

