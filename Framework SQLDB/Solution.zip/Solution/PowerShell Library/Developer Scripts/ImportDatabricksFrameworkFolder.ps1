﻿# Run the Install only once
# Install-Module azure.databricks.cicd.tools
Import-Module azure.databricks.cicd.tools

$BearerToken = “dapifad13efc9f8a949b0c0ad13d932c3989“  #Dev Framework
$BearerToken = “dapic34cf676e9230f594fae88a6a79bd6fa“  #Prd Framework

$Region = "northcentralus"

Import-DatabricksFolder -BearerToken $BearerToken -Region $Region -LocalPath 'C:\Users\mike.sherrill\Downloads\FrameworkKT\Framework' -DatabricksPath '/Framework'

