﻿# Run the Install only once
#Install-Module azure.databricks.cicd.tools
Import-Module azure.databricks.cicd.tools
#Update-Module -Name azure.databricks.cicd.tools

$BearerToken = “dapi016749002d276e7abdaf9442768172ab“  #Prd Framework
$Region = "northcentralus"

Export-DatabricksFolder -BearerToken $BearerToken -Region $Region -LocalOutputPath 'C:\Users\mike.sherrill\Downloads\Notebooks\Client000000001' -ExportPath '/Client000000001'

