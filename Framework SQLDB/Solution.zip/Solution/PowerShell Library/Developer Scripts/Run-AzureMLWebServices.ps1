<#
	.DESCRIPTION
        Starts a job in Azure ML

    .NOTES
        AUTHOR: Ken Mears - Neudesic LLC
        LASTEDIT: April 25, 2017
#>
# Needs to be run on local development machine with a connection to the internet

Login-AzureRmAccount
Select-AzureRmSubscription -SubscriptionName "Neudesic Prod"

# Unblock the downloaded dll file so Windows can trust it.
Unblock-File .\AzureMLPS.dll
# import the PowerShell module into current session
Import-Module .\AzureMLPS.dll

Get-AmlWorkspace

$rgn = "neudesic-da-tst-wcu-mlw-rg" #Resource Group Name
$mlwsn = "neudesic-da-tst-wcu-mlw-pln" #ML Web Service Name

# POST Request URL for RRS Endpoint 'abc' on Web Service 'xyz'
$webSvcId = (Get-AmlWebService | where Name -eq '<ML Web Service Name>').Id
$ep = Get-AmlWebServiceEndpoint -WebServiceId $webSvcId -EndpointName 'default'
$postUrl =  $ep.ApiLocation + '/jobs?api-version=2.0'
# Base-64 encoded API key
$apiKey = $ep.PrimaryKey
# Invoke RRS Endpoint
Invoke-AmlWebServiceBESEndpoint -SubmitJobRequestUrl $postUrl -ApiKey $apiKey -JobConfigString '{"GolbalParameters": { "Random seed": 12345 }}'