﻿# Run the Install only once
# Install-Module azure.databricks.cicd.tools
Import-Module azure.databricks.cicd.tools

$BearerToken = “dapi4cbe10dfcf9863b0b622b90dc5ce76f1“  #Prd Framework
$Region = "northcentralus"

Import-DatabricksFolder -BearerToken $BearerToken -Region $Region -LocalPath 'C:\Users\mike.sherrill\Desktop\Deployment\FrameworkDatabricks\Framework' -DatabricksPath '/Framework'

