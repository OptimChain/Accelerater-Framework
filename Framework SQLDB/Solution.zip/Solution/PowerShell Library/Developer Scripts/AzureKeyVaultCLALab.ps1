﻿Connect-AzAccount
Set-AzContext -Subscriptionid "5a676e33-faa3-4131-9e4a-148bf3515d70"

$Environment = "Labs"
$EnvironmentPrefix = "lab"
$KeyVaultName = "it-sbx-dc01-labs-df-kv"
$KeyVaultName

function new-CLAKeyVaultSecret ($secretName, $secretValue)
{
    Set-AzKeyVaultSecret `
    -VaultName $KeyVaultName `
    -Name $secretName `
    -SecretValue (ConvertTo-SecureString -String $secretValue -AsPlainText -Force)
}

new-CLAKeyVaultSecret "ADLSName" "itsbxdc01labsdl"
new-CLAKeyVaultSecret "ADLSStorageAccountKey" "Q1C5tPPHupMbUlbgAvzCsU9LRA8KdDOZs8NHnKro1OOPBQB86ZvIRg2zKvzFZLrJHs2XAX1yU6nWj8y3qBs73g=="
new-CLAKeyVaultSecret "ADLSTenantId" "4aaa468e-93ba-4ee3-ab9f-6a247aa3ade0"

new-CLAKeyVaultSecret "SQLFrameworkConnectionString" "Server=tcp:it-sbx-dc01-labs-dbs.database.windows.net,1433;Initial Catalog=it-sbx-dc01-fw-db;Persist Security Info=False;User ID=da-labs;Password=AzureAnalytics@CLA!;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;"

new-CLAKeyVaultSecret "DatabricksFrameworkAdminToken" "dapic34cf676e9230f594fae88a6a79bd6fa"  
new-CLAKeyVaultSecret "DatabricksData001AdminToken" "dapi1e2f062d8e5ae6d12a059cf5481361c8"

