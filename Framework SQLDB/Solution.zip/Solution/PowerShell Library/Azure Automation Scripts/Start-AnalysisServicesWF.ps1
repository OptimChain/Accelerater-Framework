workflow Start-AnalysisServicesWF
{
    <#
        .DESCRIPTION
            Runbook to pause the neudesic project Analysis Services

        .NOTES
            AUTHOR: Chris Kurt - Neudesic LLC
            LASTEDIT: Apr 13, 2017
    #>

    Write-Output "Begin Start-AnalysisServicesWF"

    $connectionName = "AzureRunAsConnection"
    try
    {
        # Get the connection "AzureRunAsConnection "
        $servicePrincipalConnection=Get-AutomationConnection -Name $connectionName         

        "Logging in to Azure..."
        Add-AzureRmAccount `
            -ServicePrincipal `
            -TenantId $servicePrincipalConnection.TenantId `
            -ApplicationId $servicePrincipalConnection.ApplicationId `
            -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint 
    }
    catch {
        if (!$servicePrincipalConnection)
        {
            $ErrorMessage = "Connection $connectionName not found."
            throw $ErrorMessage
        } else{
            Write-Error -Message $_.Exception
            throw $_.Exception
        }
    }

    # Set Analysis Service variables
    $resourceGroupName = "neudesic-da-tst-eus2-sas-rg"
    $serverName = "neudesicdadeveus2sas"

    "***** Analysis Server settings"
    "Resource Group: " + $resourceGroupName
    "Server Name : " + $serverName

    # Display Analysis Service information
    "***** Display Analysis Services server information"
    $state=Get-AzureRmAnalysisServicesServer -ResourceGroupName $resourceGroupName -Name $serverName
    $AStates="Paused"
    Write-Output $state.state
    # Resume Analysis Service server
    "***** Resuming Analysis Services server"

    if (Get-AzureRmAnalysisServicesServer -ResourceGroupName $resourceGroupName -Name $serverName| Where -Property State -In $AStates){
        Resume-AzureRmAnalysisServicesServer -ResourceGroupName $resourceGroupName -Name $serverName
   
        Write-Output "Analysis Service Resumed"
    
    }
    else { Write-Output "Analysis Service is already Running"}

    Write-Output "End Start-AnalysisServicesWF"
}