workflow Run-Source2StagingParallelWF
{
    # To test from PowerShell client, uncomment the 2 rows below and provide subscription ID
    #Login-AzureRmAccount
    #Select-AzureRmSubscription -SubscriptionName "Neudesic Dev"

    Write-Output "Begin Run-Source2StagingParallelWF"

    $connectionName = "AzureRunAsConnection"
    try
    {
        # Get the connection "AzureRunAsConnection "
        $servicePrincipalConnection=Get-AutomationConnection -Name $connectionName         

        "Logging in to Azure..."
        Add-AzureRmAccount `
            -ServicePrincipal `
            -TenantId $servicePrincipalConnection.TenantId `
            -ApplicationId $servicePrincipalConnection.ApplicationId `
            -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint 
    }
    catch {
        if (!$servicePrincipalConnection)
        {
            $ErrorMessage = "Connection $connectionName not found."
            throw $ErrorMessage
        } else{
            Write-Error -Message $_.Exception
            throw $_.Exception
        }
    }
    
    "Running TCS 2 Staging Daily Incremental"

    $rgn = "neudesic-da-tst-wus-df-rg" #Resource Group Name
    $dfn = "neudesic-da-tst-wus-df" #Data Factory Name
    $pipelines = "SamplePipeline" #PipeLine Names
    Write-Output $rgn
    Write-Output $pipelines
    # Get data factory object
    If($df) {
        Write-Output "Connected to data factory $dfn in resource group $rgn."
    }
    # Create start/end DateTime (yesterday)
    $sdt = [System.DateTime]::Today.AddDays(-1) #Yesterday 12:00:00 AM
    $edt = [System.DateTime]::Today.AddSeconds(-1) #Yesterday 11:59:59 PM
    #$df = Get-AzureRmDataFactory -ResourceGroupName $rgn -Name $dfn
    
    ForEach -Parallel ($pipeline in $pipelines) { 
        # Pause pipeline
        $spr = Suspend-AzureRmDataFactoryPipeline -DataFactoryName $dfn -ResourceGroupName $rgn -Name $pipeline
        If($spr) {
            Write-Output "Pipeline $pipeline paused."
        }
        # Update active period to yesterday
        $apr = Set-AzureRmDataFactoryPipelineActivePeriod -DataFactoryName $dfn -ResourceGroupName $rgn -PipelineName $pipeline -StartDateTime $sdt -EndDateTime $edt
        If($apr) {
            Write-Output "Pipeline $pipeline of data factory $dfn updated with StartDateTime $sdt and EndDateTime $edt."
        }
        # Unpause pipeline
        $rpl = Resume-AzureRmDataFactoryPipeline -DataFactoryName $dfn -ResourceGroupName $rgn -Name $pipeline
        If($rpl) {
            Write-Output "Pipeline $pipeline resumed."
        }
    }

    Write-Output "End Run-Source2StagingParallelWF"
}