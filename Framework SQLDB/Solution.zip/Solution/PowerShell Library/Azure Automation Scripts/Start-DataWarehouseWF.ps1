workflow Start-DataWarehouseWF
{
    <#
    .DESCRIPTION
        Runbook to start the neudesic project Data Warehouse from a suspended (paused) state

    .NOTES
        AUTHOR: Chris Kurt - Neudesic LLC
        LASTEDIT: Apr 7, 2017
    #>

    $connectionName = "AzureRunAsConnection"
    try
    {
        # Get the connection "AzureRunAsConnection "
        $servicePrincipalConnection=Get-AutomationConnection -Name $connectionName         

        "Logging in to Azure..."
        Add-AzureRmAccount `
            -ServicePrincipal `
            -TenantId $servicePrincipalConnection.TenantId `
            -ApplicationId $servicePrincipalConnection.ApplicationId `
            -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint 
    }
    catch {
        if (!$servicePrincipalConnection)
        {
            $ErrorMessage = "Connection $connectionName not found."
            throw $ErrorMessage
        } else{
            Write-Error -Message $_.Exception
            throw $_.Exception
        }
    }

    # Set Data Warehouse variables
   

    $resourceGroupName = "neudesic-da-prd-eus2-adw-rg"
    $serverName = "neudesic-da-prd-eus2-adw-dbs"
    $databaseName = "neudesic-da-prd-eus2-adw"

    "Data Warehouse Settings"
    "Resource Group: " + $resourceGroupName
    "Server Name : " + $serverName
    "Database Name: " + $databaseName

    # Start the Data Warehouse
    "Resuming the Data Warehouse..."
    Resume-AzureRmSqlDatabase -ResourceGroupName $resourceGroupName -ServerName $serverName -DatabaseName $databaseName 
    #Set-AzureRmSqlDatabase -ResourceGroupName $resourceGroupName -DatabaseName $databaseName -ServerName $serverName -RequestedServiceObjectiveName "DW1000"
}