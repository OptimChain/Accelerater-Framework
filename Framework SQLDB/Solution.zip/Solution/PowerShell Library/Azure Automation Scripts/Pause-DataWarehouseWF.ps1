workflow Pause-DataWarehouseWF
{
    <#
        .DESCRIPTION
            Runbook to pause the framework Data Warehouse

        .NOTES
            AUTHOR: Mike Sherrill - Neudesic LLC
            LASTEDIT: August 21, 2018
    #>

    Write-Output "Begin Pause-DataWarehouseWF"

    $connectionName = "AzureRunAsConnection"
    try
    {
        # Get the connection "AzureRunAsConnection "
        $servicePrincipalConnection=Get-AutomationConnection -Name $connectionName         

        "Logging in to Azure..."
        Add-AzureRmAccount `
            -ServicePrincipal `
            -TenantId $servicePrincipalConnection.TenantId `
            -ApplicationId $servicePrincipalConnection.ApplicationId `
            -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint 
    }
    catch {
        if (!$servicePrincipalConnection)
        {
            $ErrorMessage = "Connection $connectionName not found."
            throw $ErrorMessage
        } else{
            Write-Error -Message $_.Exception
            throw $_.Exception
        }
    }

    #Login-AzureRmAccount
    #Select-AzureRmSubscription -SubscriptionName "E470 Dev"

    # Set Data Warehouse variables
    $resourceGroupName = "Framework"
    $serverName = "neuframework"
    $databaseName = "neuframeworkadw"

    "Data Warehouse Settings"
    "Resource Group: " + $resourceGroupName
    "Server Name : " + $serverName
    "Database Name: " + $databaseName

    # Pause the Data Warehouse
    "Pausing the Data Warehouse..."

    $count = 1

    $adw = Get-AzureRmSqlDatabase -ResourceGroupName $resourceGroupName -ServerName $serverName -DatabaseName $databaseName
    while ($adw.Status -ne "Online" -and $adw.Status -ne "Paused" -and $count -ne 31) {
        $adw = Get-AzureRmSqlDatabase -ResourceGroupName $resourceGroupName -ServerName $serverName -DatabaseName $databaseName
        "Attempt $($count)"
        "Current Status: $($adw.Status)"
        Start-Sleep -s 10
        $count++
    }
    If ($adw.Status -eq "Online") {
        Suspend-AzureRmSqlDatabase -ResourceGroupName $resourceGroupName -ServerName $serverName -DatabaseName $databaseName
    }

    Write-Output "End Pause-DataWarehouseWF"
}