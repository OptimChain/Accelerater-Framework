workflow TierUp-AnalysisServicesWF
{
    <#
        .DESCRIPTION
            Runbook to increase the tier of the neudesic project Analysis Services

        .NOTES
            AUTHOR: Mike Sherrill - Neudesic LLC
            LASTEDIT: Oct 9, 2017
    #>

    Write-Output "Begin TierUp-AnalysisServicesWF"

    $connectionName = "AzureRunAsConnection"
    try
    {
        # Get the connection "AzureRunAsConnection "
        $servicePrincipalConnection=Get-AutomationConnection -Name $connectionName         

        "Logging in to Azure..."
        Add-AzureRmAccount `
            -ServicePrincipal `
            -TenantId $servicePrincipalConnection.TenantId `
            -ApplicationId $servicePrincipalConnection.ApplicationId `
            -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint 
    }
    catch {
        if (!$servicePrincipalConnection)
        {
            $ErrorMessage = "Connection $connectionName not found."
            throw $ErrorMessage
        } else{
            Write-Error -Message $_.Exception
            throw $_.Exception
        }
    }

    # Set Analysis Service variables
    $resourceGroupName = "neudesic-da-prd-eus2-sas-rg"
    $serverName = "neudesicdaprdeus2sas"

    "***** Analysis Server settings"
    "Resource Group: " + $resourceGroupName
    "Server Name : " + $serverName

    $count = 1

    # Display Analysis Service information
    "***** Display Analysis Services server information"
    $aas = Get-AzureRmAnalysisServicesServer -ResourceGroupName $resourceGroupName -Name $serverName
    $aas

    while ($aas.State -ne "Succeeded" -and $count -ne 31) {
        $aas = Get-AzureRmAnalysisServicesServer -ResourceGroupName $resourceGroupName -Name $serverName
        "Attempt $($count)"
        "Current Status: $($aas.State)"
        Start-Sleep -s 10
        $count++
    }
    If ($aas.State -eq "Succeeded") {
        # Tier Up Analysis Service server
        "***** Tier Up Analysis Services server"
        Set-AzureRmAnalysisServicesServer  -ResourceGroupName $resourceGroupName -Name $serverName -Sku "S8"  
        write-output "Analysis Service Tier Increased"
    }

    # Display Analysis Service information
    "***** Display Analysis Services server information"
    Get-AzureRmAnalysisServicesServer -ResourceGroupName $resourceGroupName -Name $serverName

    Write-Output "End TierUp-AnalysisServicesWF"
}