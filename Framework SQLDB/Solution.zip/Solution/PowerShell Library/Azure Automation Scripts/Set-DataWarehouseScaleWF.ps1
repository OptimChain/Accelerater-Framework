workflow Set-DataWarehouseScaleWF
{
    Param(
        [int]$DWUs
    )
	# Converter: Wrapping initial script in an InlineScript activity, and passing any parameters for use within the InlineScript
	# Converter: If you want this InlineScript to execute on another host rather than the Automation worker, simply add some combination of -PSComputerName, -PSCredential, -PSConnectionURI, or other workflow common parameters (http://technet.microsoft.com/en-us/library/jj129719.aspx) as parameters of the InlineScript
	inlineScript {
        Write-Output "Begin Set-DataWarehouseScaleWF"

        $inlineDWUs = $using:DWUs
		$connectionName = "AzureRunAsConnection"
		try
		{
			# Get the connection "AzureRunAsConnection "
			$servicePrincipalConnection=Get-AutomationConnection -Name $connectionName         

			"Logging in to Azure..."
			Add-AzureRmAccount `
				-ServicePrincipal `
				-TenantId $servicePrincipalConnection.TenantId `
				-ApplicationId $servicePrincipalConnection.ApplicationId `
				-CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint 
		}
		catch {
			if (!$servicePrincipalConnection)
			{
				$ErrorMessage = "Connection $connectionName not found."
				throw $ErrorMessage
			} else{
				Write-Error -Message $_.Exception
				throw $_.Exception
			}
		}
        
        #Login-AzureRmAccount
        #Select-AzureRmSubscription -SubscriptionName "Neudesic Dev"

		# Set Data Warehouse variables
		$resourceGroupName = "neudesic-da-tst-eus2-adw-rg"
		$serverName = "neudesic-da-tst-eus2-adw-dbs"
		$databaseName = "neudesic-da-tst-eus2-adw"

		"Data Warehouse Settings"
		"Resource Group: " + $resourceGroupName
		"Server Name : " + $serverName
		"Database Name: " + $databaseName
    
        $count = 1

        $adw = Get-AzureRmSqlDatabase -ResourceGroupName $resourceGroupName -ServerName $serverName -DatabaseName $databaseName
        while ($adw.Status -ne "Online" -and $count -ne 31) {
            $adw = Get-AzureRmSqlDatabase -ResourceGroupName $resourceGroupName -ServerName $serverName -DatabaseName $databaseName
            "Attempt $($count)"
            "Current Status: $($adw.Status)"
            Start-Sleep -s 10
            $count++
        }
        If ($adw.Status -eq "Online") {
		    Set-AzureRmSqlDatabase -ResourceGroupName $resourceGroupName -DatabaseName $databaseName -ServerName $serverName -RequestedServiceObjectiveName "DW$inlineDWUs"
        }
        $adw = Get-AzureRmSqlDatabase -ResourceGroupName $resourceGroupName -ServerName $serverName -DatabaseName $databaseName
        while ($adw.Status -ne "Online" -and $count -ne 31) {
            $adw = Get-AzureRmSqlDatabase -ResourceGroupName $resourceGroupName -ServerName $serverName -DatabaseName $databaseName
            "Attempt $($count)"
            "Current Status: $($adw.Status)"
            Start-Sleep -s 10
            $count++
        }

        Write-Output "End Set-DataWarehouseScaleWF"
	}
}