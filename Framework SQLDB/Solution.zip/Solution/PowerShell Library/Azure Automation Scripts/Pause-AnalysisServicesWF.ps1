workflow Pause-AnalysisServicesWF
{
    <#
        .DESCRIPTION
            Runbook to pause the neudesic project Analysis Services

        .NOTES
            AUTHOR: Chris Kurt - Neudesic LLC
            LASTEDIT: Apr 13, 2017
    #>

    Write-Output "Begin Pause-AnalysisServicesWF"

    $connectionName = "AzureRunAsConnection"
    try
    {
        # Get the connection "AzureRunAsConnection "
        $servicePrincipalConnection=Get-AutomationConnection -Name $connectionName         

        "Logging in to Azure..."
        Add-AzureRmAccount `
            -ServicePrincipal `
            -TenantId $servicePrincipalConnection.TenantId `
            -ApplicationId $servicePrincipalConnection.ApplicationId `
            -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint 
    }
    catch {
        if (!$servicePrincipalConnection)
        {
            $ErrorMessage = "Connection $connectionName not found."
            throw $ErrorMessage
        } else{
            Write-Error -Message $_.Exception
            throw $_.Exception
        }
    }

    #Login-AzureRmAccount
    #Select-AzureRmSubscription -SubscriptionName "Neudesic prd"

    # Set Analysis Service variables
    $resourceGroupName = "neudesic-da-prd-eus2-sas-rg"
    $serverName = "neudesicdaprdeus2sas"

    "***** Analysis Server settings"
    "Resource Group: " + $resourceGroupName
    "Server Name : " + $serverName

    $count = 1

    # Display Analysis Service information
    "***** Display Analysis Services server information"
    $aas = Get-AzureRmAnalysisServicesServer -ResourceGroupName $resourceGroupName -Name $serverName
    $aas

    while ($aas.State -ne "Succeeded" -and $count -ne 31) {
        $aas = Get-AzureRmAnalysisServicesServer -ResourceGroupName $resourceGroupName -Name $serverName
        "Attempt $($count)"
        "Current Status: $($aas.State)"
        Start-Sleep -s 10
        $count++
    }
    If ($aas.State -eq "Succeeded") {
        # Pause Analysis Service server
        "***** Pausing Analysis Services server"
        Suspend-AzureRmAnalysisServicesServer -ResourceGroupName $resourceGroupName -Name $serverName
    }

    Write-Output "End Pause-AnalysisServicesWF"
}