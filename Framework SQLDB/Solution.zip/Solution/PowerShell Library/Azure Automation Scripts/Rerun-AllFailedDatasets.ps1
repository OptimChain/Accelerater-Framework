<#
    .DESCRIPTION
        Runbook to pull all data from TCS into Staging on a daily basis

    .NOTES
        AUTHOR: Ken Mears - Neudesic LLC, sourced from samples published by the Microsoft Azure Automation Team
        LASTEDIT: April 25, 2017
#>

workflow Rerun-AllFailedInitDatasets
{
    # To test from PowerShell client, uncomment the 2 rows below and provide subscription ID
    #Login-AzureRmAccount
    #Select-AzureRmSubscription -SubscriptionName "Neudesic Dev"

    $connectionName = "AzureRunAsConnection"
    try
    {
        # Get the connection "AzureRunAsConnection "
        $servicePrincipalConnection=Get-AutomationConnection -Name $connectionName         

        "Logging in to Azure..."
        Add-AzureRmAccount `
            -ServicePrincipal `
            -TenantId $servicePrincipalConnection.TenantId `
            -ApplicationId $servicePrincipalConnection.ApplicationId `
            -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint 
    }
    catch {
        if (!$servicePrincipalConnection)
        {
            $ErrorMessage = "Connection $connectionName not found."
            throw $ErrorMessage
        } else{
            Write-Error -Message $_.Exception
            throw $_.Exception
        }
    }
    
    $rgn = "neudesic-da-prd-wus-df-rg" #Resource Group Name
    $dfn = "neudesic-da-prd-wus-df" #Data Factory Name
    Write-Output $rgn
    # Create start/end DateTime (yesterday)
    $sdt = [System.DateTime]::Today.AddYears(-1)
    $edt = [System.DateTime]::Today.AddSeconds(-1)

    $dataSets = Get-AzureRmDataFactoryDataset -DataFactoryName $dfn -ResourceGroupName $rgn | Where {$_.DatasetName -like "*"} | Sort-Object DatasetName
    # Loop over matching named DataSets
    ForEach -Parallel ($ds in $dataSets) {
        #If ($ds.DatasetName -like "*InitOutput*") {
            Write-Output "Dataset: $($ds.DatasetName)"
            # List slices
            $slices = Get-AzureRmDataFactorySlice -DataFactoryName $dfn -ResourceGroupName $rgn -DatasetName $ds.DatasetName -StartDateTime $sdt -EndDateTime $edt
            # Reset all slices to status Waiting for the given dataset, in case there are multiple
            ForEach ($s in $slices) {
                $outcome = $false
                If ($s.State -eq "Failed") {
                    Write-Output "Dataset: $($ds.DatasetName) --> Slice Start:[$($s.Start)] End:[$($s.End)] State:$($s.State) $($s.SubState)"
                    Try {
                        $outcome = Set-AzureRmDataFactorySliceStatus -DataFactoryName $dfn -ResourceGroupName $rgn -DatasetName $ds.DatasetName -Status Waiting -UpdateType UpstreamInPipeline -StartDateTime $s.Start -EndDateTime $s.End
                        Write-Output " Slice status reset to Waiting so it will run again: $outcome"
                    } Catch {
                        Write-Output " Slice status reset has failed. Error: $_"
                    }
                }
            }
        #}
    }
}