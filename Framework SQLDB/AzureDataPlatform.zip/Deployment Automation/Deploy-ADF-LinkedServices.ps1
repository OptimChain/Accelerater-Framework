﻿<#

	NEUDESIC AZURE FRAMEWORK

    DESCRIPTION
        Deploy new Linked Services from local Visual Studio copy to Azure.

    MODIFICATION HISTORY

	  DATE		AUTHOR					NOTES
	---------	----------------------	---------------------------------------------------------
	10/18/2017	Ken Mears				Created.
	12/7/2017	Alan Campbell			Standardized for the Framework.
	2/9/2017	Ken Mears				Updated to handle dynamic deployment folder
        
#>

Param(
    [Parameter(Position=0,Mandatory=$true)]
    [ValidateNotNull()]
    [ValidateSet("Dev", "Test", "Prod")]
    [System.String]$Environment, #$env:COMPUTERNAME
    [Parameter(Position=1,Mandatory=$true,HelpMessage="Should a prompt to login appear? Acceptable values are Yes or No")]
    [ValidateNotNull()]
    [System.String]$PromptForLogin
)

If ($PromptForLogin -eq "Yes") {
    Login-AzureRmAccount
    Select-AzureRmSubscription -SubscriptionName $Environment
}

# Set Data Factory variables
    
switch ($Environment) {
    "Dev" {
	    $resourceGroupName = "neudesic-da-dev-wus-df-rg"
	    $dataFactoryName = "neudesic-da-dev-wus-df"
        $envAbbrv = "-dev-"
    }
    "Test" {
	    $resourceGroupName = "neudesic-da-tst-wus-df-rg"
	    $dataFactoryName = "neudesic-da-tst-wus-df"
        $envAbbrv = "-tst-"
    }
    "Prod" {
	    $resourceGroupName = "neudesic-da-prd-wus-df-rg"
	    $dataFactoryName = "neudesic-da-prd-wus-df"
        $envAbbrv = "-prd-"
    }
    default {
	    $resourceGroupName = "neudesic-da-dev-wus-df-rg"
	    $dataFactoryName = "neudesic-da-dev-wus-df"
        $envAbbrv = "-dev-"
    }
}

$DeploymentFolder = [Environment]::GetEnvironmentVariable("DeploymentFolder","User")

If ($DeploymentFolder -eq $null) {
    $DeploymentFolder = Read-Host -Prompt "Please enter your solution folder's full path"
    [Environment]::SetEnvironmentVariable("DeploymentFolder", $DeploymentFolder, "User")
    Write-Host "Deployment folder set to..." -ForegroundColor Green
    $DeploymentFolder = [Environment]::GetEnvironmentVariable("DeploymentFolder","User")
    Write-Host $DeploymentFolder -ForegroundColor Yellow
}

$ignored = "ADLS", "ASDW", "Framework"

Write-Host "Data Factory Settings" -ForegroundColor Yellow
Write-Host "Resource Group: $($resourceGroupName)" -ForegroundColor Yellow
Write-Host "Server Name : $($dataFactoryName)" -ForegroundColor Yellow
Write-Host

Get-ChildItem "$DeploymentFolder\DataFactory\*" -Filter *.json -Exclude *QA*.json, *Staging*.json, *Output*.json, *Input*.json | 
Foreach-Object {
    If ($ignored -notcontains $_.BaseName) {
        Write-Host "Deploying linked service $($_.BaseName)..." -ForegroundColor Yellow

        $content = [IO.File]::ReadAllText($_.FullName)
        $content = $content.Replace("-dev-", $envAbbrv)
        $content = $content.Replace("-tst-", $envAbbrv)
        $content = $content.Replace("-prd-", $envAbbrv)
        [IO.File]::WriteAllText($_.FullName, $content.TrimEnd())

        $pl = Get-AzureRmDataFactoryLinkedService -Name $_.BaseName -DataFactoryName $dataFactoryName -ResourceGroupName $resourceGroupName -ErrorAction SilentlyContinue
        If ($pl.ProvisioningState) {
            Write-Host "$($_.BaseName) found... ignoring." -ForegroundColor Yellow
        } else {
            Write-Host "$($_.BaseName) not found... creating...." -ForegroundColor Yellow
            New-AzureRmDataFactoryLinkedService -DataFactoryName $dataFactoryName -ResourceGroupName $resourceGroupName -Name $_.BaseName -File $_.FullName
        }
    }
}

Write-Host "Press any key to continue ..."

$x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")