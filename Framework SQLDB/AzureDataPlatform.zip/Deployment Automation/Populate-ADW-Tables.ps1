﻿<#

	NEUDESIC AZURE FRAMEWORK

    DESCRIPTION
        Populate Tables in Azure Data Warehouse from local Visual Studio code.

    MODIFICATION HISTORY

	  DATE		AUTHOR					NOTES
	---------	----------------------	---------------------------------------------------------
	10/18/2017	Ken Mears				Created.
	12/7/2017	Alan Campbell			Standardized for the Framework.
	2/9/2017	Ken Mears				Updated to handle dynamic deployment folder
        
#>

Param(
    [Parameter(Position=0,Mandatory=$true)]
    [ValidateNotNull()]
    [ValidateSet("Dev", "Test", "Prod")]
    [System.String]$Environment, #$env:COMPUTERNAME
    [Parameter(Position=1,Mandatory=$true,HelpMessage="Should a prompt to login appear? Acceptable values are Yes or No")]
    [ValidateNotNull()]
    [System.String]$PromptForLogin
)

If ($PromptForLogin -eq "Yes") {
    Login-AzureRmAccount
    Select-AzureRmSubscription -SubscriptionName $Environment
}

$credential = Get-Credential -Message "SQL Login UserName/Password"

# Set Data Warehouse variables
    
switch ($Environment) {
    "Dev" {
	    $resourceGroupName = "neudesic-da-dev-eus2-adw-rg"
	    $serverName = "neudesic-da-dev-eus2-adw-dbs.database.windows.net"
	    $databaseName = "neudesic-da-dev-eus2-adw"
    }
    "Test" {
	    $resourceGroupName = "neudesic-da-tst-eus2-adw-rg"
	    $serverName = "neudesic-da-tst-eus2-adw-dbs.database.windows.net"
	    $databaseName = "neudesic-da-tst-eus2-adw"
    }
    "Prod" {
	    $resourceGroupName = "neudesic-da-prd-eus2-adw-rg"
	    $serverName = "neudesic-da-prd-eus2-adw-dbs.database.windows.net"
	    $databaseName = "neudesic-da-prd-eus2-adw"
    }
    default {
	    $resourceGroupName = "neudesic-da-dev-eus2-adw-rg"
	    $serverName = "neudesic-da-dev-eus2-adw-dbs.database.windows.net"
	    $databaseName = "neudesic-da-dev-eus2-adw"
    }
}

$DeploymentFolder = [Environment]::GetEnvironmentVariable("DeploymentFolder","User")

If ($DeploymentFolder -eq $null) {
    $DeploymentFolder = Read-Host -Prompt "Please enter your solution folder's full path"
    [Environment]::SetEnvironmentVariable("DeploymentFolder", $DeploymentFolder, "User")
    Write-Host "Deployment folder set to..." -ForegroundColor Green
    $DeploymentFolder = [Environment]::GetEnvironmentVariable("DeploymentFolder","User")
    Write-Host $DeploymentFolder -ForegroundColor Yellow
}

Write-Host "Data Warehouse Settings" -ForegroundColor Yellow
Write-Host "Resource Group: $($resourceGroupName)" -ForegroundColor Yellow
Write-Host "Server Name : $($serverName)" -ForegroundColor Yellow
Write-Host "Database Name: $($databaseName)" -ForegroundColor Yellow
Write-Host

$queryTimeout = 900
$Error.Clear()

Get-ChildItem "$DeploymentFolder\Azure Data Warehouse\Data" -Filter *.sql | 
Foreach-Object {
    $tableName = $_.BaseName.Replace(".data", "")
    Write-Host "Checking if $($tableName) exists..." -ForegroundColor Green
    $exists = Invoke-Sqlcmd -Query "SELECT LTRIM(RTRIM(OBJECT_ID('`$(TableName)','U'))) as 'id';" -Variable "TableName=$($tableName)" -ServerInstance "$serverName" -Database $databaseName -Username "$($credential.UserName)@$serverName" -Password $credential.GetNetworkCredential().Password -QueryTimeout $queryTimeout

    If ($exists.id -Match "[0-9]")
    {
        Write-Host "Checking if $($tableName) contains data..." -ForegroundColor Green
        $count = Invoke-Sqlcmd -Query "SELECT COUNT(1) as 'RowCount' FROM `$(TableName);" -Variable "TableName=$($tableName)" -ServerInstance "$serverName" -Database $databaseName -Username "$($credential.UserName)@$serverName" -Password $credential.GetNetworkCredential().Password -QueryTimeout $queryTimeout

        If ($count.RowCount -eq 0)
        {
            Write-Host "Adding data to $($tableName)..." -ForegroundColor Yellow
            Invoke-Sqlcmd -InputFile $_.FullName -ServerInstance "$serverName" -Database $databaseName -Username "$($credential.UserName)@$serverName" -Password $credential.GetNetworkCredential().Password -QueryTimeout $queryTimeout
        }
    }
}

Write-Host "Press any key to continue ..."

$x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")