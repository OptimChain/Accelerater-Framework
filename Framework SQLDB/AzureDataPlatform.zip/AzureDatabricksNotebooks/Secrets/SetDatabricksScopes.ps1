﻿#Container Secrets

$SubscriptionId = "a9736b54-71f3-4a19-bd5b-d3979b8ce04f"
Select-AzSubscription -SubscriptionId $SubscriptionId


$KeyVaultName = "da-dev-wus2-analytics-kv"
$Region = "westus2"



$ContainerToken = (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "DatabricksDataAdminToken").SecretValueText
$FrameworkToken = (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "DatabricksFrameworkAdminToken").SecretValueText




Connect-Databricks -BearerToken $ContainerToken -Region $Region

Add-DatabricksSecretScope -BearerToken $ContainerToken -Region $Region -ScopeName brtladmin
Add-DatabricksSecretScope -BearerToken $ContainerToken -Region $Region -ScopeName brtlcontribute
Add-DatabricksSecretScope -BearerToken $ContainerToken -Region $Region -ScopeName brtlpublish
Add-DatabricksSecretScope -BearerToken $ContainerToken -Region $Region -ScopeName brtlread



Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtladmin -SecretName ADLSGen2StorageAccountName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ADLSName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtladmin -SecretName ADLSTenantID -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ADLSTenantID").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtladmin -SecretName SQLFrameworkServerName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkServerName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtladmin -SecretName SQLFrameworkDatabaseName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkDatabaseName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtladmin -SecretName SQLFrameworkUserName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkUserName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtladmin -SecretName SQLFrameworkPassword -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkPassword").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtladmin -SecretName SQLDWDatabaseName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWDatabaseName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtladmin -SecretName SQLDWServerName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWServerName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtladmin -SecretName SQLDWUserName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWUserName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtladmin -SecretName SQLDWPassword -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWPassword").SecretValueText


Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlcontribute -SecretName ADLSGen2StorageAccountName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ADLSName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlcontribute -SecretName ADLSTenantID -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ADLSTenantID").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlcontribute -SecretName SQLFrameworkServerName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkServerName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlcontribute -SecretName SQLFrameworkDatabaseName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkDatabaseName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlcontribute -SecretName SQLFrameworkUserName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkUserName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlcontribute -SecretName SQLFrameworkPassword -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkPassword").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlcontribute -SecretName SQLDWDatabaseName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWDatabaseName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlcontribute -SecretName SQLDWServerName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWServerName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlcontribute -SecretName SQLDWUserName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWUserName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlcontribute -SecretName SQLDWPassword -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWPassword").SecretValueText

Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlpublish -SecretName ADLSGen2StorageAccountName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ADLSName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlpublish -SecretName ADLSTenantID -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ADLSTenantID").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlpublish -SecretName SQLFrameworkServerName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkServerName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlpublish -SecretName SQLFrameworkDatabaseName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkDatabaseName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlpublish -SecretName SQLFrameworkUserName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkUserName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlpublish -SecretName SQLFrameworkPassword -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkPassword").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlpublish -SecretName SQLDWDatabaseName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWDatabaseName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlpublish -SecretName SQLDWServerName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWServerName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlpublish -SecretName SQLDWUserName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWUserName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlpublish -SecretName SQLDWPassword -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWPassword").SecretValueText


Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlread -SecretName ADLSGen2StorageAccountName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ADLSName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlread -SecretName ADLSTenantID -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ADLSTenantID").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlread -SecretName SQLFrameworkServerName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkServerName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlread -SecretName SQLFrameworkDatabaseName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkDatabaseName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlread -SecretName SQLFrameworkUserName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkUserName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlread -SecretName SQLFrameworkPassword -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkPassword").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlread -SecretName SQLDWDatabaseName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWDatabaseName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlread -SecretName SQLDWServerName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWServerName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlread -SecretName SQLDWUserName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWUserName").SecretValueText
Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlread -SecretName SQLDWPassword -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWPassword").SecretValueText

#test

#Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtladmin -SecretName ADLSClientID -SecretValue "06d53884-fbd2-4b50-b44f-39bbf4509cd8" 
#Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtladmin -SecretName ADLSCredential -SecretValue "QBLc5s6cKwrA6yFk8lsF~926vy8-g~503_" 
#Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlContribute -SecretName ADLSClientID -SecretValue "772b2fd9-b058-4988-847a-0732417acbad" 
#Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlcontribute -SecretName ADLSCredential -SecretValue "mC-Rvg.mMZ3c7XX6~r4CISX6nZ~4dUn46~" 
#Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlpublish -SecretName ADLSClientID -SecretValue "bf956aaa-9029-4189-916e-c814610bf227" 
#Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlpublish -SecretName ADLSCredential -SecretValue "-fKmu8wEuN5Gs0wsVr.1~qHMzuE9mqEG~f"
#Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlread -SecretName ADLSClientID -SecretValue "0b861ed4-ebf2-4f54-8c9f-286f62e80540" 
#Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName brtlread -SecretName ADLSCredential -SecretValue "8mfmuDCJkm09_Aodf-y-eh.sY3Z1a9a.RN" 





#ACLs
#Set-DatabricksPermission -BearerToken  $ContainerToken  -Principal AzureAD-da-tst-brtl-Admin -PermissionLevel Read -DatabricksObjectType secretScope - brtladmin
#Set-DatabricksPermission -BearerToken  $ContainerToken  -Principal AzureAD-da-tst-brtl-Contribute -PermissionLevel Read -DatabricksObjectType secretScope -DatabricksObjectId brtlcontribute
#Set-DatabricksPermission -BearerToken  $ContainerToken  -Principal AzureAD-da-tst-brtl-Publish -PermissionLevel Read -DatabricksObjectType secretScope -DatabricksObjectId brtlpublish
#Set-DatabricksPermission -BearerToken  $ContainerToken  -Principal AzureAD-da-tst-brtl-Read -PermissionLevel Read -DatabricksObjectType secretScope -DatabricksObjectId brtlread

#Framework Secrets

Add-DatabricksSecretScope -BearerToken $FrameworkToken -Region $Region -ScopeName framework

Set-DatabricksSecret -BearerToken $ContainerToken -ScopeName framework -SecretName ADLSStorageAccountName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ADLSStorageAccountKey").SecretValueText
Set-DatabricksSecret -BearerToken $FrameworkToken -ScopeName framework -SecretName ADLSGen2StorageAccountName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ADLSName").SecretValueText
Set-DatabricksSecret -BearerToken $FrameworkToken -ScopeName framework -SecretName ADLSTenantID -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ADLSTenantID").SecretValueText
Set-DatabricksSecret -BearerToken $FrameworkToken -ScopeName framework -SecretName SQLFrameworkServerName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkServerName").SecretValueText
Set-DatabricksSecret -BearerToken $FrameworkToken -ScopeName framework -SecretName SQLFrameworkDatabaseName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkDatabaseName").SecretValueText
Set-DatabricksSecret -BearerToken $FrameworkToken -ScopeName framework -SecretName SQLFrameworkUserName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkUserName").SecretValueText
Set-DatabricksSecret -BearerToken $FrameworkToken -ScopeName framework -SecretName SQLFrameworkPassword -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLFrameworkPassword").SecretValueText
Set-DatabricksSecret -BearerToken $FrameworkToken -ScopeName framework -SecretName SQLDWDatabaseName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWDatabaseName").SecretValueText
Set-DatabricksSecret -BearerToken $FrameworkToken -ScopeName framework -SecretName SQLDWServerName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWServerName").SecretValueText
Set-DatabricksSecret -BearerToken $FrameworkToken -ScopeName framework -SecretName SQLDWUserName -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWUserName").SecretValueText
Set-DatabricksSecret -BearerToken $FrameworkToken -ScopeName framework -SecretName SQLDWPassword -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "SQLDWPassword").SecretValueText

Set-DatabricksSecret -BearerToken $FrameworkToken -ScopeName framework -SecretName ADLSGen2StorageAccountKey -SecretValue (Get-AzKeyVaultSecret -VaultName $KeyVaultName  -Name "ADLSStorageAccountKey").SecretValueText
#Set-DatabricksSecret -BearerToken $FrameworkToken -ScopeName framework -SecretName ADLSClientID -SecretValue 06d53884-fbd2-4b50-b44f-39bbf4509cd8 
#Set-DatabricksSecret -BearerToken $FrameworkToken -ScopeName framework -SecretName ADLSCredential -SecretValue QBLc5s6cKwrA6yFk8lsF~926vy8-g~503_
