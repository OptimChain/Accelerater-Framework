# MAGIC %md
# MAGIC # Client000000001 - Create DimProvider
# MAGIC ###### Author: Mike Sherrill 9/12/19
# MAGIC 
# MAGIC This notebook is used to create the DimProvider dimension from spark tables created during query zone enrich processing.  It creates spark tables and writes to the enriched zone.  
# MAGIC #### Usage
# MAGIC Supply the parameters above and run the notebook.  
# MAGIC 
# MAGIC #### Prerequisites
# MAGIC 1. Data must exist in the Spark tables.   
# MAGIC 
# MAGIC #### Details

# COMMAND ----------

# MAGIC %md
# MAGIC #### Initialize Framework

# COMMAND ----------

dbutils.widgets.text(name="containerName", defaultValue="client000000001", label="Container Name")
containerName = dbutils.widgets.get("containerName")

# COMMAND ----------

# MAGIC %run ./Framework/Secrets_Databricks_Container

# COMMAND ----------

# MAGIC %run ./Framework/Neudesic_Framework_Functions

# COMMAND ----------

dbutils.widgets.text(name="parentPipeLineExecutionLogKey", defaultValue="-1", label="Parent Pipeline Execution Log Key")
dbutils.widgets.text(name="numPartitions", defaultValue="8", label="Number of Partitions")

parentPipeLineExecutionLogKey = dbutils.widgets.get("parentPipeLineExecutionLogKey")
fullPathPrefix = "abfss://" + containerName + "@" + adlsGen2StorageAccountName + ".dfs.core.windows.net" 

numPartitions = int(dbutils.widgets.get("numPartitions"))


# COMMAND ----------

notebookName = "Client000000001 - Create Dimensions"
notebookExecutionLogKey = log_event_notebook_start(notebookName,parentPipeLineExecutionLogKey)
print("Notebook Execution Log Key: {0}".format(notebookExecutionLogKey))

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Starting
# MAGIC val notebookPath = dbutils.notebook.getContext.notebookPath.get
# MAGIC val logMessage = "Starting"
# MAGIC val notebookContext = dbutils.notebook.getContext().toJson
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

# MAGIC %md
# MAGIC #### Create Provider Dimension

# COMMAND ----------

tableName = "DimProvider"

databaseTableName = containerName + "." + tableName

enrichedPath = fullPathPrefix + "/Query/Enriched/" + tableName

# COMMAND ----------

# MAGIC %md
# MAGIC #### Create Stg View

# COMMAND ----------

sql = """CREATE OR REPLACE VIEW client000000001.StgDimProviderView AS
SELECT 
		 HOSPITAL_ID
		,HOSPITAL_NAME
		,PROVIDER_NUMBER
		,CASE 
		  WHEN FIRM_TYPE = 'Home Health Agency Corporation'
			THEN 'Home Health Agency'
		  WHEN FIRM_TYPE = 'Skilled Nursing Facility Corporation'
			THEN 'Skilled Nursing Facility'
		  WHEN FIRM_TYPE = 'Health System'
		    THEN 'Hospital'
		  ELSE FIRM_TYPE
		 END as FIRM_TYPE
		,HOSPITAL_TYPE
		,HQ_ADDRESS
		,HQ_ADDRESS1
		,HQ_CITY
		,HQ_STATE
		,HQ_ZIP_CODE
		,HQ_COUNTY
		,CBSA_POPULATION_EST_MOST_RECENT
		,CBSA_POPULATION_GROWTH_MOST_RECENT
		,HQ_LATITUDE
		,HQ_LONGITUDE
		,WEBSITE
		,NETWORK_ID
		,NETWORK_NAME
		,NETWORK_PARENT_ID
		,NETWORK_PARENT_NAME
		,PROGRAM_340B_ID
		,MEDICAL_SCHOOL_AFFILIATION
		,MARKET_CONCENTRATION_INDEX
		,FINANCIAL_DATA_DATE
		,CBSA_CODE_DESCRIPTION AS CBSA_CODE
		,'Hospital_Overview' as SOURCE_TABLE
		,'' AS FULL_CENSUS_TRACT 
		,'' AS POPULATION_DENSITY
		,'' AS STATE_NUMBER
		,'' AS COUNTY_NUMBER
		,'' AS HQ_PHONE
		,'' AS HOSPITAL_PARENT_ID
		,'' AS HOSPITAL_PARENT_NAME
		,'' AS TYPE_OF_OWNERSHIP
		,'' AS COMPANY_STATUS
		,'' AS PARTICIPATES_IN_MEDICARE
		,'' AS PARTICIPATES_IN_MEDICAID
		,'' AS DATE_FISCAL_YEAR_END
		,'' AS HOSPITAL_OWNERSHIP 
FROM {0}
UNION
SELECT
		HOSPITAL_ID	
		,HOSPITAL_NAME	
		,''	
		,'Assisted Living Facility'	
		,NULL	
		,HQ_ADDRESS	
		,HQ_ADDRESS1	
		,HQ_CITY	
		,HQ_STATE	
		,HQ_ZIP_CODE	
		,HQ_COUNTY
		,''	
		,CBSA_POPULATION_GROWTH_MOST_RECENT
		,HQ_LATITUDE
		,HQ_LONGITUDE
		,''	
		,NETWORK_ID	
		,NETWORK_NAME	
		,NETWORK_PARENT_ID	
		,NETWORK_PARENT_NAME	
		,''	
		,''	
		,''	
		,''	
		,CBSA_CODE	
		,FULL_CENSUS_TRACT 	
		,POPULATION_DENSITY	
		,STATE_NUMBER	
		,COUNTY_NUMBER	
		,HQ_PHONE	
		,'' AS HOSPITAL_PARENT_ID	
		,'' AS HOSPITAL_PARENT_NAME	
		,'' AS TYPE_OF_OWNERSHIP	
		,'' AS COMPANY_STATUS	
		,'' AS PARTICIPATES_IN_MEDICARE	
		,'' AS PARTICIPATES_IN_MEDICAID	
		,'' AS DATE_FISCAL_YEAR_END	
		,'' AS HOSPITAL_OWNERSHIP	
		,'LTC_ALF_Overview' as SOURCE_TABLE
FROM {1}
UNION
SELECT
		 HOSPITAL_ID	
		  ,HOSPITAL_NAME	
		  ,PROVIDER_NUMBER	
		  ,CASE 
		    WHEN FIRM_TYPE = 'Home Health Agency Corporation'
		    	THEN 'Home Health Agency'
		    WHEN FIRM_TYPE = 'Skilled Nursing Facility Corporation'
			    THEN 'Skilled Nursing Facility'
		    ELSE FIRM_TYPE
		  END as FIRM_TYPE
 		 ,''
		  ,HQ_ADDRESS	
		  ,HQ_ADDRESS1	
		  ,HQ_CITY	
		  ,HQ_STATE	
		  ,HQ_ZIP_CODE	
		  ,HQ_COUNTY	
		,''
		,CBSA_POPULATION_GROWTH_MOST_RECENT
		  ,HQ_LATITUDE	
		  ,HQ_LONGITUDE	
		,''
		  ,NETWORK_ID	
		  ,NETWORK_NAME	
		  ,NETWORK_PARENT_ID	
		  ,NETWORK_PARENT_NAME	
		,''
		,''
		,''
		,''
		  ,CBSA_CODE	
		,''
		,''
		,''
		,''
		,''
		  ,HOSPITAL_PARENT_ID	
		  ,HOSPITAL_PARENT_NAME	
		  ,TYPE_OF_OWNERSHIP	
		  ,COMPANY_STATUS	
		  ,PARTICIPATES_IN_MEDICARE	
		  ,PARTICIPATES_IN_MEDICAID	
		,''
		,''
		,'LTC_HHA_Overview' as SOURCE_TABLE
FROM {2}
UNION 
SELECT 
        HOSPITAL_ID
		,HOSPITAL_NAME	
		,PROVIDER_NUMBER	
		,CASE 
		  WHEN FIRM_TYPE = 'Home Health Agency Corporation'
			THEN 'Home Health Agency'
		  WHEN FIRM_TYPE = 'Skilled Nursing Facility Corporation'
			THEN 'Skilled Nursing Facility'
		  ELSE FIRM_TYPE
		 END as FIRM_TYPE
		 ,''
		,HQ_ADDRESS	
		,HQ_ADDRESS1	
		,HQ_CITY	
		,HQ_STATE	
		,HQ_ZIP_CODE	
		,HQ_COUNTY	
		,''
		,CBSA_POPULATION_GROWTH_MOST_RECENT	
		,HQ_LATITUDE
		,HQ_LONGITUDE
		,''
		,NETWORK_ID	
		,NETWORK_NAME	
		,NETWORK_PARENT_ID	
		,NETWORK_PARENT_NAME	
		,''
		,''
		,''
		,FINANCIAL_DATA_DATE	
		,CBSA_CODE	
		,''
		,''
		,''
		,''
		,HQ_PHONE	
		,''
		,''
		,''
		,''
		,''
		,''
		,DATE_FISCAL_YEAR_END	
		,HOSPITAL_OWNERSHIP	
		,'LTC_SNF_Overview' as SOURCE_TABLE
FROM {3}
UNION 
SELECT 
        "-1" as HOSPITAL_ID
		,"Unknown" as HOSPITAL_NAME	
		,"-1" as PROVIDER_NUMBER	
		,NULL as FIRM_TYPE
		 ,''
		,''
		,''
		,''
		,''
		,''	
		,''
		,''
		,''
		,''
		,''
		,''
		,''
		,''	
		,''
		,''
		,''
		,''
		,''
		,''	
		,''
		,''
		,''
		,''
		,''
		,''	
		,''
		,''
		,''
		,''
		,''
		,''
		,''	
		,''
		,'None' as SOURCE_TABLE
""".format("client000000001.Hospital_Overview", "client000000001.LTC_ALF_Overview", "client000000001.LTC_HHA_Overview","client000000001.LTC_SNF_Overview")
df=spark.sql(sql)

# COMMAND ----------

#display(df)

# COMMAND ----------

sql = """
SELECT
	 LTRIM(RTRIM(HOSPITAL_ID)) as ProviderKey
	,LTRIM(RTRIM(HOSPITAL_ID)) as ProviderID
	,LTRIM(RTRIM(HOSPITAL_NAME)) as ProviderName
    ,REPLACE(REPLACE(PROVIDER_NUMBER,"(Closed)",""),"*","") as ProviderNumber
    ,LTRIM(RTRIM(FIRM_TYPE)) as FirmType
	,LTRIM(RTRIM(HOSPITAL_TYPE)) as HospitalType
	,LTRIM(RTRIM(HQ_ADDRESS)) as HQAddress
	,LTRIM(RTRIM(HQ_ADDRESS1)) as HQAddress1
	,LTRIM(RTRIM(HQ_CITY)) as HQCity
	,LTRIM(RTRIM(HQ_STATE)) as HQState
	,LTRIM(RTRIM(HQ_ZIP_CODE)) as HQZipCode
	,LTRIM(RTRIM(HQ_COUNTY)) as HQCounty
	,LTRIM(RTRIM(CBSA_POPULATION_GROWTH_MOST_RECENT)) as CBSAPopulationGrowthMostRecent
	,double(LTRIM(RTRIM(HQ_LATITUDE))) as HQLatitude
	,double(LTRIM(RTRIM(HQ_LONGITUDE))) as HQLongitude
	,LTRIM(RTRIM(NETWORK_ID)) as NetworkID
	,LTRIM(RTRIM(NETWORK_NAME)) as NetworkName
	,LTRIM(RTRIM(NETWORK_PARENT_ID)) as NetworkParentID
	,LTRIM(RTRIM(NETWORK_PARENT_NAME)) as NetworkParentName
	,LTRIM(RTRIM(PROGRAM_340B_ID)) as Program340BID
	,LTRIM(RTRIM(MEDICAL_SCHOOL_AFFILIATION)) as MedicalSchoolAffiliation
	,LTRIM(RTRIM(MARKET_CONCENTRATION_INDEX)) as MarketConcentrationIndex
	,LTRIM(RTRIM(FINANCIAL_DATA_DATE)) as FinancialDataDate
	,LTRIM(RTRIM(CBSA_CODE)) as CBSACode
	,LTRIM(RTRIM(FULL_CENSUS_TRACT)) as FullCensusTract
	,LTRIM(RTRIM(POPULATION_DENSITY)) as PopulationDensity
	,LTRIM(RTRIM(STATE_NUMBER)) as StateNumber
	,LTRIM(RTRIM(COUNTY_NUMBER)) as CountyNumber
	,LTRIM(RTRIM(HQ_PHONE)) as HQPhone
	,LTRIM(RTRIM(HOSPITAL_PARENT_ID)) as HospitalParentID
	,LTRIM(RTRIM(HOSPITAL_PARENT_NAME)) as HospitalParentName
	,LTRIM(RTRIM(TYPE_OF_OWNERSHIP)) as TypeOfOwnership
	,LTRIM(RTRIM(COMPANY_STATUS)) as CompanyStatus
	,LTRIM(RTRIM(PARTICIPATES_IN_MEDICARE)) as ParticipatesInMedicare
	,LTRIM(RTRIM(PARTICIPATES_IN_MEDICAID)) as ParticipatesInMedicaid
	,LTRIM(RTRIM(DATE_FISCAL_YEAR_END)) as DateFiscalYearEnd
	,LTRIM(RTRIM(HOSPITAL_OWNERSHIP)) as HospitalOwnership
	,LTRIM(RTRIM(NETWORK_NAME)) as CLANetworkName
	,LTRIM(RTRIM(HOSPITAL_NAME)) as CLAProviderName
    ,if(PROVIDER_NUMBER like "%Closed%","Closed","Active") as MedicareProviderStatus
    ,Source_Table as SourceTable
    ,"Client000000001 - Create Dimensions" as CreatedBy
    ,current_timestamp() as CreatedDate
    ,timestamp(NULL) as UpdateDate
from {0}
""".format("client000000001.StgDimProviderView")
df=spark.sql(sql)

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

df \
  .write \
  .mode("overwrite") \
  .saveAsTable(databaseTableName)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Write Dimension to Query Zone (Enriched)

# COMMAND ----------

try:
  df \
    .repartition(numPartitions) \
    .write \
    .mode("overwrite") \
    .format("delta") \
    .save(enrichedPath)
except Exception as e:
  sourceName = "Create Dimensions - Write to Query Zone (Enriched)"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Log Completion

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Completed
# MAGIC val logMessage = "Completed"
# MAGIC val notebookContext = ""
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

log_event_notebook_end(notebookExecutionLogKey=notebookExecutionLogKey, notebookStatus="SUCCEEDED", notebookName=notebookName, notebookExecutionGroupName="")
dbutils.notebook.exit("Succeeded")