# MAGIC %md
# MAGIC # Client000000001 - Create FactCostOfCare
# MAGIC ###### Author: Mike Sherrill 9/30/19
# MAGIC 
# MAGIC This notebook is used to create FactCostOfCare from spark tables created during query zone enrich processing.  It creates spark tables and writes to the enriched zone.  
# MAGIC #### Usage
# MAGIC Supply the parameters above and run the notebook.  
# MAGIC 
# MAGIC #### Prerequisites
# MAGIC 1. Data must exist in the Spark tables.   
# MAGIC 
# MAGIC #### Details

# COMMAND ----------

# MAGIC %md
# MAGIC #### Initialize Framework

# COMMAND ----------

dbutils.widgets.text(name="containerName", defaultValue="client000000001", label="Container Name")
containerName = dbutils.widgets.get("containerName")

# COMMAND ----------

# MAGIC %run ./Framework/Secrets_Databricks_Container

# COMMAND ----------

# MAGIC %run ./Framework/Neudesic_Framework_Functions

# COMMAND ----------

dbutils.widgets.text(name="parentPipeLineExecutionLogKey", defaultValue="-1", label="Parent Pipeline Execution Log Key")
dbutils.widgets.text(name="numPartitions", defaultValue="8", label="Number of Partitions")

parentPipeLineExecutionLogKey = dbutils.widgets.get("parentPipeLineExecutionLogKey")
fullPathPrefix = "abfss://" + containerName + "@" + adlsGen2StorageAccountName + ".dfs.core.windows.net" 

numPartitions = int(dbutils.widgets.get("numPartitions"))


# COMMAND ----------

notebookName = "Client000000001 - Create FactCostOfCare"
notebookExecutionLogKey = log_event_notebook_start(notebookName,parentPipeLineExecutionLogKey)
print("Notebook Execution Log Key: {0}".format(notebookExecutionLogKey))

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Starting
# MAGIC val notebookPath = dbutils.notebook.getContext.notebookPath.get
# MAGIC val logMessage = "Starting"
# MAGIC val notebookContext = dbutils.notebook.getContext().toJson
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

# MAGIC %md
# MAGIC #### Create Provider Dimension

# COMMAND ----------

tableName = "FactCostOfCare"

databaseTableName = containerName + "." + tableName

enrichedPath = fullPathPrefix + "/Query/Enriched/" + tableName

# COMMAND ----------

# MAGIC %md
# MAGIC #### Create Stg View

# COMMAND ----------

sql = """CREATE OR REPLACE VIEW client000000001.StgFactCostOfCareView AS
SELECT
	 HOSPITAL_ID as ProviderID
	,FIRM_TYPE as FirmSubType
	,double(TOTAL_PMTS) as TotalPayments
	,double(TOTAL_CHARGES) as TotalCharges
	,int(TOTAL_CLAIMS) as TotalClaims
	,int(UNIQUE_PATIENTS) as UniquePatients
	,LTRIM(RTRIM(PATIENT_UNIVERSE)) as PatientUniverse
	,'HHA_Care_By_Provider_Type' as SourceTable
FROM {0} 
UNION ALL
SELECT
	 HOSPITAL_ID as ProviderID
	,FIRM_TYPE as FirmSubType
	,double(TOTAL_PMTS) as TotalPayments
	,double(TOTAL_CHARGES) as TotalCharges
	,int(TOTAL_CLAIMS) as TotalClaims
	,int(UNIQUE_PATIENTS) as UniquePatients
	,LTRIM(RTRIM(PATIENT_UNIVERSE)) as PatientUniverse
	,'LTC_SNF_Care_By_Provider_Type' as SourceTable
FROM {1}  
UNION ALL
SELECT
	 HOSPITAL_ID as ProviderID
	,FIRM_TYPE as FirmSubType
	,double(TOTAL_PMTS) as TotalPayments
	,double(TOTAL_CHARGES) as TotalCharges
	,int(TOTAL_CLAIMS) as TotalClaims
	,int(UNIQUE_PATIENTS) as UniquePatients
	,LTRIM(RTRIM(PATIENT_UNIVERSE)) as PatientUniverse
	,'Hospital_Care_By_Provider_Type' as SourceTable
FROM {2}  
""".format("client000000001.HHA_Care_By_Provider_Type", "client000000001.LTC_SNF_Care_By_Provider_Type", "client000000001.Hospital_Care_By_Provider_Type")
df=spark.sql(sql)

# COMMAND ----------

sql = """
SELECT
     COALESCE(p.ProviderID, '-1') as ProviderKey
    ,f.ProviderID
	,FirmSubType
	,TotalPayments
	,TotalCharges
	,TotalClaims
	,UniquePatients
	,PatientUniverse
	,f.SourceTable
    ,"Client000000001 - Create FactCostOfCare" as CreatedBy
    ,current_timestamp() as CreatedDate
    ,timestamp(NULL) as UpdateDate
from {0} f
LEFT JOIN client000000001.dimprovider p on f.ProviderID = p.ProviderID
""".format("client000000001.StgFactCostOfCareView")
df=spark.sql(sql)

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

df \
  .write \
  .mode("overwrite") \
  .saveAsTable(databaseTableName)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Write Fact to Query Zone (Enriched)

# COMMAND ----------

try:
  df \
    .repartition(numPartitions) \
    .write \
    .mode("overwrite") \
    .format("delta") \
    .save(enrichedPath)
except Exception as e:
  sourceName = "Create FactCostOfCare - Write to Query Zone (Enriched)"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Log Completion

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Completed
# MAGIC val logMessage = "Completed"
# MAGIC val notebookContext = ""
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

log_event_notebook_end(notebookExecutionLogKey=notebookExecutionLogKey, notebookStatus="SUCCEEDED", notebookName=notebookName, notebookExecutionGroupName="")
dbutils.notebook.exit("Succeeded")