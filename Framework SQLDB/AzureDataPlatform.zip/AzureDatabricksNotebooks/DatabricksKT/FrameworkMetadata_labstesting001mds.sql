DECLARE @ContainerExecutionGroupName VARCHAR(255) = 'labstesting001mds';
DECLARE @ContainerName varchar(255) = lower(@ContainerExecutionGroupName);
DECLARE @DataFactoryName VARCHAR(255) = 'TBD';


--DELETE NotebookExecutionPlan
DELETE NotebookExecutionPlan
FROM NotebookExecutionPlan p
JOIN Notebook n ON p.NotebookKey = n.NotebookKey
JOIN Container c ON p.ContainerKey = c.ContainerKey
WHERE c.ContainerName = @ContainerName

--DELETE NotebookParameter
DELETE NotebookParameter
FROM NotebookParameter p
JOIN Notebook n ON p.NotebookKey = n.NotebookKey
WHERE NotebookName like @ContainerName+'%'

--DELETE NotebookExecutionGroup
DELETE NotebookExecutionGroup
FROM NotebookExecutionGroup neg
JOIN ContainerExecutionGroup ceg ON ceg.ContainerExecutionGroupKey = neg.ContainerExecutionGroupKey
JOIN Container c on ceg.ContainerKey = c.ContainerKey
WHERE c.ContainerName = @ContainerName

DECLARE @NotebookExecutionGroupName VARCHAR(255) = @ContainerExecutionGroupName+' Convert';


EXEC dbo.uspInsertNotebookParameters
 @NotebookName='labstesting001mds_Landing_Convert'
,@NotebookExecutionGroupName=@NotebookExecutionGroupName
,@DataFactoryName=@DataFactoryName
,@ContainerName=@ContainerName
,@ContainerExecutionGroupName=@ContainerExecutionGroupName
,@NotebookOrder=10
,@NumPartitions = 2
,@QueryZoneSchemaName = ''
,@QueryZoneTableName = '' 
,@ExternalDataPath = '/Landing/labs001mds'
,@RawDataPath = '/Raw/labs001mds'
,@FilePath = ''
,@Delimiter = ''
,@FileExtension = ''
,@HasHeader = 0
,@QueryZoneNotebookPath = ''
,@RawZoneNotebookPath = '/Framework/Raw Zone Processing - Landing to Raw Conversion Split_'
,@SummaryZoneNotebookPath = ''
,@SummaryZoneRemoveHDFSOutputCommitterFiles = ''
,@SummaryZoneRenameSummaryOutputFile = ''
,@PrimaryKeyColumns = ''
,@TimestampColumns = ''
,@SanctionedZoneNotebookPath = '';


SELECT @NotebookExecutionGroupName = @ContainerExecutionGroupName+' Ingest';

EXEC dbo.uspInsertNotebookParameters
 @NotebookName='labstesting001mds_Data_Analytics_Desktop_Usage_201903_Ingest'
,@NotebookExecutionGroupName=@NotebookExecutionGroupName
,@DataFactoryName=@DataFactoryName
,@ContainerName=@ContainerName
,@ContainerExecutionGroupName=@ContainerExecutionGroupName
,@NotebookOrder=10
,@NumPartitions=2
,@QueryZoneSchemaName = 'labs001mds'
,@QueryZoneTableName = 'Data_Analytics_Desktop_Usage_201903' 
,@ExternalDataPath = ''
,@RawDataPath = '/Raw/labs001mds/Data Analytics Desktop Usage_201903'
,@FilePath = ''
,@Delimiter = ''
,@FileExtension = ''
,@HasHeader = 0
,@QueryZoneNotebookPath = '/Framework/Query Zone Processing - Overwrite Delta Lake'
,@RawZoneNotebookPath = ''
,@SummaryZoneNotebookPath = ''
,@SummaryZoneRemoveHDFSOutputCommitterFiles = ''
,@SummaryZoneRenameSummaryOutputFile = ''
,@PrimaryKeyColumns = ''
,@TimestampColumns = ''
,@SanctionedZoneNotebookPath = '';


EXEC dbo.uspInsertNotebookParameters
 @NotebookName='labstesting001mds_Data_Analytics_Desktop_Usage_201904_Ingest'
,@NotebookExecutionGroupName=@NotebookExecutionGroupName
,@DataFactoryName=@DataFactoryName
,@ContainerName=@ContainerName
,@ContainerExecutionGroupName=@ContainerExecutionGroupName
,@NotebookOrder=10
,@NumPartitions=2
,@QueryZoneSchemaName = 'labs001mds'
,@QueryZoneTableName = 'Data_Analytics_Desktop_Usage_201904' 
,@ExternalDataPath = ''
,@RawDataPath = '/Raw/labs001mds/Data Analytics Desktop Usage_201904'
,@FilePath = ''
,@Delimiter = ''
,@FileExtension = ''
,@HasHeader = 0
,@QueryZoneNotebookPath = '/Framework/Query Zone Processing - Overwrite Delta Lake'
,@VacuumRetentionHours = 0
,@RawZoneNotebookPath = ''
,@SummaryZoneNotebookPath = ''
,@SummaryZoneRemoveHDFSOutputCommitterFiles = ''
,@SummaryZoneRenameSummaryOutputFile = ''
,@PrimaryKeyColumns = ''
,@TimestampColumns = ''
,@SanctionedZoneNotebookPath = '';


EXEC dbo.uspInsertNotebookParameters
 @NotebookName='labstesting001mds_Data_Analytics_Desktop_Usage_201906_Ingest'
,@NotebookExecutionGroupName=@NotebookExecutionGroupName
,@DataFactoryName=@DataFactoryName
,@ContainerName=@ContainerName
,@ContainerExecutionGroupName=@ContainerExecutionGroupName
,@NotebookOrder=10
,@NumPartitions = 2
,@QueryZoneSchemaName = 'labs001mds'
,@QueryZoneTableName = 'Data_Analytics_Desktop_Usage_201906' 
,@ExternalDataPath = ''
,@RawDataPath = '/Raw/labs001mds/Data Analytics Desktop Usage_201906'
,@FilePath = ''
,@Delimiter = ''
,@FileExtension = ''
,@HasHeader = 0
,@QueryZoneNotebookPath = '/Framework/Query Zone Processing - Overwrite Delta Lake'
,@VacuumRetentionHours = 0
,@RawZoneNotebookPath = ''
,@SummaryZoneNotebookPath = ''
,@SummaryZoneRemoveHDFSOutputCommitterFiles = ''
,@SummaryZoneRenameSummaryOutputFile = ''
,@PrimaryKeyColumns = ''
,@TimestampColumns = ''
,@SanctionedZoneNotebookPath = '';


EXEC dbo.uspInsertNotebookParameters
 @NotebookName='labstesting001mds_Data_Analytics_Desktop_Usage_201907_Ingest'
,@NotebookExecutionGroupName=@NotebookExecutionGroupName
,@DataFactoryName=@DataFactoryName
,@ContainerName=@ContainerName
,@ContainerExecutionGroupName=@ContainerExecutionGroupName
,@NotebookOrder=10
,@NumPartitions = 2
,@QueryZoneSchemaName = 'labs001mds'
,@QueryZoneTableName = 'Data_Analytics_Desktop_Usage_201907' 
,@ExternalDataPath = ''
,@RawDataPath = '/Raw/labs001mds/Data Analytics Desktop Usage_201907'
,@FilePath = ''
,@Delimiter = ''
,@FileExtension = ''
,@HasHeader = 0
,@QueryZoneNotebookPath = '/Framework/Query Zone Processing - Overwrite Delta Lake'
,@VacuumRetentionHours = 0
,@RawZoneNotebookPath = ''
,@SummaryZoneNotebookPath = ''
,@SummaryZoneRemoveHDFSOutputCommitterFiles = ''
,@SummaryZoneRenameSummaryOutputFile = ''
,@PrimaryKeyColumns = ''
,@TimestampColumns = ''
,@SanctionedZoneNotebookPath = '';


EXEC dbo.uspInsertNotebookParameters
 @NotebookName='labstesting001mds_Concurrent_Desktop_Analytics_Ingest'
,@NotebookExecutionGroupName=@NotebookExecutionGroupName
,@DataFactoryName=@DataFactoryName
,@ContainerName=@ContainerName
,@ContainerExecutionGroupName=@ContainerExecutionGroupName
,@NotebookOrder=10
,@NumPartitions = 2
,@QueryZoneSchemaName = 'labs001mds'
,@QueryZoneTableName = 'Concurrent_Desktop_Analytics' 
,@ExternalDataPath = ''
,@RawDataPath = '/Raw/labs001mds/Concurrent Desktop Analytics'
,@FilePath = ''
,@Delimiter = ''
,@FileExtension = ''
,@HasHeader = 0
,@QueryZoneNotebookPath = '/Framework/Query Zone Processing - Overwrite Delta Lake'
,@VacuumRetentionHours = 0
,@RawZoneNotebookPath = ''
,@SummaryZoneNotebookPath = ''
,@SummaryZoneRemoveHDFSOutputCommitterFiles = ''
,@SummaryZoneRenameSummaryOutputFile = ''
,@PrimaryKeyColumns = ''
,@TimestampColumns = ''
,@SanctionedZoneNotebookPath = '';

EXEC dbo.uspInsertNotebookParameters
 @NotebookName='labstesting001mds_Data_Analytics_Concurrent_Sessions_Ingest'
,@NotebookExecutionGroupName=@NotebookExecutionGroupName
,@DataFactoryName=@DataFactoryName
,@ContainerName=@ContainerName
,@ContainerExecutionGroupName=@ContainerExecutionGroupName
,@NotebookOrder=10
,@NumPartitions = 2
,@QueryZoneSchemaName = 'labs001mds'
,@QueryZoneTableName = 'Data_Analytics_Concurrent_Sessions' 
,@ExternalDataPath = ''
,@RawDataPath = '/Raw/labs001mds/Data Analytics Concurrent Sessions'
,@FilePath = ''
,@Delimiter = ''
,@FileExtension = ''
,@HasHeader = 0
,@QueryZoneNotebookPath = '/Framework/Query Zone Processing - Overwrite Delta Lake'
,@VacuumRetentionHours = 0
,@RawZoneNotebookPath = ''
,@SummaryZoneNotebookPath = ''
,@SummaryZoneRemoveHDFSOutputCommitterFiles = ''
,@SummaryZoneRenameSummaryOutputFile = ''
,@PrimaryKeyColumns = ''
,@TimestampColumns = ''
,@SanctionedZoneNotebookPath = '';

EXEC dbo.uspInsertNotebookParameters
 @NotebookName='labstesting001mds_Concurrent_Connections_Ingest'
,@NotebookExecutionGroupName=@NotebookExecutionGroupName
,@DataFactoryName=@DataFactoryName
,@ContainerName=@ContainerName
,@ContainerExecutionGroupName=@ContainerExecutionGroupName
,@NotebookOrder=10
,@NumPartitions = 2
,@QueryZoneSchemaName = 'labs001mds'
,@QueryZoneTableName = 'Concurrent_Connections' 
,@ExternalDataPath = ''
,@RawDataPath = '/Raw/labs001mds/Concurrent Connections'
,@FilePath = ''
,@Delimiter = ''
,@FileExtension = ''
,@HasHeader = 0
,@QueryZoneNotebookPath = '/Framework/Query Zone Processing - Overwrite Delta Lake'
,@VacuumRetentionHours = 0
,@RawZoneNotebookPath = ''
,@SummaryZoneNotebookPath = ''
,@SummaryZoneRemoveHDFSOutputCommitterFiles = ''
,@SummaryZoneRenameSummaryOutputFile = ''
,@PrimaryKeyColumns = ''
,@TimestampColumns = ''
,@SanctionedZoneNotebookPath = '';


---------------------------------------------ENRICH AND PUBLISH-----------------------------------------------------------------------

SELECT  @NotebookExecutionGroupName = @ContainerExecutionGroupName+' Enrich and Publish';

EXEC dbo.uspInsertNotebookParameters
 @NotebookName='labstesting001mds_Data_Analytics_Desktop_Usage_Enrich_Publish'
,@NotebookExecutionGroupName=@NotebookExecutionGroupName
,@DataFactoryName=@DataFactoryName
,@ContainerName=@ContainerName
,@ContainerExecutionGroupName=@ContainerExecutionGroupName
,@NotebookOrder=10
,@NumPartitions = 2
,@QueryZoneSchemaName = 'labs001mds'
,@QueryZoneTableName = 'Data_Analytics_Desktop_Usage' 
,@CombineFiles = '201903,201904,201906,201907'
,@ExternalDataPath = ''
,@RawDataPath = ''
,@FilePath = ''
,@Delimiter = ''
,@FileExtension = ''
,@HasHeader = 0
,@QueryZoneNotebookPath = '/Query Zone Processing - Enrich Analytics Desktop Usage'
,@VacuumRetentionHours = 168
,@RawZoneNotebookPath = ''
,@SummaryZoneNotebookPath = ''
,@SummaryZoneRemoveHDFSOutputCommitterFiles = '1'
,@SummaryZoneRenameSummaryOutputFile = '1'
,@PrimaryKeyColumns = ''
,@TimestampColumns = ''
,@SanctionedZoneNotebookPath = '';

EXEC dbo.uspInsertNotebookParameters
 @NotebookName='labstesting001mds_Concurrent_Desktop_Analytics_Enrich_Publish'
,@NotebookExecutionGroupName=@NotebookExecutionGroupName
,@DataFactoryName=@DataFactoryName
,@ContainerName=@ContainerName
,@ContainerExecutionGroupName=@ContainerExecutionGroupName
,@NotebookOrder=10
,@NumPartitions = 2
,@QueryZoneSchemaName = 'labs001mds'
,@QueryZoneTableName = 'Concurrent_Desktop_Analytics' 
,@ExternalDataPath = ''
,@RawDataPath = ''
,@FilePath = ''
,@Delimiter = ''
,@FileExtension = ''
,@HasHeader = 0
,@QueryZoneNotebookPath = '/Query Zone Processing - Enrich Sessions'
,@VacuumRetentionHours = 168
,@RawZoneNotebookPath = ''
,@SummaryZoneNotebookPath = ''
,@SummaryZoneRemoveHDFSOutputCommitterFiles = '1'
,@SummaryZoneRenameSummaryOutputFile = '1'
,@PrimaryKeyColumns = ''
,@TimestampColumns = ''
,@SanctionedZoneNotebookPath = '';

EXEC dbo.uspInsertNotebookParameters
 @NotebookName='labstesting001mds_Data_Analytics_Concurrent_Sessions_Enrich_Publish'
,@NotebookExecutionGroupName=@NotebookExecutionGroupName
,@DataFactoryName=@DataFactoryName
,@ContainerName=@ContainerName
,@ContainerExecutionGroupName=@ContainerExecutionGroupName
,@NotebookOrder=10
,@NumPartitions = 2
,@QueryZoneSchemaName = 'labs001mds'
,@QueryZoneTableName = 'Data_Analytics_Concurrent_Sessions' 
,@ExternalDataPath = ''
,@RawDataPath = ''
,@FilePath = ''
,@Delimiter = ''
,@FileExtension = ''
,@HasHeader = 0
,@QueryZoneNotebookPath = '/Query Zone Processing - Enrich Sessions'
,@VacuumRetentionHours = 168
,@RawZoneNotebookPath = ''
,@SummaryZoneNotebookPath = ''
,@SummaryZoneRemoveHDFSOutputCommitterFiles = '1'
,@SummaryZoneRenameSummaryOutputFile = '1'
,@PrimaryKeyColumns = ''
,@TimestampColumns = ''
,@SanctionedZoneNotebookPath = '';

EXEC dbo.uspInsertNotebookParameters
 @NotebookName='labstesting001mds_Concurrent_Connections_Enrich_Publish'
,@NotebookExecutionGroupName=@NotebookExecutionGroupName
,@DataFactoryName=@DataFactoryName
,@ContainerName=@ContainerName
,@ContainerExecutionGroupName=@ContainerExecutionGroupName
,@NotebookOrder=10
,@NumPartitions = 2
,@QueryZoneSchemaName = 'labs001mds'
,@QueryZoneTableName = 'Concurrent_Connections' 
,@ExternalDataPath = ''
,@RawDataPath = ''
,@FilePath = ''
,@Delimiter = ''
,@FileExtension = ''
,@HasHeader = 0
,@QueryZoneNotebookPath = '/Query Zone Processing - Enrich Sessions'
,@VacuumRetentionHours = 168
,@RawZoneNotebookPath = ''
,@SummaryZoneNotebookPath = ''
,@SummaryZoneRemoveHDFSOutputCommitterFiles = '1'
,@SummaryZoneRenameSummaryOutputFile = '1'
,@PrimaryKeyColumns = ''
,@TimestampColumns = ''
,@SanctionedZoneNotebookPath = '';


SELECT  @NotebookExecutionGroupName = @ContainerExecutionGroupName+' Sanction and Publish';

EXEC dbo.uspInsertNotebookParameters
 @NotebookName='labstesting001mds_DimDesktopUser_Sanction_Publish'
,@NotebookExecutionGroupName=@NotebookExecutionGroupName
,@DataFactoryName=@DataFactoryName
,@ContainerName=@ContainerName
,@ContainerExecutionGroupName=@ContainerExecutionGroupName
,@NotebookOrder=10
,@NumPartitions = 2
,@QueryZoneSchemaName = 'labs001mds'
,@QueryZoneTableName = 'DimDesktopUser' 
,@ExternalDataPath = ''
,@RawDataPath = ''
,@FilePath = ''
,@Delimiter = ''
,@FileExtension = ''
,@HasHeader = 0
,@QueryZoneNotebookPath = '/labstesting001mds - Create DimDesktopUser'
,@RawZoneNotebookPath = ''
,@SummaryZoneNotebookPath = '/Framework/Summary Zone Processing - Export CSV'
,@SummaryZoneRemoveHDFSOutputCommitterFiles = '1'
,@SummaryZoneRenameSummaryOutputFile = '1'
,@PrimaryKeyColumns = ''
,@TimestampColumns = ''
,@SanctionedZoneNotebookPath = '/Framework/Sanctioned Zone Processing - Load Azure SQL DW';


EXEC dbo.uspInsertNotebookParameters
 @NotebookName='labstesting001mds_FactDataAnalyticsDesktopUsage_Sanction_Publish'
,@NotebookExecutionGroupName=@NotebookExecutionGroupName
,@DataFactoryName=@DataFactoryName
,@ContainerName=@ContainerName
,@ContainerExecutionGroupName=@ContainerExecutionGroupName
,@NotebookOrder=10
,@NumPartitions = 2
,@QueryZoneSchemaName = 'labs001mds'
,@QueryZoneTableName = 'FactDataAnalyticsDesktopUsage' 
,@ExternalDataPath = ''
,@RawDataPath = ''
,@FilePath = ''
,@Delimiter = ''
,@FileExtension = ''
,@HasHeader = 0
,@QueryZoneNotebookPath = '/labstesting001mds - Create FactDataAnalyticsDesktopUsage'
,@RawZoneNotebookPath = ''
,@SummaryZoneNotebookPath = '/Framework/Summary Zone Processing - Export CSV'
,@SummaryZoneRemoveHDFSOutputCommitterFiles = '1'
,@SummaryZoneRenameSummaryOutputFile = '1'
,@PrimaryKeyColumns = ''
,@TimestampColumns = ''
,@SanctionedZoneNotebookPath = '/Framework/Sanctioned Zone Processing - Load Azure SQL DW';

EXEC dbo.uspInsertNotebookParameters
 @NotebookName='labstesting001mds_FactSessions_Sanction_Publish'
,@NotebookExecutionGroupName=@NotebookExecutionGroupName
,@DataFactoryName=@DataFactoryName
,@ContainerName=@ContainerName
,@ContainerExecutionGroupName=@ContainerExecutionGroupName
,@NotebookOrder=10
,@NumPartitions = 2
,@QueryZoneSchemaName = 'labs001mds'
,@QueryZoneTableName = 'FactSessions' 
,@ExternalDataPath = ''
,@RawDataPath = ''
,@FilePath = ''
,@Delimiter = ''
,@FileExtension = ''
,@HasHeader = 0
,@QueryZoneNotebookPath = '/labstesting001mds - Create FactSessions'
,@RawZoneNotebookPath = ''
,@SummaryZoneNotebookPath = '/Framework/Summary Zone Processing - Export CSV'
,@SummaryZoneRemoveHDFSOutputCommitterFiles = '1'
,@SummaryZoneRenameSummaryOutputFile = '1'
,@PrimaryKeyColumns = ''
,@TimestampColumns = ''
,@SanctionedZoneNotebookPath = '/Framework/Sanctioned Zone Processing - Load Azure SQL DW';