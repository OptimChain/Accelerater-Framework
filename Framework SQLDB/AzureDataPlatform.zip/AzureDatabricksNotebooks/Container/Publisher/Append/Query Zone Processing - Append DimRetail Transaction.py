# Databricks notebook source
# MAGIC  
# MAGIC  
# MAGIC  
# MAGIC %md
# MAGIC # Query Zone Processing - Append DimRetailTransaction
# MAGIC ###### Author: Ranga Bondada 12/01/2020
# MAGIC 
# MAGIC Data Lake pattern for tables that are staged and merged into the final enriched version.  Takes a file from the raw data path and overwrites the table in the Query zone.      
# MAGIC 
# MAGIC #### Usage
# MAGIC Supply the parameters above and run the notebook.  
# MAGIC 
# MAGIC #### Prerequisites
# MAGIC 1. Data must exist in the Data Lake /query zone (current State).   
# MAGIC 
# MAGIC #### Details

# COMMAND ----------

# MAGIC %md
# MAGIC #### Initialize Framework

# COMMAND ----------

dbutils.widgets.text(name="containerName", defaultValue="brtl", label="Container Name")
containerName = dbutils.widgets.get("containerName")

# COMMAND ----------

# MAGIC %run ../Framework/Secrets_Databricks_Container

# COMMAND ----------

# MAGIC %run ../Framework/Neudesic_Framework_Functions

# COMMAND ----------

spark.conf.set("spark.databricks.delta.merge.joinBasedMerge.enabled", True)

# COMMAND ----------

dbutils.widgets.text(name="parentPipeLineExecutionLogKey", defaultValue="-1", label="Parent Pipeline Execution Log Key")
dbutils.widgets.text(name="numPartitions", defaultValue="32", label="Number of Partitions")
dbutils.widgets.text(name="schemaName", defaultValue="brtl", label="Schema Name")
dbutils.widgets.text(name="tableName", defaultValue="AssistedOrders", label="Table Name")
dbutils.widgets.text(name="vacuumRetentionHours", defaultValue="", label="Vacuum Retention Hours")
dbutils.widgets.text(name="primaryKeyColumns", defaultValue="", label="Primary Key Columns")
dbutils.widgets.text(name="timestampColumns", defaultValue="", label="Timestamp Columns")

parentPipeLineExecutionLogKey = dbutils.widgets.get("parentPipeLineExecutionLogKey")
fullPathPrefix = "abfss://" + containerName + "@" + adlsGen2StorageAccountName + ".dfs.core.windows.net" 

numPartitions = int(dbutils.widgets.get("numPartitions"))


schemaName = dbutils.widgets.get("schemaName")
tableName = dbutils.widgets.get("tableName")
destinationTableName = tableName

fullyQualifiedTableName = schemaName + "." + destinationTableName
primaryKeyColumns = dbutils.widgets.get("primaryKeyColumns")
timestampColumns = dbutils.widgets.get("timestampColumns")

enrichedPath = fullPathPrefix + "/Query/Enriched/" + destinationTableName
databaseTableName = containerName + "." + destinationTableName
vacuumRetentionHours = dbutils.widgets.get("vacuumRetentionHours")

currentStatePath = fullPathPrefix + "/Query/CurrentState/" + tableName

# COMMAND ----------

stageTableName = "RETAILTRANSACTIONTABLE"

databaseStageTableName = schemaName + "." + stageTableName

currentStateStagePath = fullPathPrefix + "/Query/CurrentState/" + stageTableName

# COMMAND ----------

notebookName = "Query Zone Processing - Append DimRetailTransaction"
notebookExecutionLogKey = log_event_notebook_start(notebookName,parentPipeLineExecutionLogKey)
print("Notebook Execution Log Key: {0}".format(notebookExecutionLogKey))

# COMMAND ----------

print("Schema Name: {0}".format(schemaName))
# print("Source Table Name: {0}".format(stageTableName))
print("Table Name: {0}".format(tableName))
print("Fully Qualified Table Name: {0}".format(fullyQualifiedTableName))
print("Number of Partitions: {0}".format(numPartitions))
print("Current State Path: {0}".format(currentStatePath))
# print("Current State Stage Path: {0}".format(currentStateStagePath))
print("Enriched State Path: {0}".format(enrichedPath))

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Starting
# MAGIC val notebookPath = dbutils.notebook.getContext.notebookPath.get
# MAGIC val logMessage = "Starting"
# MAGIC val notebookContext = dbutils.notebook.getContext().toJson
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read Existing Data from Query Zone (CurrentState}

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format(databaseStageTableName)
spark.sql(sql)


sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.PARTITIONS")
spark.sql(sql)

sql = """
DROP TABLE IF EXISTS {0}
""".format(tableName)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format(databaseStageTableName, currentStateStagePath)
spark.sql(sql)



sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl.PARTITIONS", fullPathPrefix + "/Query/CurrentState/" + "PARTITIONS")
spark.sql(sql)

#sql = """
#CREATE TABLE IF NOT EXISTS {0}
#USING delta
#LOCATION '{1}'
#""".format(tableName, currentStatePath)
#spark.sql(sql)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read STG Data from Query Zone (CurrentState}

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP VIEW IF EXISTS brtl.DimRetailTransactionView

# COMMAND ----------

stgViewName =  "brtl.DimRetailTransactionView"

sql="""
CREATE OR REPLACE VIEW {0} AS
SELECT 
	rt.RECID AS RecordId,
	rt.DATAAREAID as CompanyCode,
	rt.STORE as StoreCode,
	rt.TERMINAL AS TerminalCode,
	rt.TRANSACTIONID as TransactionCode,
	rt.RECEIPTID as ReceiptNumber,
	rt.STATEMENTID as StatementNumber,
	STRING(rt.STATEMENTCODE) as StatementCode,
	rt.SALESORDERID as SalesOrderNumber,
	STRING(
		case rt.TYPE 
		when 0 then 'Logoff'
		when 1 then 'Logon'
		when 2 then 'Sales'
		when 3 then 'Payment'
		when 4 then 'Remove tender'
		when 5 then 'Float entry'
		when 6 then 'Change tender'
		when 7 then 'Tender declaration'
		when 8 then 'Voided'
		when 9 then 'Open drawer'
		when 10 then 'Negative adjustment'
		when 11 then 'Physical inventory'
		when 12 then 'End of day'
		when 13 then 'End of shift'
		when 14 then 'Sales order'
		when 15 then 'Customer invoice'
		when 16 then 'Bank drop'
		when 17 then 'Safe drop'
		when 18 then 'Income expense'
		when 19 then 'Customer order'
		when 20 then 'Starting amount'
		when 21 then 'Suspend shift'
		when 22 then 'Blind close shift'
		when 23 then 'Close shift'
		when 24 then 'Print X report'
		when 25 then 'Print Z report'
		when 26 then 'Manager authorization'
		when 27 then 'Pending Sales Order'
		when 28 then 'Kit disassembly'
		when 29 then 'Reset password'
		when 30 then 'Change password'
		when 31 then 'No-sales fiscal document'
		ELSE 'N/A'
		end 
	) as TransactionType,
	STRING(
		case rt.ENTRYSTATUS
			WHEN 0 THEN 'None'
			WHEN 1 THEN 'Voided'
			WHEN 2 THEN 'Posted'
			WHEN 3 THEN 'Concluded'
			WHEN 4 THEN 'Cancelled'
			WHEN 5 THEN 'OnHold'
			WHEN 6 THEN 'Training'
			ELSE 'N/A'
		end 
	) as EntryStatus,
	--rt.SYS_CHANGE_OPERATION,
	--rt.SYS_CHANGE_VERSION,
	'Query Zone Processing - Append DimRetailTransaction' AS Created_By,
    '' AS Modified_By,
    STRING(CURRENT_TIMESTAMP()) AS Last_Created,
    '1900-01-01 00:00:00.0000000' AS Last_Modified
FROM  brtl.RETAILTRANSACTIONTABLE AS rt 
INNER JOIN brtl.PARTITIONS p on p.RECID = rt.PARTITION and p.PARTITIONKEY = 'initial'
""".format(stgViewName)
display(spark.sql(sql))

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT RecordId,COUNT(*) 
# MAGIC FROM brtl.DimRetailTransactionView
# MAGIC GROUP BY RecordId
# MAGIC HAVING COUNT(*)  > 1

# COMMAND ----------

sql="""
SELECT *
  FROM {0}
""".format(stgViewName)
stg_df=(spark.sql(sql))

# COMMAND ----------

display(stg_df)

# COMMAND ----------

try:
  #read enrichedPath into a dataframe if it exists, otherwise create it
  dst_df = spark.read \
    .format("delta") \
    .load(enrichedPath) \
    .dropDuplicates()
except Exception as e:
   (stg_df \
    .write \
    .mode("overwrite") \
    .format("delta") \
    .save(enrichedPath)
    )

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE {0}
USING delta
LOCATION '{1}'
""".format(databaseTableName, enrichedPath)
spark.sql(sql)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT RecordId,COUNT(*) 
# MAGIC FROM brtl.DimRetailTransaction
# MAGIC GROUP BY RecordId
# MAGIC HAVING COUNT(*)  > 1

# COMMAND ----------

spark.conf.set("spark.sql.crossJoin.enabled", "true")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Append Data in Query Zone (Enriched)

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC MERGE INTO brtl.DimRetailTransaction AS dim
# MAGIC USING brtl.DimRetailTransactionView AS stg
# MAGIC ON dim.RecordId = stg.RecordId
# MAGIC 
# MAGIC WHEN MATCHED THEN
# MAGIC   DELETE

# COMMAND ----------

try:
  queryTableExists = (spark.table(databaseTableName) is not None)
except:
  queryTableExists = False

# COMMAND ----------

queryTableExists

# COMMAND ----------

try:
  if queryTableExists:
    (stg_df.repartition(numPartitions) \
      .write \
      .mode("append") \
      .option("mergeSchema", True) \
      .format("delta") \
      .save(enrichedPath)
    )
  else:
    (stg_df.repartition(numPartitions) \
      .write \
      .mode("overwrite") \
      .format("delta") \
      .save(enrichedPath)
    )
    sql = """
    CREATE TABLE {0}
    USING delta
    LOCATION '{1}'
    """.format(destinationTableName, enrichedPath)
    spark.sql(sql)
except Exception as e:
  sourceName = "Query Zone Processing - Append Databricks Delta: Write to Query Zone"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Append Data in to Synapse DW from Current State

# COMMAND ----------

sanctionedZoneNotebookPath = "../Framework/Sanctioned Zone Processing - Load Synapse DW Overwrite"
stageSchemaName = "stage"
stageTableName = "DimRetailTransactionView"

run_with_retry(sanctionedZoneNotebookPath, 1200, {"parentPipeLineExecutionLogKey": notebookExecutionLogKey, "containerName": containerName, "schemaName": stageSchemaName, "tableName": stageTableName, "numPartitions": numPartitions})

# COMMAND ----------

execsp = "DELETE A \
          FROM brtl.DimRetailTransaction AS A \
          INNER JOIN stage.DimRetailTransactionView AS stg \
          ON A.RecordId = stg.RecordId"
try:
  execute_sqldw_stored_procedure_no_results(execsp)
except:
  sourceName = "Destination Table does not exist"

# COMMAND ----------

blob_storage_account_name = adlsGen2StorageAccountName
blob_storage_container_name = "temp"

tempDir = "abfss://{}@{}.dfs.core.windows.net/".format(blob_storage_container_name, blob_storage_account_name) + dbutils.widgets.get("tableName")

# COMMAND ----------

sqlDwUrlSmall, connectionProperties = build_sqldw_jdbc_url_and_connectionProperties(sqldwservername, sqldwdatabasename, sqldwusername, sqldwpassword)

# COMMAND ----------

try:
  dst_df \
    .write \
    .format("com.databricks.spark.sqldw") \
    .mode("append") \
    .option("url", sqlDwUrlSmall) \
    .option("dbtable", fullyQualifiedTableName) \
    .option("useAzureMSI","True") \
    .option("maxStrLength",2048) \
    .option("tempdir", tempDir) \
    .save()
except Exception as e:
  sourceName = "Sanctioned Zone Processing - Load Azure SQL DW: Load Synapse SQL Data Warehouse"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

display(dst_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Drop Temporary Table and Views

# COMMAND ----------

dbutils.fs.rm(tempDir,True)

# COMMAND ----------

sql = """
DROP VIEW IF EXISTS {0}
""".format("brtl.DimRetailTransactionView")
spark.sql(sql)

# COMMAND ----------

sql = """
DROP VIEW IF EXISTS {0}
""".format(stgViewName)
spark.sql(sql)

# COMMAND ----------

execsp = "IF OBJECT_ID('stage.DimRetailTransactionView') IS NOT NULL DROP TABLE stage.DimRetailTransactionView"
execute_sqldw_stored_procedure_no_results(execsp)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Optimize and Vacuum Table

# COMMAND ----------

sql="""OPTIMIZE {0}""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

if vacuumRetentionHours != '':
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", False)
  spark.sql("VACUUM " + databaseTableName + " RETAIN " + vacuumRetentionHours + " HOURS")
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", True)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Log Completion

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Completed
# MAGIC val logMessage = "Completed"
# MAGIC val notebookContext = ""
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

log_event_notebook_end(notebookExecutionLogKey=notebookExecutionLogKey, notebookStatus="SUCCEEDED", notebookName=notebookName, notebookExecutionGroupName="")
dbutils.notebook.exit("Succeeded")