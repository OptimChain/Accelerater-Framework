# MAGIC  
# MAGIC  
# MAGIC  
# MAGIC %md
# MAGIC # Query Zone Processing - Append FCTAssistedOrders
# MAGIC ###### Author: Mike Sherrill 05/27/2020
# MAGIC 
# MAGIC Data Lake pattern for tables that are staged and merged into the final enriched version.  Takes a file from the raw data path and overwrites the table in the Query zone.      
# MAGIC 
# MAGIC #### Usage
# MAGIC Supply the parameters above and run the notebook.  
# MAGIC 
# MAGIC #### Prerequisites
# MAGIC 1. Data must exist in the Data Lake /query zone (current State).   
# MAGIC 
# MAGIC #### Details

# COMMAND ----------

# MAGIC %md
# MAGIC #### Initialize Framework

# COMMAND ----------

dbutils.widgets.text(name="containerName", defaultValue="brtl", label="Container Name")
containerName = dbutils.widgets.get("containerName")

# COMMAND ----------

# MAGIC %run ../Framework/Secrets_Databricks_Container

# COMMAND ----------

# MAGIC %run ../Framework/Neudesic_Framework_Functions

# COMMAND ----------

spark.conf.set("spark.databricks.delta.merge.joinBasedMerge.enabled", True)

# COMMAND ----------

dbutils.widgets.text(name="parentPipeLineExecutionLogKey", defaultValue="-1", label="Parent Pipeline Execution Log Key")
dbutils.widgets.text(name="numPartitions", defaultValue="32", label="Number of Partitions")
dbutils.widgets.text(name="schemaName", defaultValue="brtl", label="Schema Name")
dbutils.widgets.text(name="tableName", defaultValue="AssistedOrders", label="Table Name")
dbutils.widgets.text(name="vacuumRetentionHours", defaultValue="", label="Vacuum Retention Hours")
dbutils.widgets.text(name="primaryKeyColumns", defaultValue="", label="Primary Key Columns")
dbutils.widgets.text(name="timestampColumns", defaultValue="", label="Timestamp Columns")

parentPipeLineExecutionLogKey = dbutils.widgets.get("parentPipeLineExecutionLogKey")
fullPathPrefix = "abfss://" + containerName + "@" + adlsGen2StorageAccountName + ".dfs.core.windows.net" 

numPartitions = int(dbutils.widgets.get("numPartitions"))



schemaName = dbutils.widgets.get("schemaName")
tableName = dbutils.widgets.get("tableName")
fullyQualifiedTableName = schemaName + "." + tableName
primaryKeyColumns = dbutils.widgets.get("primaryKeyColumns")
timestampColumns = dbutils.widgets.get("timestampColumns")

enrichedPath = fullPathPrefix + "/Query/Enriched/" + tableName
databaseTableName = containerName + "." + tableName
vacuumRetentionHours = dbutils.widgets.get("vacuumRetentionHours")
destinationTableName = tableName

currentStatePath = fullPathPrefix + "/Query/CurrentState/" + tableName

# COMMAND ----------

notebookName = "Query Zone Processing - Append Export Test1"
notebookExecutionLogKey = log_event_notebook_start(notebookName,parentPipeLineExecutionLogKey)
print("Notebook Execution Log Key: {0}".format(notebookExecutionLogKey))

# COMMAND ----------

print("Schema Name: {0}".format(schemaName))
# print("Source Table Name: {0}".format(stageTableName))
print("Table Name: {0}".format(tableName))
print("Fully Qualified Table Name: {0}".format(fullyQualifiedTableName))
print("Number of Partitions: {0}".format(numPartitions))
print("Current State Path: {0}".format(currentStatePath))
# print("Current State Stage Path: {0}".format(currentStateStagePath))
print("Enriched State Path: {0}".format(enrichedPath))

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Starting
# MAGIC val notebookPath = dbutils.notebook.getContext.notebookPath.get
# MAGIC val logMessage = "Starting"
# MAGIC val notebookContext = dbutils.notebook.getContext().toJson
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read Existing Data from Query Zone (CurrentState}

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl" + tableName)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl." + tableName, fullPathPrefix + "/Query/CurrentState/" + tableName)
print(sql)
spark.sql(sql)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from brtl.INVENTDIM

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read STG Data from Query Zone (CurrentState}

# COMMAND ----------

sql = """
DROP VIEW IF EXISTS {0}
""".format( "brtl.Incremental_" + tableName)
spark.sql(sql)

# COMMAND ----------

stgViewName =  "brtl.Incremental_" + tableName

sql="""
CREATE OR REPLACE VIEW {0} AS
SELECT *

FROM {1}
""".format(stgViewName,"brtl." + tableName)
display(spark.sql(sql))

# COMMAND ----------

sql="""
SELECT *
  FROM {0}
""".format(stgViewName)
stg_df=(spark.sql(sql))

# COMMAND ----------

display(stg_df)

# COMMAND ----------

try:
  #read enrichedPath into a dataframe if it exists, otherwise create it
  dst_df = spark.read \
    .format("delta") \
    .load(enrichedPath) \
    .dropDuplicates()
except Exception as e:
   (stg_df \
    .write \
    .mode("overwrite") \
    .format("delta") \
    .save(enrichedPath)
    )

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE {0}
USING delta
LOCATION '{1}'
""".format(databaseTableName, enrichedPath)
spark.sql(sql)

# COMMAND ----------

spark.conf.set("spark.sql.crossJoin.enabled", "true")

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC --MERGE INTO brtl.FCTAssistedOrders
# MAGIC --USING brtl.Incremental_AssistedOrders
# MAGIC --ON brtl.FCTAssistedOrders.3rdPartyOrderNumber = brtl.Incremental_AssistedOrders.3rdPartyOrderNumber
# MAGIC --AND brtl.FCTAssistedOrders.StoreNumber = brtl.Incremental_AssistedOrders.StoreNumber
# MAGIC --AND brtl.FCTAssistedOrders.Date = brtl.Incremental_AssistedOrders.Date
# MAGIC ---AND brtl.FCTAssistedOrders.ItemNumber = brtl.Incremental_AssistedOrders.ItemNumber
# MAGIC ---AND brtl.FCTAssistedOrders.Barcode = brtl.Incremental_AssistedOrders.Barcode
# MAGIC --WHEN MATCHED THEN
# MAGIC --  DELETE

# COMMAND ----------

#stageTableName = "brtl." + tableName
pkColumns = primaryKeyColumns.split(",")
mergeCommand = "MERGE INTO " + fullyQualifiedTableName + " AS fct \n" + "USING " + stgViewName  + " AS stg \nON "
pksize = len(pkColumns)
for i in range(pksize):
  if i == pksize-1:
    mergeCommand = mergeCommand + " \nfct." + pkColumns[i] + " = stg." + pkColumns[i] 
  else:
    mergeCommand = mergeCommand + " \nfct." + pkColumns[i] + " = stg." + pkColumns[i] + " AND "

 

print(mergeCommand)
sqlquery = mergeCommand + " WHEN MATCHED THEN DELETE"
spark.sql(sqlquery)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Append Data in Query Zone (Enriched)

# COMMAND ----------

try:
  queryTableExists = (spark.table(databaseTableName) is not None)
except:
  queryTableExists = False

# COMMAND ----------

queryTableExists

# COMMAND ----------

try:
  if queryTableExists:
    (stg_df.repartition(numPartitions) \
      .write \
      .mode("append") \
      .option("mergeSchema", True) \
      .format("delta") \
      .save(enrichedPath)
    )
  else:
    (stg_df.repartition(numPartitions) \
      .write \
      .mode("overwrite") \
      .format("delta") \
      .save(enrichedPath)
    )
    sql = """
    CREATE TABLE {0}
    USING delta
    LOCATION '{1}'
    """.format(destinationTableName, enrichedPath)
    spark.sql(sql)
except Exception as e:
  sourceName = "Query Zone Processing - Append Databricks Delta: Write to Query Zone"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE {0}
USING delta
LOCATION '{1}'
""".format(databaseTableName, enrichedPath)
spark.sql(sql)

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from brtl.INVENTDIM

# COMMAND ----------

# MAGIC %md
# MAGIC #### Append Data in to Synapse DW from Current State

# COMMAND ----------

sanctionedZoneNotebookPath = "../Framework/Sanctioned Zone Processing - Load Synapse DW Overwrite"
stageSchemaName = "stage"
stageTableName = "Incremental_AssistedOrders"

run_with_retry(sanctionedZoneNotebookPath, 1200, {"parentPipeLineExecutionLogKey": notebookExecutionLogKey, "containerName": containerName, "schemaName": stageSchemaName, "tableName": stageTableName, "numPartitions": numPartitions})

# COMMAND ----------

execsp = "DELETE brtl.FCTAssistedOrders WHERE [3rdPartyOrderNumber] in (SELECT [3rdPartyOrderNumber] from stage.Incremental_AssistedOrders) \
                                     AND StoreNumber in (SELECT StoreNumber from stage.Incremental_AssistedOrders) \
                                     AND ItemNumber in (SELECT ItemNumber from stage.Incremental_AssistedOrders) \
                                     AND Barcode in (SELECT Barcode from stage.Incremental_AssistedOrders) \
                                     AND Date in (SELECT Date from stage.Incremental_AssistedOrders)"
try:
  execute_sqldw_stored_procedure_no_results(execsp)
except:
  sourceName = "Destination Table does not exist"

# COMMAND ----------

blob_storage_account_name = adlsGen2StorageAccountName
blob_storage_container_name = "temp"

tempDir = "abfss://{}@{}.dfs.core.windows.net/".format(blob_storage_container_name, blob_storage_account_name) + dbutils.widgets.get("tableName")

# COMMAND ----------

sqlDwUrlSmall, connectionProperties = build_sqldw_jdbc_url_and_connectionProperties(sqldwservername, sqldwdatabasename, sqldwusername, sqldwpassword)

# COMMAND ----------

try:
  stg_df \
    .write \
    .format("com.databricks.spark.sqldw") \
    .mode("append") \
    .option("url", sqlDwUrlSmall) \
    .option("dbtable", fullyQualifiedTableName) \
    .option("useAzureMSI","True") \
    .option("maxStrLength",2048) \
    .option("tempdir", tempDir) \
    .save()
except Exception as e:
  sourceName = "Sanctioned Zone Processing - Load Azure SQL DW: Load Synapse SQL Data Warehouse"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Drop Temporary Table and Views

# COMMAND ----------

dbutils.fs.rm(tempDir,True)

# COMMAND ----------

sql = """
DROP VIEW IF EXISTS {0}
""".format("brtl.Incremental_" + tableName)
spark.sql(sql)

# COMMAND ----------

sql = """
DROP VIEW IF EXISTS {0}
""".format(stgViewName)
spark.sql(sql)

# COMMAND ----------

execsp = "IF OBJECT_ID('stage.Incremental_AssistedOrders') IS NOT NULL DROP TABLE stage.Incremental_AssistedOrders"
execute_sqldw_stored_procedure_no_results(execsp)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Optimize and Vacuum Table

# COMMAND ----------

sql="""OPTIMIZE {0}""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

if vacuumRetentionHours != '':
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", False)
  spark.sql("VACUUM " + databaseTableName + " RETAIN " + vacuumRetentionHours + " HOURS")
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", True)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Log Completion

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Completed
# MAGIC val logMessage = "Completed"
# MAGIC val notebookContext = ""
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

log_event_notebook_end(notebookExecutionLogKey=notebookExecutionLogKey, notebookStatus="SUCCEEDED", notebookName=notebookName, notebookExecutionGroupName="")
dbutils.notebook.exit("Succeeded")