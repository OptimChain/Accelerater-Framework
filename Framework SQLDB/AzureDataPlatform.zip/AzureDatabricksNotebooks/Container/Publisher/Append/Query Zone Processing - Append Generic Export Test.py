# MAGIC  
# MAGIC  
# MAGIC  
# MAGIC %md
# MAGIC # Query Zone Processing - Append FCTInventoryTrans
# MAGIC ###### Author: Chaitanya Badam 06/01/2020
# MAGIC 
# MAGIC Data Lake pattern for tables that are staged and merged into the final enriched version.  Takes a file from the raw data path and overwrites the table in the Query zone.      
# MAGIC 
# MAGIC #### Usage
# MAGIC Supply the parameters above and run the notebook.  
# MAGIC 
# MAGIC #### Prerequisites
# MAGIC 1. Data must exist in the Data Lake /query zone (current State).   
# MAGIC 
# MAGIC #### Details

# COMMAND ----------

# MAGIC %md
# MAGIC #### Initialize Framework

# COMMAND ----------

dbutils.widgets.text(name="containerName", defaultValue="brtl", label="Container Name")
containerName = dbutils.widgets.get("containerName")

# COMMAND ----------

# MAGIC %run ../Framework/Secrets_Databricks_Container

# COMMAND ----------

# MAGIC %run ../Framework/Neudesic_Framework_Functions

# COMMAND ----------

spark.conf.set("spark.databricks.delta.merge.joinBasedMerge.enabled", True)

# COMMAND ----------

dbutils.widgets.text(name="parentPipeLineExecutionLogKey", defaultValue="-1", label="Parent Pipeline Execution Log Key")
dbutils.widgets.text(name="numPartitions", defaultValue="32", label="Number of Partitions")
dbutils.widgets.text(name="schemaName", defaultValue="brtl", label="Schema Name")
dbutils.widgets.text(name="tableName", defaultValue="INVENTTRANS", label="Table Name")
dbutils.widgets.text(name="vacuumRetentionHours", defaultValue="", label="Vacuum Retention Hours")
dbutils.widgets.text(name="primaryKeyColumns", defaultValue="", label="Primary Key Columns")
dbutils.widgets.text(name="timestampColumns", defaultValue="", label="Timestamp Columns")

parentPipeLineExecutionLogKey = dbutils.widgets.get("parentPipeLineExecutionLogKey")
fullPathPrefix = "abfss://" + containerName + "@" + adlsGen2StorageAccountName + ".dfs.core.windows.net" 

numPartitions = int(dbutils.widgets.get("numPartitions"))

#destinationTableName = 'FCTInventoryTrans'
tableName='INVENTDIM'

schemaName = dbutils.widgets.get("schemaName")

fullyQualifiedTableName = schemaName + "." + destinationTableName
primaryKeyColumns = dbutils.widgets.get("primaryKeyColumns")
timestampColumns = dbutils.widgets.get("timestampColumns")

enrichedPath = fullPathPrefix + "/Query/Enriched/" + destinationTableName
databaseTableName = containerName + "." + destinationTableName
vacuumRetentionHours = dbutils.widgets.get("vacuumRetentionHours")

currentStatePath = fullPathPrefix + "/Query/CurrentState/" + tableName



# COMMAND ----------

notebookName = "Query Zone Processing - Append FCTInventoryTrans"
notebookExecutionLogKey = log_event_notebook_start(notebookName,parentPipeLineExecutionLogKey)
print("Notebook Execution Log Key: {0}".format(notebookExecutionLogKey))

# COMMAND ----------

print("Schema Name: {0}".format(schemaName))
# print("Source Table Name: {0}".format(stageTableName))
print("Table Name: {0}".format(tableName))
print("Fully Qualified Table Name: {0}".format(fullyQualifiedTableName))
print("Number of Partitions: {0}".format(numPartitions))
print("Current State Path: {0}".format(currentStatePath))
# print("Current State Stage Path: {0}".format(currentStateStagePath))
print("Enriched State Path: {0}".format(enrichedPath))

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Starting
# MAGIC val notebookPath = dbutils.notebook.getContext.notebookPath.get
# MAGIC val logMessage = "Starting"
# MAGIC val notebookContext = dbutils.notebook.getContext().toJson
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read Existing Data from Query Zone (CurrentState}

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}.{1}
""".format(schemaName,tableName)
spark.sql(sql)

#sql = """
#DROP TABLE IF EXISTS {0}.{1}
#""".format(schemaName,"FCTInventoryTrans_DeletedRecords")
#spark.sql(sql)



# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}.{1}
USING delta
LOCATION '{2}'
""".format(schemaName,tableName, currentStatePath)
spark.sql(sql)

#sql = """
#CREATE TABLE IF NOT EXISTS {0}.{1}
#USING delta
#LOCATION '{2}'
#""".format(schemaName,"FCTInventoryTrans_DeletedRecords", fullPathPrefix + "/Query/Enriched/" + "FCTInventoryTrans_DeletedRecords")
#spark.sql(sql)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read STG Data from Query Zone (CurrentState}

# COMMAND ----------

stgViewName =  "brtl.Incremental"

sql="""
DROP  VIEW  IF EXISTS {0}
""".format(stgViewName)
display(spark.sql(sql))

# COMMAND ----------

sql="""
CREATE OR REPLACE VIEW {0} AS
SELECT *
,'Query Zone Processing - Append' AS Created_By
,'' AS Modified_By
,cast(current_date() AS string) AS Last_Created
--,'1900-01-01 00:00:00.0000000' AS Last_Modified
FROM {1}.{2}
""".format(stgViewName,schemaName,tableName)
display(spark.sql(sql))

# COMMAND ----------

sql="""
SELECT *
  FROM {0}
""".format(stgViewName)
stg_df=(spark.sql(sql))

# COMMAND ----------

try:
  #read enrichedPath into a dataframe if it exists, otherwise create it
  dst_df = spark.read \
    .format("delta") \
    .load(enrichedPath) \
    .dropDuplicates()
except Exception as e:
   (stg_df \
    .write \
    .mode("overwrite") \
    .format("delta") \
    .save(enrichedPath)
    )

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE {0}
USING delta
LOCATION '{1}'
""".format(databaseTableName, enrichedPath)
spark.sql(sql)

# COMMAND ----------

spark.conf.set("spark.sql.crossJoin.enabled", "true")

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC --MERGE INTO brtl.FCTInventoryTrans
# MAGIC --USING brtl.Incremental_InventoryTrans
# MAGIC --ON brtl.FCTInventoryTrans.RECID = brtl.Incremental_InventoryTrans.RECID
# MAGIC --AND brtl.FCTInventoryTrans.RECVERSION = brtl.Incremental_InventoryTrans.RECVERSION
# MAGIC --WHEN MATCHED THEN
# MAGIC  -- DELETE

# COMMAND ----------

stageTableName = "brtl.AssistedOrders" + ta
pkColumns = primaryKeyColumns.split(",")
mergeCommand = "MERGE INTO " + fullyQualifiedTableName + " AS fct \n" + "USING " + stageTableName  + " AS stg \nON "
pksize = len(pkColumns)
for i in range(pksize):
  if i == pksize-1:
    mergeCommand = mergeCommand + " \nfct." + pkColumns[i] + " = stg." + pkColumns[i] 
  else:
    mergeCommand = mergeCommand + " \nfct." + pkColumns[i] + " = stg." + pkColumns[i] + " AND "

 

print(mergeCommand)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Append Data in Query Zone (Enriched)

# COMMAND ----------

try:
  queryTableExists = (spark.table(databaseTableName) is not None)
except:
  queryTableExists = False

# COMMAND ----------

queryTableExists

# COMMAND ----------

try:
  if queryTableExists:
    (stg_df.repartition(numPartitions) \
      .write \
      .mode("append") \
      .option("mergeSchema", True) \
      .format("delta") \
      .save(enrichedPath)
    )
  else:
    (stg_df.repartition(numPartitions) \
      .write \
      .mode("overwrite") \
      .format("delta") \
      .save(enrichedPath)
    )
    sql = """
    CREATE TABLE {0}
    USING delta
    LOCATION '{1}'
    """.format(destinationTableName, enrichedPath)
    spark.sql(sql)
except Exception as e:
  sourceName = "Query Zone Processing - Append Databricks Delta: Write to Query Zone"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Append Data in to Synapse DW from Current State

# COMMAND ----------

sanctionedZoneNotebookPath = "../Framework/Sanctioned Zone Processing - Load Synapse DW Overwrite"
stageSchemaName = "stage"
stageTableName = "Incremental_InventoryTrans"

run_with_retry(sanctionedZoneNotebookPath, 0, {"parentPipeLineExecutionLogKey": notebookExecutionLogKey, "containerName": containerName, "schemaName": stageSchemaName, "tableName": stageTableName, "numPartitions": numPartitions})

# COMMAND ----------

execsp = "DELETE brtl.FCTInventoryTrans WHERE [RECID] in (SELECT [RECID] from stage.Incremental_InventoryTrans) \
                                          AND [RECVERSION] in (SELECT [RECVERSION] from stage.Incremental_InventoryTrans)"
try:
  execute_sqldw_stored_procedure_no_results(execsp)
except:
  sourceName = "Destination Table does not exist"

# COMMAND ----------

blob_storage_account_name = adlsGen2StorageAccountName
blob_storage_container_name = "temp"

tempDir = "abfss://{}@{}.dfs.core.windows.net/".format(blob_storage_container_name, blob_storage_account_name) + dbutils.widgets.get("tableName")

# COMMAND ----------

sqlDwUrlSmall, connectionProperties = build_sqldw_jdbc_url_and_connectionProperties(sqldwservername, sqldwdatabasename, sqldwusername, sqldwpassword)

# COMMAND ----------

try:
  stg_df \
    .write \
    .format("com.databricks.spark.sqldw") \
    .mode("append") \
    .option("url", sqlDwUrlSmall) \
    .option("dbtable", fullyQualifiedTableName) \
    .option("useAzureMSI","True") \
    .option("maxStrLength",2048) \
    .option("tempdir", tempDir) \
    .save()
except Exception as e:
  sourceName = "Sanctioned Zone Processing - Load Azure SQL DW: Load Synapse SQL Data Warehouse"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Drop Temporary Table and Views

# COMMAND ----------

dbutils.fs.rm(tempDir,True)

# COMMAND ----------

sql = """
DROP VIEW IF EXISTS {0}
""".format("brtl.Incremental_InventoryTrans")
spark.sql(sql)

# COMMAND ----------

sql = """
DROP VIEW IF EXISTS {0}
""".format(stgViewName)
spark.sql(sql)

# COMMAND ----------

execsp = "IF OBJECT_ID('stage.Incremental_InventoryTrans') IS NOT NULL DROP TABLE stage.Incremental_InventoryTrans"
execute_sqldw_stored_procedure_no_results(execsp)

# COMMAND ----------

#sql="""
#DROP TABLE IF EXISTS {0}.{1}
#""".format(schemaName,"Current")
#display(spark.sql(sql))

#sql="""
#CREATE TABLE IF NOT EXISTS {0}.{1} AS
#SELECT *  FROM {2}
#""".format(schemaName,"Current",databaseTableName)
#display(spark.sql(sql))

# COMMAND ----------

sql="""
SELECT ACTIVITYNUMBER
,AXAOLDTRANSCHILDREFID
,COSTAMOUNTADJUSTMENT
,COSTAMOUNTOPERATIONS
,COSTAMOUNTPHYSICAL
,COSTAMOUNTPOSTED
,COSTAMOUNTSECCURADJUSTMENT_RU
,COSTAMOUNTSECCURPHYSICAL_RU
,COSTAMOUNTSECCURPOSTED_RU
,COSTAMOUNTSETTLED
,COSTAMOUNTSETTLEDSECCUR_RU
,COSTAMOUNTSTD
,COSTAMOUNTSTDSECCUR_RU
,CURRENCYCODE
,DATAAREAID
,DATECLOSED
,DATECLOSEDSECCUR_RU
,DATEEXPECTED
,DATEFINANCIAL
,DATEINVENT
,DATEPHYSICAL
,DATESTATUS
,GROUPREFID_RU
,GROUPREFTYPE_RU
,INTERCOMPANYINVENTDIMTRANSFERRED
,INVENTDIMFIXED
,INVENTDIMID
,INVENTDIMIDSALES_RU
,INVENTTRANSORIGIN
,INVENTTRANSORIGINDELIVERY_RU
,INVENTTRANSORIGINSALES_RU
,INVENTTRANSORIGINTRANSIT_RU
,INVOICEID
,INVOICERETURNED
,ITEMID
,MARKINGREFINVENTTRANSORIGIN
,MODIFIEDDATETIME
,NONFINANCIALTRANSFERINVENTCLOSING
,PACKINGSLIPID
,PACKINGSLIPRETURNED
,PARTITION
,PDSCWQTY
,PDSCWSETTLED
,PICKINGROUTEID
,PROJADJUSTREFID
,PROJCATEGORYID
,PROJID
,QTY
,QTYSETTLED
,QTYSETTLEDSECCUR_RU
,RECID
,RECVERSION
,RETURNINVENTTRANSORIGIN
,REVENUEAMOUNTPHYSICAL
,SHIPPINGDATECONFIRMED
,SHIPPINGDATEREQUESTED
,STATUSISSUE
,STATUSRECEIPT
,STORNOPHYSICAL_RU
,STORNO_RU
,TAXAMOUNTPHYSICAL
,TIMEEXPECTED
,TRANSCHILDREFID
,TRANSCHILDTYPE
,VALUEOPEN
,VALUEOPENSECCUR_RU
,VOUCHER
,VOUCHERPHYSICAL

FROM {0}
""".format(databaseTableName)
df_curr = spark.sql(sql)

# COMMAND ----------

sql="""
SELECT max(version)-1  FROM (DESCRIBE HISTORY {0})
""".format(databaseTableName)
version = spark.sql(sql).collect()
previous = version[0][0]


sql="""
CREATE TABLE IF NOT EXISTS {0}.{1} AS
SELECT ACTIVITYNUMBER
,AXAOLDTRANSCHILDREFID
,COSTAMOUNTADJUSTMENT
,COSTAMOUNTOPERATIONS
,COSTAMOUNTPHYSICAL
,COSTAMOUNTPOSTED
,COSTAMOUNTSECCURADJUSTMENT_RU
,COSTAMOUNTSECCURPHYSICAL_RU
,COSTAMOUNTSECCURPOSTED_RU
,COSTAMOUNTSETTLED
,COSTAMOUNTSETTLEDSECCUR_RU
,COSTAMOUNTSTD
,COSTAMOUNTSTDSECCUR_RU
,CURRENCYCODE
,DATAAREAID
,DATECLOSED
,DATECLOSEDSECCUR_RU
,DATEEXPECTED
,DATEFINANCIAL
,DATEINVENT
,DATEPHYSICAL
,DATESTATUS
,GROUPREFID_RU
,GROUPREFTYPE_RU
,INTERCOMPANYINVENTDIMTRANSFERRED
,INVENTDIMFIXED
,INVENTDIMID
,INVENTDIMIDSALES_RU
,INVENTTRANSORIGIN
,INVENTTRANSORIGINDELIVERY_RU
,INVENTTRANSORIGINSALES_RU
,INVENTTRANSORIGINTRANSIT_RU
,INVOICEID
,INVOICERETURNED
,ITEMID
,MARKINGREFINVENTTRANSORIGIN
,MODIFIEDDATETIME
,NONFINANCIALTRANSFERINVENTCLOSING
,PACKINGSLIPID
,PACKINGSLIPRETURNED
,PARTITION
,PDSCWQTY
,PDSCWSETTLED
,PICKINGROUTEID
,PROJADJUSTREFID
,PROJCATEGORYID
,PROJID
,QTY
,QTYSETTLED
,QTYSETTLEDSECCUR_RU
,RECID
,RECVERSION
,RETURNINVENTTRANSORIGIN
,REVENUEAMOUNTPHYSICAL
,SHIPPINGDATECONFIRMED
,SHIPPINGDATEREQUESTED
,STATUSISSUE
,STATUSRECEIPT
,STORNOPHYSICAL_RU
,STORNO_RU
,TAXAMOUNTPHYSICAL
,TIMEEXPECTED
,TRANSCHILDREFID
,TRANSCHILDTYPE
,VALUEOPEN
,VALUEOPENSECCUR_RU
,VOUCHER
,VOUCHERPHYSICAL
FROM {2} Version AS OF {3}
""".format(schemaName,"Previous",databaseTableName,previous)
display(spark.sql(sql))

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from brtl.FCTInventoryTrans

# COMMAND ----------

sql="""
DROP  TABLE IF EXISTS {0}.{1}
""".format(schemaName,"Incremental_FCTInventoryTrans_DeletedRecords")
display(spark.sql(sql))

sql="""
CREATE TABLE IF NOT EXISTS {0}.{1}
SELECT p.*
FROM {0}.{3} as p
LEFT OUTER JOIN  {2} as c ON c.RECID = p.RECID
WHERE c.RECID  IS NULL
""".format(schemaName,"Incremental_FCTInventoryTrans_DeletedRecords",databaseTableName,"Previous")
display(spark.sql(sql))

# COMMAND ----------

sql="""
SELECT count(*)
FROM {0}.{1} as p
""".format(schemaName,"Incremental_FCTInventoryTrans_DeletedRecords")
display(spark.sql(sql))

# COMMAND ----------

sql="""
SELECT *
FROM {0}.{1} as p
LIMIT 100
""".format(schemaName,"Incremental_FCTInventoryTrans_DeletedRecords")
del_df=spark.sql(sql)

# COMMAND ----------

try:
  queryTableExists = (spark.table("FCTInventoryTrans_DeletedRecords") is not None)
except:
  queryTableExists = False

# COMMAND ----------

queryTableExists

# COMMAND ----------

try:
  if queryTableExists:
    (del_df.repartition(numPartitions) \
      .write \
      .mode("append") \
      .option("mergeSchema", True) \
      .format("delta") \
      .save(fullPathPrefix +"/Query/Enriched/" + "FCTInventoryTrans_DeletedRecords")
    )
  else:
    (del_df.repartition(numPartitions) \
      .write \
      .mode("overwrite") \
      .format("delta") \
      .save(fullPathPrefix +"/Query/Enriched/" + "FCTInventoryTrans_DeletedRecords")
    )
    sql = """
    CREATE TABLE {0}
    USING delta
    LOCATION '{1}'
    """.format("FCTInventoryTrans_DeletedRecords", fullPathPrefix + "/Query/Enriched/" + "FCTInventoryTrans_DeletedRecords")
    spark.sql(sql)
except Exception as e:
  sourceName = "Query Zone Processing - Append Databricks Delta: Write to Query Zone"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Append Deleted Trans Data in to Synapse DW from Current State

# COMMAND ----------

sanctionedZoneNotebookPath = "../Framework/Sanctioned Zone Processing - Load Synapse DW Overwrite"
stageSchemaName = "stage"
stageTableName = "Incremental_FCTInventoryTrans_DeletedRecords"

run_with_retry(sanctionedZoneNotebookPath, 0, {"parentPipeLineExecutionLogKey": notebookExecutionLogKey, "containerName": containerName, "schemaName": stageSchemaName, "tableName": stageTableName, "numPartitions": numPartitions})

# COMMAND ----------

execsp = "DELETE brtl.FCTInventoryTrans_DeletedRecords WHERE [RECID] in (SELECT [RECID] from stage.FCTInventoryTrans_DeletedRecords)"
try:
  execute_sqldw_stored_procedure_no_results(execsp)
except:
  sourceName = "Destination Table does not exist"

# COMMAND ----------

blob_storage_account_name = adlsGen2StorageAccountName
blob_storage_container_name = "temp"

tempDir = "abfss://{}@{}.dfs.core.windows.net/".format(blob_storage_container_name, blob_storage_account_name) + dbutils.widgets.get("tableName")

# COMMAND ----------

try:
  del_df \
    .write \
    .format("com.databricks.spark.sqldw") \
    .mode("append") \
    .option("url", sqlDwUrlSmall) \
    .option("dbtable", "brtl.FCTInventoryTrans_DeletedRecords") \
    .option("useAzureMSI","True") \
    .option("maxStrLength",2048) \
    .option("tempdir", tempDir) \
    .save()
except Exception as e:
  sourceName = "Sanctioned Zone Processing - Load Azure SQL DW: Load Synapse SQL Data Warehouse"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

execsp = "IF OBJECT_ID('stage.Incremental_FCTInventoryTrans_DeletedRecords') IS NOT NULL DROP TABLE stage.Incremental_FCTInventoryTrans_DeletedRecords"
execute_sqldw_stored_procedure_no_results(execsp)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Optimize and Vacuum Table

# COMMAND ----------

#sql="""OPTIMIZE {0}""".format(databaseTableName)
#spark.sql(sql)

# COMMAND ----------

if vacuumRetentionHours != '':
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", False)
  spark.sql("VACUUM " + databaseTableName + " RETAIN " + vacuumRetentionHours + " HOURS")
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", True)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Log Completion

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Completed
# MAGIC val logMessage = "Completed"
# MAGIC val notebookContext = ""
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

log_event_notebook_end(notebookExecutionLogKey=notebookExecutionLogKey, notebookStatus="SUCCEEDED", notebookName=notebookName, notebookExecutionGroupName="")
dbutils.notebook.exit("Succeeded")