# MAGIC 
# MAGIC %md
# MAGIC # Query Zone Processing - Append Fill_Fact
# MAGIC ###### Author: Mike Sherrill 01/14/2021
# MAGIC 
# MAGIC Data Lake pattern for tables that are staged and merged into the final enriched version.  Takes a file from the raw data path and overwrites the table in the Query zone.      
# MAGIC 
# MAGIC #### Usage
# MAGIC Supply the parameters above and run the notebook.  
# MAGIC 
# MAGIC #### Prerequisites
# MAGIC 1. Data must exist in the Data Lake /query zone (current State).   
# MAGIC 
# MAGIC #### Details

# COMMAND ----------

# MAGIC %md
# MAGIC #### Initialize Framework

# COMMAND ----------

dbutils.widgets.text(name="containerName", defaultValue="brtl", label="Container Name")
containerName = dbutils.widgets.get("containerName")

# COMMAND ----------

# MAGIC %run ../Framework/Secrets_Databricks_Container

# COMMAND ----------

# MAGIC %run ../Framework/Neudesic_Framework_Functions

# COMMAND ----------

spark.conf.set("spark.databricks.delta.merge.joinBasedMerge.enabled", True)

# COMMAND ----------

dbutils.widgets.text(name="parentPipeLineExecutionLogKey", defaultValue="-1", label="Parent Pipeline Execution Log Key")
dbutils.widgets.text(name="numPartitions", defaultValue="8", label="Number of Partitions")
dbutils.widgets.text(name="schemaName", defaultValue="brtl", label="Schema Name")
dbutils.widgets.text(name="tableName", defaultValue="Fill_Fact", label="Table Name")
dbutils.widgets.text(name="vacuumRetentionHours", defaultValue="", label="Vacuum Retention Hours")
dbutils.widgets.text(name="primaryKeyColumns", defaultValue="", label="Primary Key Columns")
dbutils.widgets.text(name="timestampColumns", defaultValue="", label="Timestamp Columns")

parentPipeLineExecutionLogKey = dbutils.widgets.get("parentPipeLineExecutionLogKey")
fullPathPrefix = "abfss://" + containerName + "@" + adlsGen2StorageAccountName + ".dfs.core.windows.net" 

numPartitions = int(dbutils.widgets.get("numPartitions"))


schemaName = dbutils.widgets.get("schemaName")
tableName = dbutils.widgets.get("tableName")
destinationTableName = tableName

fullyQualifiedTableName = schemaName + "." + destinationTableName
primaryKeyColumns = dbutils.widgets.get("primaryKeyColumns")
timestampColumns = dbutils.widgets.get("timestampColumns")

enrichedPath = fullPathPrefix + "/Query/Enriched/" + destinationTableName
databaseTableName = containerName + "." + destinationTableName
vacuumRetentionHours = dbutils.widgets.get("vacuumRetentionHours")

currentStatePath = fullPathPrefix + "/Query/CurrentState/" + tableName

# COMMAND ----------

notebookName = "Query Zone Processing - Append Fill_Fact"
notebookExecutionLogKey = log_event_notebook_start(notebookName,parentPipeLineExecutionLogKey)
print("Notebook Execution Log Key: {0}".format(notebookExecutionLogKey))

# COMMAND ----------

print("Schema Name: {0}".format(schemaName))
# print("Source Table Name: {0}".format(stageTableName))
print("Table Name: {0}".format(tableName))
print("Fully Qualified Table Name: {0}".format(fullyQualifiedTableName))
print("Number of Partitions: {0}".format(numPartitions))
print("Current State Path: {0}".format(currentStatePath))
# print("Current State Stage Path: {0}".format(currentStateStagePath))
print("Enriched State Path: {0}".format(enrichedPath))

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Starting
# MAGIC val notebookPath = dbutils.notebook.getContext.notebookPath.get
# MAGIC val logMessage = "Starting"
# MAGIC val notebookContext = dbutils.notebook.getContext().toJson
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read STG Data from Query Zone (CurrentState}

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.Fill_Fact_Incremental")
spark.sql(sql)


# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl.Fill_Fact_Incremental", fullPathPrefix + "/Query/CurrentState/" + "Fill_Fact")
spark.sql(sql)


# COMMAND ----------

sql="""
SELECT ACUTE_PROMISE_REASON_CODE
      ,ADJUDICATION_DATE_KEY
      ,ADJUDICATION_GROUP_NUM
      ,ADJ_DATE_OF_SERVICE_KEY
      ,BILLED_AMOUNT
      ,BIN_NAME
      ,CANCEL_DATE_KEY
      ,CANCEL_TIME_KEY
      ,CENTRAL_FILL_FD_FACILITY_KEY
      ,CF_LOCAL_PRD_PRODUCT_KEY
      ,COST_PRICING_FORMULA_NAME
      ,COUNSELING_ACCEPTED
      ,COUNSELING_COMMENTS
      ,COUNSELING_SIGN_IMAGE_KEY
      ,CRF_SEQ_NUM
      ,DATA_ENTRY_USER_KEY
      ,DATE_CONSENTED_TO_FILL
      ,DAYS_SUPPLY
      ,DC_DAW_CODE_KEY
      ,DISPENSED_DATE_KEY
      ,DISPENSED_DRUG_KEY
      ,DISPENSED_PRD_PRODUCT_KEY
      ,DISPENSED_QTY_AWP
      ,DISPENSED_TIME_KEY
      ,DISPENSING_FEE_AMOUNT
      ,DISPENSING_USER_KEY
      ,DM_DELIVERY_METHOD_KEY
      ,ERP_ENROLLMENT_CODE_NUM
      ,ERP_ENROLLMENT_REASON_CODE_NUM
      ,ERP_ENROLLMENT_STATUS_DATE
      ,ERP_EXCLUSION_REASON_CODE_NUM
      ,ERP_TARGET_DATE
      ,EXPIRY_DATE_KEY
      ,FACILITY_ORDER_NUMBER
      ,FD_FACILITY_KEY
      ,FILL_DURATION_SECS
      ,FILL_FACT_KEY
      ,FILL_INDICATOR_KEY
      ,FIRST_FILL_DATE_KEY
      ,FIRST_FILL_QTY
      ,FIRST_FILL_TIME_KEY
      ,FOA_DATE
      ,FS_FILL_STATUS_KEY
      ,FULL_PACKAGE_UNC
      ,FUTURE_FILL_DATE_KEY
      ,GS_GENERIC_SUB_KEY
      ,H_LEVEL
      ,INCENTIVE_FEE_AMOUNT
      ,INGREDIENT_COST
      ,INTENDED_DAYS_SUPPLY
      ,INTENDED_QTY_DISPENSED
      ,IS_340B
      ,IS_AUTO_DISPENSED
      ,IS_BAR
      ,IS_BAR_SOURCE
      ,IS_COB
      ,IS_CONSENTED_TO_FILL
      ,IS_EDIT_TP
      ,IS_EDIT_TP_SOURCE
      ,IS_ERP_OPPORTUNITY
      ,IS_MAIL
      ,IS_PARTIAL_AUTOBILLED
      ,IS_PARTIAL_AUTOBILLED_SOURCE
      ,IS_PARTIAL_FILL_BILLED
      ,IS_PRN
      ,IS_RETURNED_TO_STOCK
      ,IS_SAME_DAY_REVERSAL
      ,IS_SERVICE
      ,IS_SPLIT_ORDER
      ,LAST_FILL_DATE_KEY
      ,LAST_FILL_TIME_KEY
      ,LATIN_FREQUENCY_QTY
      ,LF_LATIN_FREQUENCY_KEY
      ,LOCAL_TRANSACTION_DATE
      ,LTC_BILLING_TYPE
      ,LTC_DELIVERY_DATE_KEY
      ,LTC_FACILITY_KEY
      ,LTC_FACILITY_NODE_KEY
      ,LTC_HOA_KEY
      ,LTC_MAINTENANCE_DRUG
      ,LTC_PACKAGING_METHOD_KEY
      ,LTC_RX_CYCLE_FILL_IND
      ,LTC_RX_DUE_DATE_KEY
      ,LTC_RX_START_DATE_KEY
      ,LTC_RX_STOP_DATE_KEY
      ,MCKESSON_GENERIC_AVAIL
      ,MCKESSON_GENERIC_OPPORTUNITY
      ,MCKESSON_GENERIC_STATUS
      ,METRIC_QTY_DISPENSED
      ,NEXT_FILL_QTY
      ,NON_DISCOUNTED_UNC
      ,ORDER_DATE_KEY
      ,ORDER_NUM
      ,ORDER_QUOTE_PRICE
      ,ORDER_TIME_KEY
      ,OS_ITEM_SOURCE_KEY
      ,OS_ORDER_SOURCE_KEY
      ,OVERRIDE_AMOUNT
      ,OVERRIDE_CODE_KEY
      ,PADR_KEY
      ,PARTIAL_FILL_SEQ
      ,PARTITION_DATE
      ,PATIENT_ERP_ENROLLMENT_STATUS
      ,PATIENT_PRICE_PAID
      ,PATIENT_TAX_AMT
      ,PRDC_CHAR_KEY
      ,PRD_PRODUCT_KEY
      ,PRESCRIBED_DATE_KEY
      ,PRIORITY
      ,PROMISE_DATE_KEY
      ,PROMISE_TIME_KEY
      ,PRSH_PRESCRIBER_KEY
      ,PRS_PRESCRIBER_KEY
      ,QTY_DISPENSED
      ,READY_DATE_KEY
      ,READY_TIME_KEY
      ,REFILL_NUM
      ,REFILL_QTY
      ,REQUIRE_CONSENT_TO_FILL
      ,RET_TO_STCK_DT_KEY
      ,CAST(RET_TO_STCK_QTY as Double) as RET_TO_STCK_QTY
      ,RTP_DATE_KEY
      ,RTP_TIME_KEY
      ,RX_EXPIRY_DATE_KEY
      ,RX_EXPIRY_TIME_KEY
      ,RX_FILL_SEQ
      ,RX_ORIGIN_CODE
      ,RX_RECORD_NUM
      ,SHIPMENT_NUM
      ,SIG
      ,CAST(SKIP_PRE_VER_CODE as Double) as SKIP_PRE_VER_CODE
      ,SOLD_DATE_KEY
      ,SOLD_TIME_KEY
      ,SPLIT_ORDER_DATE
      ,SPLIT_ORDER_USER_KEY
      ,SYNC_DATE_KEY
      ,TOTAL_PRICE_PAID
      ,TOTAL_REFILLS_ALLOWED
      ,TOTAL_REFILLS_REMAINING
      ,TOTAL_TAX
      ,TOTAL_UNC
      ,TPD_KEY
      ,TP_PRICE_PAID
      ,TP_TAX_AMT
      ,TRANSACTION_CODE
      ,TRANSACTION_DATE
      ,TRIPLICATE_SERIAL_NUM
      ,TSC_THERAPUETIC_SUB_CODE_KEY
      ,UNSOLD_DATE_KEY
      ,USER_DEFINED_STEP_AMT
      ,WRITTEN_DATE_KEY
      ,WRITTEN_DRUG_KEY
      ,WRITTEN_QTY
      ,WRITTEN_TIME_KEY
      ,dateLoaded
  FROM {0}
""".format("brtl.Fill_Fact_Incremental")
stg_df=(spark.sql(sql))

# COMMAND ----------

display(stg_df)

# COMMAND ----------

try:
  #read enrichedPath into a dataframe if it exists, otherwise create it
  dst_df = spark.read \
    .format("delta") \
    .load(enrichedPath) \
    .dropDuplicates()
except Exception as e:
   (stg_df \
    .write \
    .mode("overwrite") \
    .format("delta") \
    .save(enrichedPath)
    )

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format(databaseTableName, enrichedPath)
spark.sql(sql)

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from brtl.Fill_Fact_Incremental

# COMMAND ----------

spark.conf.set("spark.sql.crossJoin.enabled", "true")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Append Data in Query Zone (Enriched)

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC MERGE INTO brtl.Fill_Fact AS dst
# MAGIC USING brtl.Fill_Fact_Incremental AS stg
# MAGIC ON dst.Fill_Fact_Key = stg.Fill_Fact_Key
# MAGIC 
# MAGIC WHEN MATCHED THEN
# MAGIC   DELETE

# COMMAND ----------

try:
  queryTableExists = (spark.table(databaseTableName) is not None)
except:
  queryTableExists = False

# COMMAND ----------

queryTableExists

# COMMAND ----------

try:
  if queryTableExists:
    (stg_df.repartition(numPartitions) \
      .write \
      .mode("append") \
      .option("mergeSchema", True) \
      .format("delta") \
      .save(enrichedPath)
    )
  else:
    (stg_df.repartition(numPartitions) \
      .write \
      .mode("overwrite") \
      .format("delta") \
      .save(enrichedPath)
    )
    sql = """
    CREATE TABLE {0}
    USING delta
    LOCATION '{1}'
    """.format(destinationTableName, enrichedPath)
    spark.sql(sql)
except Exception as e:
  sourceName = "Query Zone Processing - Append Databricks Delta: Write to Query Zone"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Append Data in to Synapse DW from Current State

# COMMAND ----------

sanctionedZoneNotebookPath = "../Framework/Sanctioned Zone Processing - Load Synapse DW Overwrite"
stageSchemaName = "stage"
stageTableName = "Fill_Fact_Incremental"

run_with_retry(sanctionedZoneNotebookPath, 1200, {"parentPipeLineExecutionLogKey": notebookExecutionLogKey, "containerName": containerName, "schemaName": stageSchemaName, "tableName": stageTableName, "numPartitions": numPartitions})

# COMMAND ----------

execsp = "DELETE A \
          FROM brtl.Fill_Fact AS A \
          INNER JOIN stage.Fill_Fact_Incremental AS stg \
          ON A.Fill_Fact_Key = stg.Fill_Fact_Key"
try:
  execute_sqldw_stored_procedure_no_results(execsp)
except:
  sourceName = "Destination Table does not exist"

# COMMAND ----------

blob_storage_account_name = adlsGen2StorageAccountName
blob_storage_container_name = "temp"

tempDir = "abfss://{}@{}.dfs.core.windows.net/".format(blob_storage_container_name, blob_storage_account_name) + dbutils.widgets.get("tableName")

# COMMAND ----------

sqlDwUrlSmall, connectionProperties = build_sqldw_jdbc_url_and_connectionProperties(sqldwservername, sqldwdatabasename, sqldwusername, sqldwpassword)

# COMMAND ----------

try:
  stg_df \
    .write \
    .format("com.databricks.spark.sqldw") \
    .mode("append") \
    .option("url", sqlDwUrlSmall) \
    .option("dbtable", fullyQualifiedTableName) \
    .option("useAzureMSI","True") \
    .option("maxStrLength",2048) \
    .option("tempdir", tempDir) \
    .save()
except Exception as e:
  sourceName = "Sanctioned Zone Processing - Load Azure SQL DW: Load Synapse SQL Data Warehouse"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Drop Temporary Table and Views

# COMMAND ----------

dbutils.fs.rm(tempDir,True)

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.Fill_Fact_Incremental")
spark.sql(sql)

# COMMAND ----------

execsp = "IF OBJECT_ID('stage.DimLocationView') IS NOT NULL DROP TABLE stage.Fill_Fact_Incremental"
execute_sqldw_stored_procedure_no_results(execsp)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Optimize and Vacuum Table

# COMMAND ----------

sql="""OPTIMIZE {0}""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

if vacuumRetentionHours != '':
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", False)
  spark.sql("VACUUM " + databaseTableName + " RETAIN " + vacuumRetentionHours + " HOURS")
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", True)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Log Completion

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Completed
# MAGIC val logMessage = "Completed"
# MAGIC val notebookContext = ""
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

log_event_notebook_end(notebookExecutionLogKey=notebookExecutionLogKey, notebookStatus="SUCCEEDED", notebookName=notebookName, notebookExecutionGroupName="")
dbutils.notebook.exit("Succeeded")