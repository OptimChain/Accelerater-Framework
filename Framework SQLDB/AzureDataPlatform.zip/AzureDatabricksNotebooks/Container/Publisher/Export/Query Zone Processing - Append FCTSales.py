# Databricks notebook source
# MAGIC 
# MAGIC  
# MAGIC %md
# MAGIC # Query Zone Processing - Append FCTSales
# MAGIC ###### Author: Ranga Bondada 12/15/2020
# MAGIC 
# MAGIC Data Lake pattern for tables that are staged and merged into the final enriched version.  Takes a file from the raw data path and overwrites the table in the Query zone.      
# MAGIC 
# MAGIC #### Usage
# MAGIC Supply the parameters above and run the notebook.  
# MAGIC 
# MAGIC #### Prerequisites
# MAGIC 1. Data must exist in the Data Lake /query zone (current State).   
# MAGIC 
# MAGIC #### Details

# COMMAND ----------

# MAGIC %md
# MAGIC #### Initialize Framework

# COMMAND ----------

dbutils.widgets.text(name="containerName", defaultValue="brtl", label="Container Name")
containerName = dbutils.widgets.get("containerName")

# COMMAND ----------

# MAGIC %run ../Framework/Secrets_Databricks_Container

# COMMAND ----------

# MAGIC %run ../Framework/Neudesic_Framework_Functions

# COMMAND ----------

spark.conf.set("spark.databricks.delta.merge.joinBasedMerge.enabled", True)

# COMMAND ----------

dbutils.widgets.text(name="parentPipeLineExecutionLogKey", defaultValue="-1", label="Parent Pipeline Execution Log Key")
dbutils.widgets.text(name="numPartitions", defaultValue="32", label="Number of Partitions")
dbutils.widgets.text(name="schemaName", defaultValue="brtl", label="Schema Name")
dbutils.widgets.text(name="tableName", defaultValue="FCTSales", label="Table Name")
dbutils.widgets.text(name="vacuumRetentionHours", defaultValue="", label="Vacuum Retention Hours")
dbutils.widgets.text(name="primaryKeyColumns", defaultValue="", label="Primary Key Columns")
dbutils.widgets.text(name="timestampColumns", defaultValue="", label="Timestamp Columns")

parentPipeLineExecutionLogKey = dbutils.widgets.get("parentPipeLineExecutionLogKey")
fullPathPrefix = "abfss://" + containerName + "@" + adlsGen2StorageAccountName + ".dfs.core.windows.net" 

numPartitions = int(dbutils.widgets.get("numPartitions"))

schemaName = dbutils.widgets.get("schemaName")
tableName = dbutils.widgets.get("tableName")

destinationTableName = tableName

fullyQualifiedTableName = schemaName + "." + destinationTableName
primaryKeyColumns = dbutils.widgets.get("primaryKeyColumns")
timestampColumns = dbutils.widgets.get("timestampColumns")

enrichedPath = fullPathPrefix + "/Query/Enriched/" + destinationTableName
databaseTableName = containerName + "." + destinationTableName
vacuumRetentionHours = dbutils.widgets.get("vacuumRetentionHours")

currentStatePath = fullPathPrefix + "/Query/CurrentState/" + tableName

# COMMAND ----------

notebookName = "Query Zone Processing - Append FCTSalesArchive"
notebookExecutionLogKey = log_event_notebook_start(notebookName,parentPipeLineExecutionLogKey)
print("Notebook Execution Log Key: {0}".format(notebookExecutionLogKey))

# COMMAND ----------

print("Schema Name: {0}".format(schemaName))
# print("Source Table Name: {0}".format(stageTableName))
print("Table Name: {0}".format(tableName))
print("Fully Qualified Table Name: {0}".format(fullyQualifiedTableName))
print("Number of Partitions: {0}".format(numPartitions))
print("Current State Path: {0}".format(currentStatePath))
# print("Current State Stage Path: {0}".format(currentStateStagePath))
print("Enriched State Path: {0}".format(enrichedPath))

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Starting
# MAGIC val notebookPath = dbutils.notebook.getContext.notebookPath.get
# MAGIC val logMessage = "Starting"
# MAGIC val notebookContext = dbutils.notebook.getContext().toJson
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read Existing Data from Query Zone (CurrentState}

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.CUSTINVOICETRANS")
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.INVENTTRANSORIGIN")
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.INVENTTRANS")
spark.sql(sql)

sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.PARTITIONS")
spark.sql(sql)

sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.CUSTINVOICEJOUR")
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.INVENTDIM")
spark.sql(sql)

sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.INVENTTRANSORIGIN")
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.ECORESPRODUCTCATEGORYEXPANDED")
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.RETAILCUSTINVOICEJOURTABLE")
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.LOGISTICSPOSTALADDRESS")
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.ECORESCATEGORY")
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.HCMWORKER")
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.RETAILTRANSACTIONSALESTRANS")
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.RETAILTRANSACTIONTABLE")
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.ECORESCATEGORY")
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl.CUSTINVOICETRANS", fullPathPrefix + "/Query/CurrentState/" + "CUSTINVOICETRANS")
spark.sql(sql)


sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl.INVENTTRANSORIGIN", fullPathPrefix + "/Query/CurrentState/" + "INVENTTRANSORIGIN")
spark.sql(sql)

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl.INVENTTRANS", fullPathPrefix + "/Query/CurrentState/" + "INVENTTRANS")
spark.sql(sql)


sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl.PARTITIONS", fullPathPrefix + "/Query/CurrentState/" + "PARTITIONS")
spark.sql(sql)

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl.CUSTINVOICEJOUR", fullPathPrefix + "/Query/CurrentState/" + "CUSTINVOICEJOUR")
spark.sql(sql)

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl.INVENTDIM", fullPathPrefix + "/Query/CurrentState/" + "INVENTDIM")
spark.sql(sql)
sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl.INVENTTRANSORIGIN", fullPathPrefix + "/Query/CurrentState/" + "INVENTTRANSORIGIN")
spark.sql(sql) 
sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl.ECORESPRODUCTCATEGORYEXPANDED", fullPathPrefix + "/Query/CurrentState/" + "ECORESPRODUCTCATEGORYEXPANDED")
spark.sql(sql) 
sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl.RETAILCUSTINVOICEJOURTABLE", fullPathPrefix + "/Query/CurrentState/" + "RETAILCUSTINVOICEJOURTABLE")
spark.sql(sql) 
sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl.LOGISTICSPOSTALADDRESS", fullPathPrefix + "/Query/CurrentState/" + "LOGISTICSPOSTALADDRESS")
spark.sql(sql)
sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl.ECORESCATEGORY", fullPathPrefix + "/Query/CurrentState/" + "ECORESCATEGORY")
spark.sql(sql)
sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl.HCMWORKER", fullPathPrefix + "/Query/CurrentState/" + "HCMWORKER")
spark.sql(sql)
sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl.RETAILTRANSACTIONSALESTRANS", fullPathPrefix + "/Query/CurrentState/" + "RETAILTRANSACTIONSALESTRANS")
spark.sql(sql)
sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl.RETAILTRANSACTIONTABLE", fullPathPrefix + "/Query/CurrentState/" + "RETAILTRANSACTIONTABLE")
spark.sql(sql)
sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl.ECORESCATEGORY", fullPathPrefix + "/Query/CurrentState/" + "ECORESCATEGORY")
spark.sql(sql)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read STG Data from Query Zone (CurrentState}

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS brtl.ctePrice

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE brtl.ctePrice
# MAGIC AS
# MAGIC SELECT 
# MAGIC 	rtst.RECID
# MAGIC 	,CASE WHEN SUM(ABS(tr.QTY)) = 0 THEN 0 ELSE SUM(ABS(tr.COSTAMOUNTPOSTED + tr.COSTAMOUNTADJUSTMENT))/SUM(ABS(tr.QTY)) END AS Price
# MAGIC FROM brtl.RETAILTRANSACTIONSALESTRANS rtst
# MAGIC INNER JOIN brtl.CUSTINVOICETRANS cit
# MAGIC 	ON rtst.PARTITION = cit.PARTITION 
# MAGIC 	AND rtst.DATAAREAID = cit.DATAAREAID 
# MAGIC 	AND rtst.INVENTTRANSID = cit.INVENTTRANSID 
# MAGIC LEFT OUTER JOIN brtl.INVENTTRANSORIGIN ito 
# MAGIC 	ON ito.REFERENCECATEGORY=0 
# MAGIC 	AND cit.INVENTTRANSID=ito.INVENTTRANSID 
# MAGIC 	AND cit.DATAAREAID=ito.DATAAREAID
# MAGIC 	AND cit.PARTITION=ito.PARTITION
# MAGIC LEFT OUTER JOIN brtl.INVENTTRANS tr
# MAGIC 	ON cit.PARTITION=tr.PARTITION 
# MAGIC 	AND cit.DATAAREAID=tr.DATAAREAID 
# MAGIC 	AND cit.INVOICEID=tr.INVOICEID 
# MAGIC 	AND ito.RECID=tr.INVENTTRANSORIGIN
# MAGIC WHERE rtst.TRANSACTIONSTATUS IN (0, 2)
# MAGIC GROUP BY 
# MAGIC 	rtst.RECID

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP VIEW IF EXISTS brtl.FCTSalesView

# COMMAND ----------

stgViewName =  "brtl.FCTSalesView"

sql="""
CREATE OR REPLACE VIEW {0} 
AS
SELECT 	STRING(
	case when rtst.TRANSACTIONID is null 
	then 'Non-retail'
	else 'Retail' end 
	)
	as RetailTransactionType,
	case when rtst.TRANSACTIONID is null 
	then cit.RECID 
	else rtst.RECID end as SalesKey,
	cit.DATAAREAID AS CompanyCode,
	cit.COMMISSAMOUNTMST AS CommissionAmountMaster,
	cit.INVOICEDATE AS InvoiceDate,
	cit.INVOICEID AS InvoiceNumber,
	cit.ITEMID AS ItemCode,
	case when rtst.TRANSACTIONID is null 
		then cit.LINEAMOUNTMST 
		else -rtst.NETAMOUNT end  AS AmountMaster,
	case when rtst.TRANSACTIONID is null 
		then cit.LINEAMOUNTTAXMST 
		else -rtst.NETAMOUNTINCLTAX END AS TaxAmountMaster,
	case when rtst.TRANSACTIONID is null 
	then cit.QTY 
	else -rtst.QTY end AS SalesQuantity,
	case when rtst.TRANSACTIONID is null 
	then cit.QTYPHYSICAL
	else -rtst.QTY end AS PhysicalQuantity,	
	cit.RETURNARRIVALDATE AS ReturnArrivalDate,
	cit.RETURNCLOSEDDATE AS ReturnClosedDate,
	case when rtst.TRANSACTIONID is null 
		THEN cit.SALESUNIT 
		ELSE rtst.unit end AS SalesUnit,
	case when rtst.TRANSACTIONID is null 
	then cit.INVENTQTY 
	else -rtst.QTY end AS InventoryQuantity,
	STRING(case cit.DELIVERYTYPE when 0 then '' when 1 then 'Direct Delivery' end) AS DeliveryType,
	STRING(case cit.STOCKEDPRODUCT when 0 then 'Not Stocked' when 1 then 'Stocked' end ) AS StockedProduct,
	cit.CURRENCYCODE AS CurrencyCode,
	case when rtst.TRANSACTIONID is null 
	then cit.SALESCATEGORY
	else rtst.CATEGORYID end AS CategoryId,
	case when rtst.TRANSACTIONID is null 
	then cat.NAME
	else RstCat.NAME end AS Category,		
	(CAST ((CASE  WHEN cit.ITEMID='' OR pc.RECIDCATEGORY IS NULL THEN cit.SALESCATEGORY ELSE pc.RECIDCATEGORY END) AS BIGINT)) AS CurrentCategoryId,
		daddr.CITY as DeliveryCity,
	daddr.ZIPCODE as DeliveryZipCode,
	daddr.COUNTRYREGIONID as DeliveryCountryorRegion,
	cij.INVOICEACCOUNT AS InvoiceAccount,
	cij.ORDERACCOUNT AS OrderAccount,
	case when rtst.TRANSACTIONID is null 
		then wrk.PERSONNELNUMBER 
		else rt.STAFF end as SalesTaker,
	cij.DUEDATE AS DueDate,
	cit.INVENTDIMID as InventoryDimensionId,
	cit.DEFAULTDIMENSION as DefaultDimensionId,
	'' AS InventoryUnit,
	rcij.OMINTERNALORGANIZATION AS OrganizationId,
	rcij.RETAILCHANNEL AS RetailChannelId,
	rcij.RETAILSTOREID AS RetailStoreCode,
	rcij.RETAILTERMINALID AS RetailTerminalCode,
	-rtst.QTY * prc.Price AS COGS,
	0.00 AS COGS2,
	STRING(rtst.TRANSACTIONID) as RetailStoreTransactionCode,
	rtst.PERIODICDISCTYPE as PeriodicDiscountTypeCode,
	rtst.PERIODICDISCGROUP as PeriodicDiscountGroupCode,
	rt.loyaltyCardId as LoyaltyCardCode,
	cij.SALESORIGINID SalesOriginCode,
	case 
	when rtst.TRANSACTIONID is not null then rtst.DISCAMOUNT 
	else cit.SUMLINEDISC 
	end  AS DiscountAmountMaster,
	case 
	when rtst.TRANSTIME is null then 0
	else rtst.TRANSTIME
	end  AS RetailTransactionTime,
	STRING('Posted') as TransactionStatus,
	case 
	when rtst.TRANSACTIONID is not null then rtst.CREATEDDATETIME
	else cit.CREATEDDATETIME 
	end  AS CreatedDateTime
	--,cit.SYS_CHANGE_OPERATION
	--,cit.SYS_CHANGE_VERSION
	,cit.RECID
FROM  brtl.CUSTINVOICETRANS cit 
INNER JOIN  brtl.PARTITIONS p on p.RECID = cit.PARTITION 
                                and p.PARTITIONKEY = 'initial'
INNER JOIN  brtl.CUSTINVOICEJOUR cij on ((cit.PARTITION = cij.PARTITION) 
                                      AND (cit.DATAAREAID = cij.DATAAREAID) 
                                      AND (cit.SALESID=cij.SALESID) 
                                      AND (cit.INVOICEID=cij.INVOICEID) 
                                      AND (cit.INVOICEDATE=cij.INVOICEDATE) 
                                      AND (cit.NUMBERSEQUENCEGROUP=cij.NUMBERSEQUENCEGROUP))
LEFT OUTER JOIN  brtl.INVENTTRANSORIGIN ito ON ((ito.REFERENCECATEGORY=0) 
                                            AND (cit.INVENTTRANSID=ito.INVENTTRANSID 
                                            AND (cit.DATAAREAID = ito.DATAAREAID) 
                                            AND (cit.PARTITION = ito.PARTITION))) 
LEFT OUTER JOIN  brtl.ECORESPRODUCTCATEGORYEXPANDED pc ON ((pc.NAMEDCATEGORYHIERARCHYROLE in (3,4)) 
                                                        AND (cit.ITEMID=pc.ITEMID 
                                                        AND (cit.DATAAREAID = pc.DATAAREAID) 
                                                        AND (cit.PARTITION = pc.PARTITION))) 
LEFT OUTER JOIN  brtl.RETAILCUSTINVOICEJOURTABLE rcij ON (cij.RECID=rcij.CUSTINVOICEJOUR 
                                                      AND (cij.DATAAREAID = rcij.DATAAREAID) 
                                                      AND (cij.PARTITION = rcij.PARTITION)) 
LEFT OUTER JOIN  brtl.LOGISTICSPOSTALADDRESS daddr on (daddr.RECID = cit.DELIVERYPOSTALADDRESS)
LEFT OUTER JOIN  brtl.ECORESCATEGORY cat on cat.RECID = cit.SALESCATEGORY
LEFT OUTER JOIN  brtl.HCMWORKER wrk on wrk.RECID = cij.WORKERSALESTAKER
INNER JOIN  brtl.RETAILTRANSACTIONSALESTRANS rtst on rtst.PARTITION = cit.PARTITION 
                                                  and rtst.DATAAREAID = cit.DATAAREAID 
                                                  and rtst.INVENTTRANSID = cit.INVENTTRANSID 
                                                  and rtst.INVENTTRANSID <> '' 
                                                  and rtst.TRANSACTIONSTATUS in (0, 2) 
LEFT OUTER JOIN  brtl.RETAILTRANSACTIONTABLE rt on rt.PARTITION = rtst.PARTITION 
                                                and rt.DATAAREAID = rtst.DATAAREAID 
                                                and rt.STORE = rtst.STORE 
                                                and rt.TERMINAL = rtst.TERMINALID 
                                                and rt.TRANSACTIONID = rtst.TRANSACTIONID 
                                                and rt.TYPE =2 
LEFT OUTER JOIN  brtl.ECORESCATEGORY RstCat on RstCat.RECID = rtst.CATEGORYID
LEFT OUTER JOIN brtl.ctePrice prc ON prc.RECID = rtst.RECID
""".format(stgViewName)
display(spark.sql(sql))

# COMMAND ----------

sql="""
SELECT *
  FROM {0}
""".format(stgViewName)
stg_df=(spark.sql(sql))

# COMMAND ----------

try:
  #read enrichedPath into a dataframe if it exists, otherwise create it
  dst_df = spark.read \
  .format("delta") \
  .load(enrichedPath) \
  .dropDuplicates()
except Exception as e:
  (stg_df \
  .write \
  .mode("overwrite") \
  .format("delta") \
  .save(enrichedPath)
)

# COMMAND ----------

sql="""
CREATE TABLE IF NOT EXISTS brtl.FCTSales
USING  delta
LOCATION '{1}'
""".format("brtl.FCTSales", enrichedPath)
spark.sql(sql)

# COMMAND ----------

sql="""
SELECT  InvoiceDate,InvoiceNumber,count(*)
  FROM {0}
  Group by InvoiceDate,InvoiceNumber
  Having Count(*) > 1
""".format(stgViewName)
display(spark.sql(sql))

# COMMAND ----------

spark.conf.set("spark.sql.crossJoin.enabled", "true")

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC MERGE INTO brtl.FCTSales fct
# MAGIC USING brtl.FCTSalesView stg
# MAGIC ON fct.RECID = stg.RECID AND fct.SalesKey = stg.SalesKey
# MAGIC WHEN MATCHED THEN
# MAGIC   DELETE
# MAGIC   
# MAGIC  

# COMMAND ----------

# MAGIC %md
# MAGIC #### Append Data in Query Zone (Enriched)

# COMMAND ----------

try:
  queryTableExists = (spark.table(databaseTableName) is not None)
except:
  queryTableExists = False

# COMMAND ----------

queryTableExists

# COMMAND ----------

try:
  if queryTableExists:
    (stg_df.repartition(numPartitions) \
      .write \
      .mode("append") \
      .option("mergeSchema", True) \
      .format("delta") \
      .save(enrichedPath)
    )
  else:
    (stg_df.repartition(numPartitions) \
      .write \
      .mode("overwrite") \
      .format("delta") \
      .save(enrichedPath)
    )
    sql = """
    CREATE TABLE {0}
    USING delta
    LOCATION '{1}'
    """.format(destinationTableName, enrichedPath)
    spark.sql(sql)
except Exception as e:
  sourceName = "Query Zone Processing - Append Databricks Delta: Write to Query Zone"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Append Data in to Synapse DW from Current State

# COMMAND ----------

sanctionedZoneNotebookPath = "../Framework/Sanctioned Zone Processing - Load Synapse DW Overwrite"
stageSchemaName = "stage"
stageTableName = "FCTSalesView"

run_with_retry(sanctionedZoneNotebookPath, 1200, {"parentPipeLineExecutionLogKey": notebookExecutionLogKey, "containerName": containerName, "schemaName": stageSchemaName, "tableName": stageTableName, "numPartitions": numPartitions})

# COMMAND ----------

execsp = "DELETE A FROM brtl.FCTSales A INNER JOIN stage.FCTSalesView stg ON  stg.recid = A.recid and stg.SalesKey = A.SalesKey"
try:
  execute_sqldw_stored_procedure_no_results(execsp)
except:
  sourceName = "Destination Table does not exist"

# COMMAND ----------

blob_storage_account_name = adlsGen2StorageAccountName
blob_storage_container_name = "temp"

tempDir = "abfss://{}@{}.dfs.core.windows.net/".format(blob_storage_container_name, blob_storage_account_name) + dbutils.widgets.get("tableName")

# COMMAND ----------

sqlDwUrlSmall, connectionProperties = build_sqldw_jdbc_url_and_connectionProperties(sqldwservername, sqldwdatabasename, sqldwusername, sqldwpassword)

# COMMAND ----------

try:
  stg_df \
    .write \
    .format("com.databricks.spark.sqldw") \
    .mode("append") \
    .option("url", sqlDwUrlSmall) \
    .option("dbtable", fullyQualifiedTableName) \
    .option("useAzureMSI","True") \
    .option("maxStrLength",2048) \
    .option("tempdir", tempDir) \
    .save()
except Exception as e:
  sourceName = "Sanctioned Zone Processing - Load Azure SQL DW: Load Synapse SQL Data Warehouse"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Drop Temporary Table and Views

# COMMAND ----------

dbutils.fs.rm(tempDir,True)

# COMMAND ----------

sql = """
DROP VIEW IF EXISTS {0}
""".format(stgViewName)
spark.sql(sql)

# COMMAND ----------

execsp = "IF OBJECT_ID('stage.FCTSalesView') IS NOT NULL DROP TABLE stage.FCTSalesView"
execute_sqldw_stored_procedure_no_results(execsp)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Optimize and Vacuum Table

# COMMAND ----------

sql="""OPTIMIZE {0}""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

if vacuumRetentionHours != '':
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", False)
  spark.sql("VACUUM " + databaseTableName + " RETAIN " + vacuumRetentionHours + " HOURS")
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", True)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Log Completion

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Completed
# MAGIC val logMessage = "Completed"
# MAGIC val notebookContext = ""
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

log_event_notebook_end(notebookExecutionLogKey=notebookExecutionLogKey, notebookStatus="SUCCEEDED", notebookName=notebookName, notebookExecutionGroupName="")
dbutils.notebook.exit("Succeeded")