# Databricks notebook source
# MAGIC 
# MAGIC  
# MAGIC %md
# MAGIC # Query Zone Processing - Overwrite FCTtInventoryAged
# MAGIC ###### Author: Ranga Bondada 12/16/2020
# MAGIC 
# MAGIC Data Lake pattern for tables with change feeds of new or updated records.  Takes a file from the raw data path and applies the updates to the Query zone.      
# MAGIC 
# MAGIC #### Usage
# MAGIC Supply the parameters above and run the notebook.  
# MAGIC 
# MAGIC #### Prerequisites
# MAGIC 1. Raw Data must exist in the Data Lake /raw zone in JSON format.  
# MAGIC 
# MAGIC #### Details

# COMMAND ----------

# MAGIC %md
# MAGIC #### Initialize

# COMMAND ----------

# MAGIC %run ../Framework/Secrets_Databricks_Container

# COMMAND ----------

# MAGIC %run ../Framework/Neudesic_Framework_Functions

# COMMAND ----------

dbutils.widgets.text(name="containerName", defaultValue="brtl", label="Container Name")
dbutils.widgets.text(name="parentPipeLineExecutionLogKey", defaultValue="-1", label="Parent Pipeline Execution Log Key")

# filePath is to pick up the schema of an actual file in the case of subfolders

dbutils.widgets.text(name="numPartitions", defaultValue="8", label="Number of Partitions")
dbutils.widgets.text(name="schemaName", defaultValue="brtl", label="Schema Name")
dbutils.widgets.text(name="tableName", defaultValue="FCTInventoryAged", label="Table Name")
dbutils.widgets.text(name="vacuumRetentionHours", defaultValue="", label="Vacuum Retention Hours")

parentPipeLineExecutionLogKey = dbutils.widgets.get("parentPipeLineExecutionLogKey")
containerName = dbutils.widgets.get("containerName")
fullPathPrefix = "abfss://" + containerName + "@" + adlsgen2storageaccountname + ".dfs.core.windows.net" 

numPartitions = int(dbutils.widgets.get("numPartitions"))

schemaName = dbutils.widgets.get("schemaName")
tableName = dbutils.widgets.get("tableName")
fullyQualifiedTableName = schemaName + "." + tableName

currentStateDestinationPath = fullPathPrefix + "/Query/Enriched/" + tableName

badRecordsPath = "/BadRecords/" + schemaName + "/" + tableName
fullBadRecordsPath = fullPathPrefix + badRecordsPath
databaseTableName = containerName + "." + tableName
vacuumRetentionHours = dbutils.widgets.get("vacuumRetentionHours")

# COMMAND ----------

notebookName = "Query Zone Processing - Overwrite FCTInventoryAged"
notebookExecutionLogKey = log_event_notebook_start(notebookName,parentPipeLineExecutionLogKey)
print("Notebook Execution Log Key: {0}".format(notebookExecutionLogKey))

# COMMAND ----------

print("Schema Name: {0}".format(schemaName))
print("Table Name: {0}".format(tableName))
print("Fully Qualified Table Name: {0}".format(fullyQualifiedTableName))
print("Number of Partitions: {0}".format(numPartitions))
print("Current State Destination Path: {0}".format(currentStateDestinationPath))
print("Bad Records Path: {0}".format(fullBadRecordsPath))
print("Database Table Name: {0}".format(databaseTableName))

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Starting
# MAGIC val notebookPath = dbutils.notebook.getContext.notebookPath.get
# MAGIC val logMessage = "Starting"
# MAGIC val notebookContext = dbutils.notebook.getContext().toJson
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read STG Data from Query Zone (CurrentState}

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS brtl.DimInventoryDimension
"""
spark.sql(sql)

sql = """
DROP TABLE IF EXISTS brtl.FCTInventoryValue
"""
spark.sql(sql)



# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS brtl.DimInventoryDimension
USING delta
LOCATION '{0}'
""".format(fullPathPrefix + "/Query/Enriched/"  + "DimInventoryDimension")
spark.sql(sql)

sql = """
CREATE TABLE IF NOT EXISTS brtl.FCTInventoryValue
USING delta
LOCATION '{0}'
""".format(fullPathPrefix + "/Query/Enriched/"  + "FCTInventoryValue")
spark.sql(sql)



# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS brtl.Onhand

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM brtl.FCTInventoryValue LIMIT 10

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM brtl.DimInventoryDimension

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE brtl.Onhand
# MAGIC AS
# MAGIC SELECT 
# MAGIC        iv.CompanyCode
# MAGIC        --,iv.ProductKey
# MAGIC        --,iv.CategoryHierarchyKey
# MAGIC        ,iv.CategoryId
# MAGIC        ,IFNULL(id.InventorySiteCode,'') as InventorySiteCode
# MAGIC        ,ifnull(id.WarehouseCode,'') as WarehouseCode
# MAGIC        ,id.InventorySite
# MAGIC        ,id.Warehouse
# MAGIC        ,id.InventoryDimensionKey
# MAGIC        ,-1 as DefaultDimensionKey
# MAGIC        ,sum(iv.Quantity) as Quantity
# MAGIC        ,sum(iv.CostAmount) as CostAmount
# MAGIC        ,sum(iv.CostAmount) / ifnull(sum(iv.Quantity), 0.0) as AvgUnitCost
# MAGIC FROM brtl.FCTInventoryValue iv
# MAGIC left outer join brtl.DimInventoryDimension id on id.InventoryDimensionId = iv.InventoryDimensionId
# MAGIC where iv.TransactionDate >=  ADD_MONTHS(iv.TransactionDate,-6)
# MAGIC group by iv.CompanyCode
# MAGIC        --,iv.ProductKey
# MAGIC        --,iv.CategoryHierarchyKey
# MAGIC        ,iv.CategoryId
# MAGIC        ,id.InventorySiteCode
# MAGIC        ,id.WarehouseCode
# MAGIC        ,id.InventorySite
# MAGIC        ,id.Warehouse
# MAGIC        ,id.InventoryDimensionKey
# MAGIC having sum(iv.Quantity) > 0.0;

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS brtl.Receipts

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE brtl.Receipts
# MAGIC AS
# MAGIC SELECT  iv.CompanyCode
# MAGIC        --,iv.ProductKey
# MAGIC        --,iv.CategoryHierarchyKey
# MAGIC        ,iv.CategoryId
# MAGIC        ,id.InventorySiteCode
# MAGIC        ,id.WarehouseCode
# MAGIC        ,id.InventorySite
# MAGIC        ,id.Warehouse
# MAGIC        ,id.InventoryDimensionKey
# MAGIC        ,-1 as DefaultDimensionKey
# MAGIC        ,iv.TransactionDate
# MAGIC        ,sum(iv.Quantity) as Received
# MAGIC from brtl.FCTInventoryValue iv 
# MAGIC left outer join brtl.DimInventoryDimension id on id.InventoryDimensionId = iv.InventoryDimensionId 
# MAGIC where iv.RecordType = 177
# MAGIC and iv.ReceiptStatus in ( 'Received', 'Purchased' )
# MAGIC and iv.TransactionDate >=  ADD_MONTHS(iv.TransactionDate,-6)
# MAGIC group by iv.CompanyCode
# MAGIC        --,iv.ProductKey
# MAGIC        --,iv.CategoryHierarchyKey
# MAGIC        ,iv.CategoryId
# MAGIC        ,id.InventorySiteCode
# MAGIC        ,id.WarehouseCode
# MAGIC        ,id.InventorySite
# MAGIC        ,id.Warehouse
# MAGIC        ,id.InventoryDimensionKey
# MAGIC        ,iv.TransactionDate

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP View if exists brtl.FCTInventoryAgedView

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE VIEW brtl.FCTInventoryAgedView
# MAGIC AS
# MAGIC SELECT
# MAGIC      CompanyCode
# MAGIC     --,ProductKey
# MAGIC     --,CategoryHierarchyKey
# MAGIC     ,CategoryId
# MAGIC     ,InventorySiteCode
# MAGIC     ,WarehouseCode
# MAGIC     ,TransactionDate
# MAGIC     ,case when OnhandQuantity >= TotalReceived then Received else OnhandQuantity - ( TotalReceived - Received ) end as Quantity
# MAGIC     ,AvgUnitCost
# MAGIC     ,case when OnhandQuantity >= TotalReceived then Received else OnhandQuantity - ( TotalReceived - Received ) end 
# MAGIC         * AvgUnitCost as CostAmount
# MAGIC     ,InventorySite
# MAGIC     ,Warehouse
# MAGIC     ,InventoryDimensionKey
# MAGIC     ,DefaultDimensionKey
# MAGIC from 
# MAGIC (
# MAGIC     select ia.CompanyCode
# MAGIC         --,ia.ProductKey
# MAGIC         --,ia.CategoryHierarchyKey
# MAGIC         ,ia.CategoryId
# MAGIC         ,ia.InventorySiteCode
# MAGIC         ,ia.WarehouseCode
# MAGIC         ,ia.Quantity as OnhandQuantity
# MAGIC         ,ia.AvgUnitCost
# MAGIC         ,r.Received
# MAGIC         ,r.TransactionDate
# MAGIC         ,SUM(r.Received)
# MAGIC                 OVER (PARTITION BY r.CompanyCode 
# MAGIC                                     --,r.ProductKey, r.CategoryHierarchyKey
# MAGIC                                     , r.InventorySiteCode, r.WarehouseCode, r.InventorySite, r.Warehouse, r.InventoryDimensionKey, r.DefaultDimensionKey
# MAGIC                 ORDER BY r.TransactionDate desc) AS TotalReceived
# MAGIC         ,ia.InventorySite
# MAGIC         ,ia.Warehouse
# MAGIC         ,ia.InventoryDimensionKey
# MAGIC         ,ia.DefaultDimensionKey
# MAGIC     from brtl.Onhand ia
# MAGIC     left outer join brtl.Receipts r 
# MAGIC         on r.CompanyCode = ia.CompanyCode
# MAGIC         --and r.ProductKey = ia.ProductKey 
# MAGIC         --and r.CategoryHierarchyKey = r.CategoryHierarchyKey
# MAGIC         and r.CategoryId = ia.CategoryId
# MAGIC         and r.InventorySiteCode = ia.InventorySiteCode
# MAGIC         and r.WarehouseCode = ia.WarehouseCode
# MAGIC         and r.InventorySite = ia.InventorySite
# MAGIC         and r.Warehouse = ia.Warehouse
# MAGIC         and r.InventoryDimensionKey = ia.InventoryDimensionKey
# MAGIC         and r.DefaultDimensionKey = ia.DefaultDimensionKey
# MAGIC ) as ageing
# MAGIC where TotalReceived - Received < OnhandQuantity

# COMMAND ----------

sql="""
SELECT * FROM brtl.FCTInventoryAgedView
"""
stg_df=(spark.sql(sql))

# COMMAND ----------

display(stg_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Write Data to Query Zone (Enriched)

# COMMAND ----------

display(spark.sql("DROP TABLE IF EXISTS " + databaseTableName))

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS brtl.FCTInventoryAged

# COMMAND ----------

try:
  (stg_df \
   .write \
   .mode("overwrite") \
   .option("overwriteSchema", "true") \
   .format("delta") \
   .save(currentStateDestinationPath)
  )
  sql = """
  CREATE TABLE brtl.FCTInventoryAged
  USING delta
  LOCATION '{0}'
  """.format(currentStateDestinationPath)
  spark.sql(sql)
except Exception as e:
  sourceName = "Query Zone Processing - Overwrite Delta Lake: Write to Query Zone"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

sql = """
SELECT * FROM {0}
""".format(databaseTableName)
display(spark.sql(sql))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Overwrite data into Synapse DW from Current State

# COMMAND ----------

execsp = "TRUNCATE TABLE brtl.FCTInventoryAged"
try:
  execute_sqldw_stored_procedure_no_results(execsp)
except:
  sourceName = "Destination Table does not exist"

# COMMAND ----------

if vacuumRetentionHours != '':
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", False)
  spark.sql("VACUUM " + databaseTableName + " RETAIN " + vacuumRetentionHours + " HOURS")
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", True)

# COMMAND ----------

blob_storage_account_name = adlsGen2StorageAccountName
blob_storage_container_name = "temp"

tempDir = "abfss://{}@{}.dfs.core.windows.net/".format(blob_storage_container_name, blob_storage_account_name) + dbutils.widgets.get("tableName")

# COMMAND ----------

sqlDwUrlSmall, connectionProperties = build_sqldw_jdbc_url_and_connectionProperties(sqldwservername, sqldwdatabasename, sqldwusername, sqldwpassword)

# COMMAND ----------

sql = """	
select 
    CompanyCode
       --,ProductKey
       --,CategoryHierarchyKey
       ,CategoryId
       ,InventorySiteCode
       ,WarehouseCode
       ,TransactionDate
       ,Quantity
       ,AvgUnitCost
       ,CostAmount
       ,InventorySite
       ,Warehouse
       ,InventoryDimensionKey
       ,DefaultDimensionKey
FROM brtl.FCTInventoryAgedView
"""
dest_df=spark.sql(sql)

# COMMAND ----------

try:
  dest_df \
    .write \
    .format("com.databricks.spark.sqldw") \
    .mode("append") \
    .option("url", sqlDwUrlSmall) \
    .option("dbtable", fullyQualifiedTableName) \
    .option("useAzureMSI","True") \
    .option("maxStrLength",2048) \
    .option("tempdir", tempDir) \
    .save()
except Exception as e:
  sourceName = "Sanctioned Zone Processing - Load Azure SQL DW: Load Synapse SQL Data Warehouse"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Drop Temporary Tables and Views

# COMMAND ----------

dbutils.fs.rm(tempDir,True)

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP View if exists brtl.FCTtInventoryAgedView

# COMMAND ----------

# MAGIC %md
# MAGIC #### Optimize and Vacuum Table

# COMMAND ----------

sql="""OPTIMIZE {0}""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

if vacuumRetentionHours != '':
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", False)
  spark.sql("VACUUM " + databaseTableName + " RETAIN " + vacuumRetentionHours + " HOURS")
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", True)

# COMMAND ----------

try:
  dbutils.fs.ls(badRecordsPath)
  sourceName = "Query Zone Processing - Overwrite Delta Lake: Bad Records"
  errorCode = "500"
  errorDescription = "Processing completed, but rows were written to badRecordsPath: {0}.  Raw records do not comply with the current schema for table {1}.{2}.".format(badRecordsPath, schemaName, tableName)
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise ValueError(errorDescription)
except:
  print("success")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Log Completion

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Completed
# MAGIC val logMessage = "Completed"
# MAGIC val notebookContext = ""
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

log_event_notebook_end(notebookExecutionLogKey=notebookExecutionLogKey, notebookStatus="SUCCEEDED", notebookName=notebookName, notebookExecutionGroupName="")
dbutils.notebook.exit("Succeeded")