# Databricks notebook source
# MAGIC  
# MAGIC  
# MAGIC  
# MAGIC %md
# MAGIC # Query Zone Processing - Append FCTPurchaseLine
# MAGIC ###### Author: Ranga Bondada 05/26/2020
# MAGIC 
# MAGIC Data Lake pattern for tables that are staged and merged into the final enriched version.  Takes a file from the raw data path and overwrites the table in the Query zone.      
# MAGIC 
# MAGIC #### Usage
# MAGIC Supply the parameters above and run the notebook.  
# MAGIC 
# MAGIC #### Prerequisites
# MAGIC 1. Data must exist in the Data Lake /query zone (current State).   
# MAGIC 
# MAGIC #### Details

# COMMAND ----------

# MAGIC %md
# MAGIC #### Initialize Framework

# COMMAND ----------

dbutils.widgets.text(name="containerName", defaultValue="brtl", label="Container Name")
containerName = dbutils.widgets.get("containerName")

# COMMAND ----------

# MAGIC %run ../Framework/Secrets_Databricks_Container

# COMMAND ----------

# MAGIC %run ../Framework/Neudesic_Framework_Functions

# COMMAND ----------

spark.conf.set("spark.databricks.delta.merge.joinBasedMerge.enabled", True)

# COMMAND ----------

dbutils.widgets.text(name="parentPipeLineExecutionLogKey", defaultValue="-1", label="Parent Pipeline Execution Log Key")
dbutils.widgets.text(name="numPartitions", defaultValue="8", label="Number of Partitions")
dbutils.widgets.text(name="schemaName", defaultValue="brtl", label="Schema Name")
dbutils.widgets.text(name="tableName", defaultValue="FCTPurchaseLine", label="Table Name")
dbutils.widgets.text(name="vacuumRetentionHours", defaultValue="", label="Vacuum Retention Hours")
dbutils.widgets.text(name="primaryKeyColumns", defaultValue="VendorName,ProductName", label="Primary Key Columns")
dbutils.widgets.text(name="timestampColumns", defaultValue="ModifiedDate", label="Timestamp Columns")

parentPipeLineExecutionLogKey = dbutils.widgets.get("parentPipeLineExecutionLogKey")
fullPathPrefix = "abfss://" + containerName + "@" + adlsGen2StorageAccountName + ".dfs.core.windows.net" 

numPartitions = int(dbutils.widgets.get("numPartitions"))

schemaName = dbutils.widgets.get("schemaName")
tableName =  dbutils.widgets.get("tableName")
fullyQualifiedTableName = schemaName + "." + tableName
primaryKeyColumns = dbutils.widgets.get("primaryKeyColumns")
timestampColumns = dbutils.widgets.get("timestampColumns")

enrichedPath = fullPathPrefix + "/Query/Enriched/" + tableName
databaseTableName = containerName + "." + tableName
vacuumRetentionHours = dbutils.widgets.get("vacuumRetentionHours")

currentStateDestinationPath = fullPathPrefix + "/Query/Enriched/" + tableName

# COMMAND ----------

stageTableName = "Purchline"

databaseStageTableName = schemaName + "." + stageTableName

currentStateStagePath = fullPathPrefix + "/Query/CurrentState/" + stageTableName


# COMMAND ----------

notebookName = "Query Zone Processing - Append FCTPurchaseLine"
notebookExecutionLogKey = log_event_notebook_start(notebookName,parentPipeLineExecutionLogKey)
print("Notebook Execution Log Key: {0}".format(notebookExecutionLogKey))

# COMMAND ----------

print("Schema Name: {0}".format(schemaName))
# print("Source Table Name: {0}".format(stageTableName))
print("Table Name: {0}".format(tableName))
print("Fully Qualified Table Name: {0}".format(fullyQualifiedTableName))
print("Number of Partitions: {0}".format(numPartitions))
print("Current State Destination Path: {0}".format(currentStateDestinationPath))
# print("Current State Stage Path: {0}".format(currentStateStagePath))
print("Enriched State Path: {0}".format(enrichedPath))

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Starting
# MAGIC val notebookPath = dbutils.notebook.getContext.notebookPath.get
# MAGIC val logMessage = "Starting"
# MAGIC val notebookContext = dbutils.notebook.getContext().toJson
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read Existing Data from Query Zone (CurrentState}

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read STG Data from Query Zone (CurrentState}

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format("DIMVendor")
spark.sql(sql)

sql = """
DROP TABLE IF EXISTS {0}
""".format("DIMProduct")
spark.sql(sql)

sql = """
DROP TABLE IF EXISTS {0}
""".format("Purchline")
spark.sql(sql)


# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("DIMVendor", fullPathPrefix + "/Query/Enriched/" + "DIMVendor")
spark.sql(sql)

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("DIMProduct", fullPathPrefix + "/Query/Enriched/" + "DIMProduct")
spark.sql(sql)

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("Purchline", fullPathPrefix + "/Query/CurrentState/" + "Purchline")
spark.sql(sql)

# COMMAND ----------

stgViewName =  schemaName + "." + "FCTPurchaseLine" + "_view"

sql = """
DROP VIEW IF EXISTS {0}
""".format(stgViewName)
spark.sql(sql)


# COMMAND ----------

sql="""
CREATE OR REPLACE VIEW {0} AS
SELECT
ACCOUNTINGDISTRIBUTIONTEMPLATE,
ACTIVITYNUMBER,
ADDRESSREFRECID,
ADDRESSREFTABLEID,
AGREEMENTSKIPAUTOLINK,
ASSETBOOKID,
ASSETGROUP,
ASSETID,
ASSETTRANSTYPEPURCH,
BARCODE,
BARCODETYPE,
BLOCKED,
BUDGETRESERVATIONLINE_PSN,
CASETAGGING,
CFOPTABLE_BR,
COMPLETE,
CONFIRMEDDLV,
CONFIRMEDTAXAMOUNT,
CONFIRMEDTAXWRITECODE,
COUNTYORIGDEST,
COVREF,
CREATEDDATETIME,
CREATEFIXEDASSET,
CREDITEDVENDINVOICETRANS,
CURRENCYCODE,
CUSTOMERREF,
CUSTPURCHASEORDERFORMNUM,
DATAAREAID,
DEFAULTDIMENSION,
DELIVERYDATE,
DELIVERYNAME,
DELIVERYPOSTALADDRESS,
DELIVERYTYPE,
DEPRECIATIONSTARTDATE,
DISCAMOUNT,
DISCPERCENT,
EADCAMPAIGNTABLE,
ECL_BARTELLSTORE,
ECL_IMPORTEDFROMK3S,
ECL_REQQTYORIG,
ECL_UPDATEBYMSTAR,
EDITABLEINWORKFLOW,
EXTERNALITEMID,
GSTHSTTAXTYPE_CA,
INTERCOMPANYINVENTTRANSID,
INTERCOMPANYORIGIN,
INTRASTATFULFILLMENTDATE_HU,
INVENTDIMID,
INVENTINVOICENOW,
INVENTRECEIVEDNOW,
INVENTREFID,
INVENTREFTRANSID,
INVENTTRANSID,
ISDELETED,
ISFINALIZED,
ISINVOICEMATCHED,
ISMODIFIED,
ISPWP,
ITEMBOMID,
ITEMID,
ITEMPBAID,
ITEMREFTYPE,
ITEMROUTEID,
ITEMTAGGING,
LEDGERDIMENSION,
LINEAMOUNT,
LINEDELIVERYTYPE,
LINEDISC,
LINEHEADER,
LINENUMBER,
LINEPERCENT,
MANUALENTRYCHANGEPOLICY,
MANUALMODIFIEDFIELD,
MATCHINGAGREEMENTLINE,
MATCHINGPOLICY,
MCRDROPSHIPCOMMENT,
MCRDROPSHIPMENT,
MCRDROPSHIPSTATUS,
MCRORDERLINE2PRICEHISTORYREF,
MODIFIEDDATETIME,
MULTILNDISC,
MULTILNPERCENT,
NAME AS ProductName,
OPERATIONTYPE_MX,
OVERDELIVERYPCT,
PALLETTAGGING,
PARTITION,
PDSCALCULATIONID,
PDSCWINVENTRECEIVEDNOW,
PDSCWQTY,
PDSCWREMAININVENTFINANCIAL,
PDSCWREMAININVENTPHYSICAL,
PLANREFERENCE,
PORT,
PRICEUNIT,
PROCUREMENTCATEGORY,
PROJCATEGORYID,
PROJID,
PROJLINEPROPERTYID,
PROJSALESCURRENCYID,
PROJSALESPRICE,
PROJSALESUNITID,
PROJTAXGROUPID,
PROJTAXITEMGROUPID,
PROJTRANSID,
PROJWORKER,
PSARETAINSCHEDULEID,
PSATOTALRETAINAMOUNT,
PURCHASETYPE,
PURCHCOMMITMENTLINE_PSN,
PURCHID,
PURCHMARKUP,
PURCHPRICE,
PURCHQTY,
PURCHRECEIVEDNOW,
PURCHREQID,
PURCHREQLINEREFID,
PURCHSTATUS,
PURCHUNIT,
QTYORDERED,
RBOPACKAGELINENUM,
RECID,
RECVERSION,
REMAINDER,
REMAININVENTFINANCIAL,
REMAININVENTPHYSICAL,
REMAINPURCHFINANCIAL,
REMAINPURCHPHYSICAL,
REQATTENTION,
REQPLANIDSCHED,
REQPOID,
REQUESTER,
RETAILLINENUMEX1,
RETAILPACKAGEID,
RETAILTEMPVALUEEX2,
RETURNACTIONID,
RETURNDISPOSITIONCODEID,
RETURNSTATUS,
SCRAP,
SERVICEADDRESS,
SERVICEDATE,
SHIPPINGDATECONFIRMED,
SHIPPINGDATEREQUESTED,
SKIPDISTRIBUTIONUPDATE,
SOURCEDOCUMENTLINE,
STATISTICVALUE_LT,
STATPROCID,
STATTRIANGULARDEAL,
STOCKEDPRODUCT,
SYSTEMENTRYCHANGEPOLICY,
SYSTEMENTRYSOURCE,
TAMITEMVENDREBATEGROUPID,
TAX1099AMOUNT,
TAX1099FIELDS,
TAX1099RECID,
TAX1099STATE,
TAX1099STATEAMOUNT,
TAXAUTOGENERATED,
TAXGROUP,
TAXITEMGROUP,
TAXSERVICECODE_BR,
TAXWITHHOLDBASECUR_TH,
TAXWITHHOLDGROUP_TH,
TAXWITHHOLDITEMGROUPHEADING_TH,
TRANSACTIONCODE,
TRANSPORT,
UNDERDELIVERYPCT,
VARIANTID,
VENDACCOUNT,
VENDGROUP,
WFDELIVERYDUESTATE,
WFINVRECEIVEDSTATE,
WORKFLOWSTATE,
'Query Zone Processing - Append FCTPurchaseLine' AS Created_By,
'' AS Modified_By,
cast(current_date() AS string) AS Last_Created,
'1900-01-01 00:00:00.0000000' AS Last_Modified
FROM {1}.{2} as a

""".format(stgViewName,schemaName,"Purchline","DIMProduct")
display(spark.sql(sql))
#INNER JOIN {1}.{3} as b on b.ProductName = a.Name
#LIMIT 100

# COMMAND ----------

sql="""
SELECT *
  FROM {0}
""".format(stgViewName)
stg_df=(spark.sql(sql))

# COMMAND ----------

display(stg_df)

# COMMAND ----------

sql="""
SELECT count(*)
  FROM {0}.{1}
""".format(schemaName,"Purchline")
display(spark.sql(sql))

# COMMAND ----------

sql="""
SELECT PURCHID, LINENUMBER, count(*)
  FROM {0}
  Group by ProductName,SERVICEDATE,PURCHID, LINENUMBER
""".format(stgViewName)
display(spark.sql(sql))

# COMMAND ----------

sql="""
CREATE OR REPLACE VIEW {0} AS
SELECT PURCHID, LINENUMBER FROM {1}
""".format("brtl.Incremental_FCTPurchaseLine_DateLoaded",stgViewName)
display(spark.sql(sql))

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM brtl.Incremental_FCTPurchaseLine_DateLoaded

# COMMAND ----------

try:
  #read enrichedPath into a dataframe if it exists, otherwise create it
  dst_df = spark.read \
    .format("delta") \
    .load(enrichedPath) \
    .dropDuplicates()
except Exception as e:
   (stg_df \
    .write \
    .mode("overwrite") \
    .format("delta") \
    .save(enrichedPath)
    )

# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl.FCTPurchaseLine", enrichedPath)
spark.sql(sql)

# COMMAND ----------

spark.conf.set("spark.sql.crossJoin.enabled", "true")

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO brtl.FCTPurchaseLine
# MAGIC USING brtl.Incremental_FCTPurchaseLine_DateLoaded
# MAGIC ON brtl.FCTPurchaseLine.PURCHID = brtl.Incremental_FCTPurchaseLine_DateLoaded.PURCHID
# MAGIC and brtl.FCTPurchaseLine.LINENUMBER = brtl.Incremental_FCTPurchaseLine_DateLoaded.LINENUMBER
# MAGIC WHEN MATCHED THEN
# MAGIC   DELETE

# COMMAND ----------

# MAGIC %md
# MAGIC #### Append Data in Query Zone (Current State)

# COMMAND ----------

try:
  queryTableExists = (spark.table(databaseTableName) is not None)
except:
  queryTableExists = False

# COMMAND ----------

queryTableExists

# COMMAND ----------

try:
  if queryTableExists:
    (stg_df \
      .write \
      .mode("append") \
      .format("delta") \
      .save(currentStateDestinationPath)
    )
  else:
    (stg_df \
      .write \
      .mode("overwrite") \
      .format("delta") \
      .save(currentStateDestinationPath)
    )
    sql = """
    CREATE TABLE {0}
    USING delta
    LOCATION '{1}'
    """.format(fullyQualifiedTableName, currentStateDestinationPath)
    spark.sql(sql)
except Exception as e:
  sourceName = "Query Zone Processing - Append Databricks Delta: Write to Query Zone"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Append Data in to Synapse DW from Current State

# COMMAND ----------

sanctionedZoneNotebookPath = "../Framework/Sanctioned Zone Processing - Load Synapse DW Overwrite"
stageSchemaName = "stage"
stageTableName = "Incremental_FCTPurchaseLine_DateLoaded"

run_with_retry(sanctionedZoneNotebookPath, 1200, {"parentPipeLineExecutionLogKey": notebookExecutionLogKey, "containerName": containerName, "schemaName": stageSchemaName, "tableName": stageTableName, "numPartitions": numPartitions})

# COMMAND ----------

execsp = "DELETE brtl.FCTPurchaseLine FROM brtl.FCTPurchaseLine f JOIN stage.Incremental_FCTPurchaseLine_DateLoaded s on f.PURCHID = s.PURCHID and f.LINENUMBER = s.LINENUMBER"
try:
  execute_sqldw_stored_procedure_no_results(execsp)
except:
  sourceName = "Destination Table does not exist"

# COMMAND ----------

blob_storage_account_name = adlsGen2StorageAccountName
blob_storage_container_name = "temp"

tempDir = "abfss://{}@{}.dfs.core.windows.net/".format(blob_storage_container_name, blob_storage_account_name) + dbutils.widgets.get("tableName")

# COMMAND ----------

sqlDwUrlSmall, connectionProperties = build_sqldw_jdbc_url_and_connectionProperties(sqldwservername, sqldwdatabasename, sqldwusername, sqldwpassword)

# COMMAND ----------

try:
  stg_df \
    .write \
    .format("com.databricks.spark.sqldw") \
    .mode("append") \
    .option("url", sqlDwUrlSmall) \
    .option("dbtable", fullyQualifiedTableName) \
    .option("useAzureMSI","True") \
    .option("maxStrLength",2048) \
    .option("tempdir", tempDir) \
    .save()
except Exception as e:
  sourceName = "Sanctioned Zone Processing - Load Azure SQL DW: Load Synapse SQL Data Warehouse"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Drop Temporary Table and Views

# COMMAND ----------

dbutils.fs.rm(tempDir,True)

# COMMAND ----------

sql = """
DROP VIEW IF EXISTS {0}
""".format("brtl.Incremental_FCTPurchaseLine_DateLoaded")
spark.sql(sql)

# COMMAND ----------

sql = """
DROP VIEW IF EXISTS {0}
""".format(stgViewName)
spark.sql(sql)

# COMMAND ----------

execsp = "IF OBJECT_ID('stage.Incremental_FCTPurchaseLine_DateLoaded') IS NOT NULL DROP TABLE stage.Incremental_FCTPurchaseLine_DateLoaded"
execute_sqldw_stored_procedure_no_results(execsp)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Optimize and Vacuum Table

# COMMAND ----------

sql="""OPTIMIZE {0}""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

if vacuumRetentionHours != '':
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", False)
  spark.sql("VACUUM " + databaseTableName + " RETAIN " + vacuumRetentionHours + " HOURS")
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", True)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Log Completion

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Completed
# MAGIC val logMessage = "Completed"
# MAGIC val notebookContext = ""
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

log_event_notebook_end(notebookExecutionLogKey=notebookExecutionLogKey, notebookStatus="SUCCEEDED", notebookName=notebookName, notebookExecutionGroupName="")
dbutils.notebook.exit("Succeeded")