# Databricks notebook source
# MAGIC  
# MAGIC  
# MAGIC  
# MAGIC %md
# MAGIC # Query Zone Processing - Append FCTInventoryTrans
# MAGIC ###### Author: Mike Sherrill 06/02/2020
# MAGIC 
# MAGIC Data Lake pattern for tables that are staged and merged into the final enriched version.  Takes a file from the raw data path and overwrites the table in the Query zone.      
# MAGIC 
# MAGIC #### Usage
# MAGIC Supply the parameters above and run the notebook.  
# MAGIC 
# MAGIC #### Prerequisites
# MAGIC 1. Data must exist in the Data Lake /query zone (current State).   
# MAGIC 
# MAGIC #### Details

# COMMAND ----------

# MAGIC %md
# MAGIC #### Initialize Framework

# COMMAND ----------

dbutils.widgets.text(name="containerName", defaultValue="brtl", label="Container Name")
containerName = dbutils.widgets.get("containerName")

# COMMAND ----------

# MAGIC %run ../Framework/Secrets_Databricks_Container

# COMMAND ----------

# MAGIC %run ../Framework/Neudesic_Framework_Functions

# COMMAND ----------

spark.conf.set("spark.databricks.delta.merge.joinBasedMerge.enabled", True)

# COMMAND ----------

dbutils.widgets.text(name="parentPipeLineExecutionLogKey", defaultValue="-1", label="Parent Pipeline Execution Log Key")
dbutils.widgets.text(name="numPartitions", defaultValue="32", label="Number of Partitions")
dbutils.widgets.text(name="schemaName", defaultValue="brtl", label="Schema Name")
dbutils.widgets.text(name="tableName", defaultValue="INVENTTRANS", label="Table Name")
dbutils.widgets.text(name="vacuumRetentionHours", defaultValue="", label="Vacuum Retention Hours")
dbutils.widgets.text(name="primaryKeyColumns", defaultValue="", label="Primary Key Columns")
dbutils.widgets.text(name="timestampColumns", defaultValue="", label="Timestamp Columns")

parentPipeLineExecutionLogKey = dbutils.widgets.get("parentPipeLineExecutionLogKey")
fullPathPrefix = "abfss://" + containerName + "@" + adlsGen2StorageAccountName + ".dfs.core.windows.net" 

numPartitions = int(dbutils.widgets.get("numPartitions"))

destinationTableName = 'FCTInventoryTrans'
tableName='INVENTTRANS'

schemaName = dbutils.widgets.get("schemaName")

fullyQualifiedTableName = schemaName + "." + destinationTableName
primaryKeyColumns = dbutils.widgets.get("primaryKeyColumns")
timestampColumns = dbutils.widgets.get("timestampColumns")

enrichedPath = fullPathPrefix + "/Query/Enriched/" + destinationTableName
databaseTableName = containerName + "." + destinationTableName
vacuumRetentionHours = dbutils.widgets.get("vacuumRetentionHours")

currentStatePath = fullPathPrefix + "/Query/CurrentState/" + tableName



# COMMAND ----------

notebookName = "Query Zone Processing - Append FCTInventoryTrans"
notebookExecutionLogKey = log_event_notebook_start(notebookName,parentPipeLineExecutionLogKey)
print("Notebook Execution Log Key: {0}".format(notebookExecutionLogKey))

# COMMAND ----------

print("Schema Name: {0}".format(schemaName))
# print("Source Table Name: {0}".format(stageTableName))
print("Table Name: {0}".format(tableName))
print("Fully Qualified Table Name: {0}".format(fullyQualifiedTableName))
print("Number of Partitions: {0}".format(numPartitions))
print("Current State Path: {0}".format(currentStatePath))
# print("Current State Stage Path: {0}".format(currentStateStagePath))
print("Enriched State Path: {0}".format(enrichedPath))

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Starting
# MAGIC val notebookPath = dbutils.notebook.getContext.notebookPath.get
# MAGIC val logMessage = "Starting"
# MAGIC val notebookContext = dbutils.notebook.getContext().toJson
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

sqlDwUrlSmall, connectionProperties = build_sqldw_jdbc_url_and_connectionProperties(sqldwservername, sqldwdatabasename, sqldwusername, sqldwpassword)

# COMMAND ----------


query = """(
SELECT 
 [ACTIVITYNUMBER]
      ,[AXAOLDTRANSCHILDREFID]
      ,[COSTAMOUNTADJUSTMENT]
      ,[COSTAMOUNTOPERATIONS]
      ,[COSTAMOUNTPHYSICAL]
      ,[COSTAMOUNTPOSTED]
      ,[COSTAMOUNTSECCURADJUSTMENT_RU]
      ,[COSTAMOUNTSECCURPHYSICAL_RU]
      ,[COSTAMOUNTSECCURPOSTED_RU]
      ,[COSTAMOUNTSETTLED]
      ,[COSTAMOUNTSETTLEDSECCUR_RU]
      ,[COSTAMOUNTSTD]
      ,[COSTAMOUNTSTDSECCUR_RU]
      ,[CURRENCYCODE]
      ,[DATAAREAID]
      ,[DATECLOSED]
      ,[DATECLOSEDSECCUR_RU]
      ,[DATEEXPECTED]
      ,[DATEFINANCIAL]
      ,[DATEINVENT]
      ,[DATEPHYSICAL]
      ,[DATESTATUS]
      ,[GROUPREFID_RU]
      ,[GROUPREFTYPE_RU]
      ,[INTERCOMPANYINVENTDIMTRANSFERRED]
      ,[INVENTDIMFIXED]
      ,[INVENTDIMID]
      ,[INVENTDIMIDSALES_RU]
      ,[INVENTTRANSORIGIN]
      ,[INVENTTRANSORIGINDELIVERY_RU]
      ,[INVENTTRANSORIGINSALES_RU]
      ,[INVENTTRANSORIGINTRANSIT_RU]
      ,[INVOICEID]
      ,[INVOICERETURNED]
      ,[ITEMID]
      ,[MARKINGREFINVENTTRANSORIGIN]
      ,[MODIFIEDDATETIME]
      ,[NONFINANCIALTRANSFERINVENTCLOSING]
      ,[PACKINGSLIPID]
      ,[PACKINGSLIPRETURNED]
      ,[PARTITION]
      ,[PDSCWQTY]
      ,[PDSCWSETTLED]
      ,[PICKINGROUTEID]
      ,[PROJADJUSTREFID]
      ,[PROJCATEGORYID]
      ,[PROJID]
      ,[QTY]
      ,[QTYSETTLED]
      ,[QTYSETTLEDSECCUR_RU]
      ,[RECID]
      ,[RECVERSION]
      ,[RETURNINVENTTRANSORIGIN]
      ,[REVENUEAMOUNTPHYSICAL]
      ,[SHIPPINGDATECONFIRMED]
      ,[SHIPPINGDATEREQUESTED]
      ,[STATUSISSUE]
      ,[STATUSRECEIPT]
      ,[STORNOPHYSICAL_RU]
      ,[STORNO_RU]
      ,[TAXAMOUNTPHYSICAL]
      ,[TIMEEXPECTED]
      ,[TRANSCHILDREFID]
      ,[TRANSCHILDTYPE]
      ,[VALUEOPEN]
      ,[VALUEOPENSECCUR_RU]
      ,[VOUCHER]
      ,[VOUCHERPHYSICAL]
      ,[dateLoaded]
      ,[neu_pk_col]
    FROM {0}
  ) t""".format(databaseTableName)
replace_df = spark.read.jdbc(url=sqlDwUrlSmall, table=query, properties=connectionProperties)

# COMMAND ----------

replace_df.repartition(256) \
  .write \
  .mode("overwrite") \
  .format("delta") \
  .save(enrichedPath)


# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select count(*) CurrentStateCount from brtl.INVENTTRANS

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE {0}
USING delta
LOCATION '{1}'
""".format(databaseTableName, enrichedPath)
spark.sql(sql)

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select count(*) EnrichedCount from brtl.FCTInventoryTrans