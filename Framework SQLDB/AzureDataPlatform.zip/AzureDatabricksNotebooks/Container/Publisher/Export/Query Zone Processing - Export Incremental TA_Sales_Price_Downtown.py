# MAGIC %md
# MAGIC # Query Zone Processing - Export Incremental TA_Sales_Price_Downtown
# MAGIC ###### Author: Ranga Bondada 02/19/2020
# MAGIC 
# MAGIC Data Lake pattern for master data or small tables that can be overwritten every time.  Takes a file from the raw data path and overwrites the table in the Query zone.      
# MAGIC 
# MAGIC #### Usage
# MAGIC Supply the parameters above and run the notebook.  
# MAGIC 
# MAGIC #### Prerequisites
# MAGIC 1. Data must exist in the Data Lake /query zone (current State).   
# MAGIC 
# MAGIC #### Details

# COMMAND ----------

# MAGIC %md
# MAGIC #### Initialize Framework

# COMMAND ----------

dbutils.widgets.text(name="containerName", defaultValue="brtl", label="Container Name")
containerName = dbutils.widgets.get("containerName")

# COMMAND ----------

# MAGIC %run ../Framework/Secrets_Databricks_Container

# COMMAND ----------

# MAGIC %run ../Framework/Neudesic_Framework_Functions

# COMMAND ----------

dbutils.widgets.text(name="parentPipeLineExecutionLogKey", defaultValue="-1", label="Parent Pipeline Execution Log Key")
dbutils.widgets.text(name="numPartitions", defaultValue="8", label="Number of Partitions")
dbutils.widgets.text(name="schemaName", defaultValue="brtl", label="Schema Name")
dbutils.widgets.text(name="tableName", defaultValue="TA_Sales_Price_Downtown", label="Table Name")
dbutils.widgets.text(name="vacuumRetentionHours", defaultValue="", label="Vacuum Retention Hours")
dbutils.widgets.text(name="timestampColumns", defaultValue="", label="Timestamp Columns")

timestampColumns = dbutils.widgets.get("timestampColumns")

parentPipeLineExecutionLogKey = dbutils.widgets.get("parentPipeLineExecutionLogKey")
fullPathPrefix = "abfss://" + containerName + "@" + adlsGen2StorageAccountName + ".dfs.core.windows.net" 

numPartitions = int(dbutils.widgets.get("numPartitions"))

schemaName = dbutils.widgets.get("schemaName")
tableName = dbutils.widgets.get("tableName")
fullyQualifiedTableName = schemaName + "." + tableName
currentStatePath = fullPathPrefix + "/Query/CurrentState/" + schemaName + "/" + tableName
enrichedPath = fullPathPrefix + "/Query/Enriched/Exports/" + tableName
trackingEnrichedPath = fullPathPrefix + "/Query/Enriched/Exports/Tracking/" + tableName + "Tracking"

databaseTableName = containerName + "." + tableName
vacuumRetentionHours = dbutils.widgets.get("vacuumRetentionHours")

# COMMAND ----------

notebookName = "Query Zone Processing - Export Incremental TA_Sales_Price_Downtown"
notebookExecutionLogKey = log_event_notebook_start(notebookName,parentPipeLineExecutionLogKey)
print("Notebook Execution Log Key: {0}".format(notebookExecutionLogKey))

# COMMAND ----------

print("Schema Name: {0}".format(schemaName))
print("Table Name: {0}".format(tableName))
print("ProcessingMode: {0}".format(timestampColumns))
print("Fully Qualified Table Name: {0}".format(fullyQualifiedTableName))
print("Number of Partitions: {0}".format(numPartitions))
print("Current State Path: {0}".format(currentStatePath))
print("Enriched State Path: {0}".format(enrichedPath))

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Starting
# MAGIC val notebookPath = dbutils.notebook.getContext.notebookPath.get
# MAGIC val logMessage = "Starting"
# MAGIC val notebookContext = dbutils.notebook.getContext().toJson
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

if timestampColumns == 'Full':
  dbutils.fs.rm(trackingEnrichedPath,True)

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.PRICEDISCTABLE")
spark.sql(sql)



# COMMAND ----------

sql = """
CREATE TABLE {0}
USING delta
LOCATION '{1}'
""".format("brtl.PRICEDISCTABLE",fullPathPrefix + "/Query/CurrentState/PRICEDISCTABLE")
spark.sql(sql)



# COMMAND ----------

IsFirstTime=file_exists(trackingEnrichedPath)

# COMMAND ----------

try:
  #read enrichedPath into a dataframe if it exists, otherwise create it
  dst_df = spark.read \
    .format("delta") \
    .load(trackingEnrichedPath) \
    .dropDuplicates()
except Exception as e:
  IsFirstTime = True
  

# COMMAND ----------

IsFirstTime

# COMMAND ----------

if not IsFirstTime:
  sql = """
  DROP TABLE IF EXISTS {0}
  """.format("brtl.TA_Sales_Price_DowntownTracking")
  spark.sql(sql)

# COMMAND ----------

if not IsFirstTime:
  sql = """
  CREATE TABLE {0}
  USING delta
  LOCATION '{1}'
  """.format("brtl.TA_Sales_Price_DowntownTracking",trackingEnrichedPath)
  spark.sql(sql)

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS brtl.NewTA_Sales_Price_Downtown

# COMMAND ----------

sql = """
CREATE TABLE brtl.NewTA_Sales_Price_Downtown
USING DELTA
AS
SELECT 
    --ITEMRELATION AS ITEMID
	--, AMOUNT AS TAAmount
	--, CURRENCY AS TACurrency
	--, FROMDATE AS TAFromDate
	--, TODATE AS TAToDate
	--, UNITID AS TAUnitId
	--, PRICEUNIT AS TAPriceUnit
	--, ACCOUNTRELATION AS Account
    RIGHT(CONCAT("000000000",ITEMRELATION),9) AS ItemNumber		
    , DOUBLE(AMOUNT) AS TAAmount
    , DATE_FORMAT(FROMDATE,'yyyy-MM-dd') AS TAFromDate
    , HASH(
            AMOUNT
            , FROMDATE
            ) AS HashValue
  FROM brtl.PRICEDISCTABLE 
WHERE 1=1
AND (ACCOUNTCODE = 1 OR ACCOUNTRELATION LIKE 'Downtown')
AND TODATE >= CURRENT_DATE()
AND ITEMRELATION NOT LIKE '%,%'
""".format()
spark.sql(sql)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM brtl.NewTA_Sales_Price_Downtown

# COMMAND ----------

if not IsFirstTime:
  sql = """
  MERGE INTO brtl.NewTA_Sales_Price_Downtown AS NTT
  USING  brtl.TA_Sales_Price_DowntownTracking as TT ON NTT.ItemNumber = TT.ItemNumber AND NTT.HashValue = TT.HashValue
  WHEN MATCHED THEN DELETE"""
  spark.sql(sql)
     
 

# COMMAND ----------

sql = """
SELECT 
    --ITEMID
	--,  TAAmount
	--,  TACurrency
	--,  TAFromDate
	--,  TAToDate
	--,  TAUnitId
	--,  TAPriceUnit
	--,  Account
    --, HashValue
    ItemNumber		
    , TAAmount
    , TAFromDate
FROM brtl.NewTA_Sales_Price_Downtown
"""
df = spark.sql(sql)

# COMMAND ----------

display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Write Data to Query Zone (Enriched)

# COMMAND ----------

try:
  df \
    .repartition(numPartitions) \
    .write \
    .mode("overwrite") \
	.option("overwriteSchema","true") \
    .format("delta") \
    .save(enrichedPath)
except Exception as e:
  sourceName = "Query Zone Processing - Overwrite: Write to Query Zone"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

sql = """
SELECT 
      --ITEMID
      --,  TAAmount
      --,  TACurrency
      --,  TAFromDate
      --,  TAToDate
      --,  TAUnitId
      --,  TAPriceUnit
      --,  Account
      --, HashValue
      --,CURRENT_TIMESTAMP() SENT_DATE 
     ItemNumber		
     , HashValue
     , CURRENT_TIMESTAMP() SENT_DATE
  FROM brtl.NewTA_Sales_Price_Downtown
"""
tracking_df = spark.sql(sql)

# COMMAND ----------

display(tracking_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Write Tracking Data to Query Zone (Enriched)

# COMMAND ----------

try:
  tracking_df \
    .repartition(numPartitions) \
    .write \
    .mode("append") \
	.option("overwriteSchema","true") \
    .format("delta") \
    .save(trackingEnrichedPath)
except Exception as e:
  sourceName = "Query Zone Processing - Overwrite: Write to Query Zone"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

trackingEnrichedPath

# COMMAND ----------

# MAGIC %md
# MAGIC #### Create Spark Table

# COMMAND ----------

display(spark.sql("CREATE DATABASE IF NOT EXISTS " + containerName))

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

  sql = """
  CREATE TABLE IF NOT EXISTS {0}
  USING delta
  LOCATION '{1}'
  """.format(databaseTableName, enrichedPath)
  spark.sql(sql)

# COMMAND ----------

sql="""
select count(*) from {0}
""".format(databaseTableName)
display(spark.sql(sql))

# COMMAND ----------

if vacuumRetentionHours != '':
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", False)
  spark.sql("VACUUM " + databaseTableName + " RETAIN " + vacuumRetentionHours + " HOURS")
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", True)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Log Completion

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Completed
# MAGIC val logMessage = "Completed"
# MAGIC val notebookContext = ""
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

log_event_notebook_end(notebookExecutionLogKey=notebookExecutionLogKey, notebookStatus="SUCCEEDED", notebookName=notebookName, notebookExecutionGroupName="")
dbutils.notebook.exit("Succeeded")