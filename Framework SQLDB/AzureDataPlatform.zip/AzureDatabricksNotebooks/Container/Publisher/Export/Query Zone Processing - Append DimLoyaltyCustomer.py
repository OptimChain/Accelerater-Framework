# Databricks notebook source
# MAGIC 
# MAGIC %md
# MAGIC # Query Zone Processing - Append DimLoyaltyCustomer
# MAGIC ###### Author: Ranga Bondada 12/02/2020
# MAGIC 
# MAGIC Data Lake pattern for tables that are staged and merged into the final enriched version.  Takes a file from the raw data path and overwrites the table in the Query zone.      
# MAGIC 
# MAGIC #### Usage
# MAGIC Supply the parameters above and run the notebook.  
# MAGIC 
# MAGIC #### Prerequisites
# MAGIC 1. Data must exist in the Data Lake /query zone (current State).   
# MAGIC 
# MAGIC #### Details

# COMMAND ----------

# MAGIC %md
# MAGIC #### Initialize Framework

# COMMAND ----------

dbutils.widgets.text(name="containerName", defaultValue="brtl", label="Container Name")
containerName = dbutils.widgets.get("containerName")

# COMMAND ----------

# MAGIC %run ../Framework/Secrets_Databricks_Container

# COMMAND ----------

# MAGIC %run ../Framework/Neudesic_Framework_Functions

# COMMAND ----------

spark.conf.set("spark.databricks.delta.merge.joinBasedMerge.enabled", True)

# COMMAND ----------

dbutils.widgets.text(name="parentPipeLineExecutionLogKey", defaultValue="-1", label="Parent Pipeline Execution Log Key")
dbutils.widgets.text(name="numPartitions", defaultValue="32", label="Number of Partitions")
dbutils.widgets.text(name="schemaName", defaultValue="brtl", label="Schema Name")
dbutils.widgets.text(name="tableName", defaultValue="AssistedOrders", label="Table Name")
dbutils.widgets.text(name="vacuumRetentionHours", defaultValue="", label="Vacuum Retention Hours")
dbutils.widgets.text(name="primaryKeyColumns", defaultValue="", label="Primary Key Columns")
dbutils.widgets.text(name="timestampColumns", defaultValue="", label="Timestamp Columns")

parentPipeLineExecutionLogKey = dbutils.widgets.get("parentPipeLineExecutionLogKey")
fullPathPrefix = "abfss://" + containerName + "@" + adlsGen2StorageAccountName + ".dfs.core.windows.net" 

numPartitions = int(dbutils.widgets.get("numPartitions"))


schemaName = dbutils.widgets.get("schemaName")
tableName = dbutils.widgets.get("tableName")
destinationTableName = tableName

fullyQualifiedTableName = schemaName + "." + destinationTableName
primaryKeyColumns = dbutils.widgets.get("primaryKeyColumns")
timestampColumns = dbutils.widgets.get("timestampColumns")

enrichedPath = fullPathPrefix + "/Query/Enriched/" + destinationTableName
databaseTableName = containerName + "." + destinationTableName
vacuumRetentionHours = dbutils.widgets.get("vacuumRetentionHours")

currentStatePath = fullPathPrefix + "/Query/CurrentState/" + tableName

# COMMAND ----------

notebookName = "Query Zone Processing - Append DimLoyaltyCustomer"
notebookExecutionLogKey = log_event_notebook_start(notebookName,parentPipeLineExecutionLogKey)
print("Notebook Execution Log Key: {0}".format(notebookExecutionLogKey))

# COMMAND ----------

print("Schema Name: {0}".format(schemaName))
# print("Source Table Name: {0}".format(stageTableName))
print("Table Name: {0}".format(tableName))
print("Fully Qualified Table Name: {0}".format(fullyQualifiedTableName))
print("Number of Partitions: {0}".format(numPartitions))
print("Current State Path: {0}".format(currentStatePath))
# print("Current State Stage Path: {0}".format(currentStateStagePath))
print("Enriched State Path: {0}".format(enrichedPath))

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Starting
# MAGIC val notebookPath = dbutils.notebook.getContext.notebookPath.get
# MAGIC val logMessage = "Starting"
# MAGIC val notebookContext = dbutils.notebook.getContext().toJson
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read Existing Data from Query Zone (CurrentState}

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.RETAILLOYALTYCARD")
spark.sql(sql)

sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.PARTITIONS")
spark.sql(sql)

sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.DIRPARTYTABLE")
spark.sql(sql)

sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.DIRPARTYPOSTALADDRESSVIEW")
spark.sql(sql)

sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.RetailLoyaltyCardRewardPointTrans")
spark.sql(sql)


sql = """
DROP TABLE IF EXISTS {0}
""".format(tableName)
spark.sql(sql)


# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl.RETAILLOYALTYCARD", fullPathPrefix + "/Query/CurrentState/" + "RETAILLOYALTYCARD")
spark.sql(sql)

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl.PARTITIONS", fullPathPrefix + "/Query/CurrentState/" + "PARTITIONS")
spark.sql(sql)

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl.DIRPARTYTABLE", fullPathPrefix + "/Query/CurrentState/" + "DIRPARTYTABLE")
spark.sql(sql)
   
sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl.DIRPARTYPOSTALADDRESSVIEW", fullPathPrefix + "/Query/CurrentState/" + "DIRPARTYPOSTALADDRESSVIEW")
spark.sql(sql)

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl.RetailLoyaltyCardRewardPointTrans", fullPathPrefix + "/Query/CurrentState/" + "RetailLoyaltyCardRewardPointTrans")
spark.sql(sql)

#sql = """
#CREATE TABLE IF NOT EXISTS {0}
#USING delta
#LOCATION '{1}'
#""".format(tableName, currentStatePath)
#spark.sql(sql)




# COMMAND ----------

# MAGIC %md
# MAGIC #### Read STG Data from Query Zone (CurrentState}

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS brtl.Accounts

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE brtl.Accounts
# MAGIC AS
# MAGIC 	SELECT la.RECID as RecordId,
# MAGIC 		la.CARDNUMBER as LoyaltyCustomerCode
# MAGIC 		,STRING(ltrim(rtrim(left(dpt.NAME, charindex(' ', dpt.NAME))))) as FirstName
# MAGIC 		,STRING(ltrim(rtrim(right(dpt.NAME, len(dpt.NAME) - charindex(' ', dpt.NAME)))) ) as LastName
# MAGIC 		,dpt.NAME as FullName
# MAGIC 		,addr.CITY as City
# MAGIC 		,addr.STATE as State
# MAGIC 		,addr.ZIPCODE as ZIPCode
# MAGIC 		,addr.COUNTRYREGIONID as Country
# MAGIC 		,STRING(
# MAGIC 			case la.CARDTENDERTYPE 
# MAGIC 			when 0 then N'As card tender' 
# MAGIC 			when 1 then N'As contact tender' 
# MAGIC 			when 2 then N'No tender' 
# MAGIC 			when 3 then N'Blocked'
# MAGIC 			end 
# MAGIC 			) as CardType
# MAGIC 		,DATEDIFF(month, 
# MAGIC 			(SELECT max(lcpt.ENTRYDATE) 
# MAGIC               FROM  brtl.RetailLoyaltyCardRewardPointTrans lcpt 
# MAGIC               WHERE lcpt.PARTITION = la.PARTITION and lcpt.CARDNUMBER = la.CARDNUMBER),
# MAGIC 			CURRENT_TIMESTAMP()
# MAGIC 			) as MonthsSinceLastTransaction
# MAGIC 		,DATEDIFF(month, IFNULL(dpt.CREATEDDATETIME,'1900-01-01'), CURRENT_TIMESTAMP()) as LoyaltyMonths
# MAGIC 	FROM  dbo.RETAILLOYALTYCARD la
# MAGIC 	INNER JOIN  dbo.PARTITIONS p on p.RECID = la.PARTITION and p.PARTITIONKEY = N'initial'
# MAGIC 	LEFT OUTER JOIN  dbo.DIRPARTYTABLE dpt on dpt.RECID = la.PARTY
# MAGIC 	LEFT OUTER JOIN  dbo.DIRPARTYPOSTALADDRESSVIEW addr on (addr.PARTY = dpt.RECID ) and (addr.ISPRIMARY = 1 ) and  (getutcdate() between addr.VALIDFROM and addr.VALIDTO )

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP VIEW IF EXISTS brtl.DimLoyaltyCustomerView

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE VIEW brtl.DimLoyaltyCustomerView
# MAGIC AS
# MAGIC SELECT 
# MAGIC 	LoyaltyCustomerCode
# MAGIC 	,FirstName
# MAGIC 	,LastName
# MAGIC 	,STRING(FullName) as FullName
# MAGIC 	,City
# MAGIC 	,State
# MAGIC 	,ZIPCode
# MAGIC 	,Country
# MAGIC 	,CardType
# MAGIC 	,STRING(
# MAGIC 		case 
# MAGIC 		when MonthsSinceLastTransaction >= 24 then N'24+ months'
# MAGIC 		when MonthsSinceLastTransaction >= 12 then N'12-23 months'
# MAGIC 		when MonthsSinceLastTransaction >= 6 then N'6-11 months'
# MAGIC 		when MonthsSinceLastTransaction >= 3 then N'3-5 months'
# MAGIC 		when MonthsSinceLastTransaction >= 1 then N'1-2 months'
# MAGIC 		when MonthsSinceLastTransaction >= 0 then N'<1 months'
# MAGIC 		else null 
# MAGIC 		end 
# MAGIC 	)
# MAGIC 	as MonthsSinceLastTransaction
# MAGIC 	,case 
# MAGIC 	when MonthsSinceLastTransaction >= 24 then 24
# MAGIC 	when MonthsSinceLastTransaction >= 12 then 12
# MAGIC 	when MonthsSinceLastTransaction >= 6 then 6
# MAGIC 	when MonthsSinceLastTransaction >= 3 then 3
# MAGIC 	when MonthsSinceLastTransaction >= 1 then 1
# MAGIC 	when MonthsSinceLastTransaction >= 0 then 0
# MAGIC 	else null end as MonthsSinceLastTransaction Order
# MAGIC 	,CAST(
# MAGIC 		case 
# MAGIC 		when LoyaltyMonths >= 24 then N'24+ months'
# MAGIC 		when LoyaltyMonths >= 12 then N'12-23 months'
# MAGIC 		when LoyaltyMonths >= 6 then N'6-11 months'
# MAGIC 		when LoyaltyMonths >= 3 then N'3-5 months'
# MAGIC 		when LoyaltyMonths >= 1 then N'1-2 months'
# MAGIC 		when LoyaltyMonths >= 0 then N'<1 months'
# MAGIC 		else null 
# MAGIC 		end 
# MAGIC 	as nvarchar(20))
# MAGIC 	as LoyaltyMonths
# MAGIC 	,case 
# MAGIC 	when LoyaltyMonths >= 24 then 24
# MAGIC 	when LoyaltyMonths >= 12 then 12
# MAGIC 	when LoyaltyMonths >= 6 then 6
# MAGIC 	when LoyaltyMonths >= 3 then 3
# MAGIC 	when LoyaltyMonths >= 1 then 1
# MAGIC 	when LoyaltyMonths >= 0 then 0
# MAGIC 	else null end as LoyaltyMonthsOrder
# MAGIC 	
# MAGIC FROM brtl.Accounts

# COMMAND ----------

sql="""
SELECT *
 FROM brtl.DimLoyaltyCustomerView
""".format()
stg_df=(spark.sql(sql))

# COMMAND ----------

display(stg_df)

# COMMAND ----------

try:
  #read enrichedPath into a dataframe if it exists, otherwise create it
  dst_df = spark.read \
    .format("delta") \
    .load(enrichedPath) \
    .dropDuplicates()
except Exception as e:
   (stg_df \
    .write \
    .mode("overwrite") \
    .format("delta") \
    .save(enrichedPath)
    )

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE {0}
USING delta
LOCATION '{1}'
""".format(databaseTableName, enrichedPath)
spark.sql(sql)

# COMMAND ----------

spark.conf.set("spark.sql.crossJoin.enabled", "true")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Append Data in Query Zone (Enriched)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from brtl.DimLoyaltyCustomerView

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC MERGE INTO brtl.DimLoyaltyCustomer AS dim
# MAGIC USING brtl.DimLoyaltyCustomerView AS stg
# MAGIC ON dim.LoyaltyCustomerCode = stg.LoyaltyCustomerCode
# MAGIC 
# MAGIC WHEN MATCHED THEN
# MAGIC   DELETE

# COMMAND ----------

try:
  queryTableExists = (spark.table(databaseTableName) is not None)
except:
  queryTableExists = False

# COMMAND ----------

queryTableExists

# COMMAND ----------

try:
  if queryTableExists:
    (stg_df.repartition(numPartitions) \
      .write \
      .mode("append") \
      .option("mergeSchema", True) \
      .format("delta") \
      .save(enrichedPath)
    )
  else:
    (stg_df.repartition(numPartitions) \
      .write \
      .mode("overwrite") \
      .format("delta") \
      .save(enrichedPath)
    )
    sql = """
    CREATE TABLE {0}
    USING delta
    LOCATION '{1}'
    """.format(destinationTableName, enrichedPath)
    spark.sql(sql)
except Exception as e:
  sourceName = "Query Zone Processing - Append Databricks Delta: Write to Query Zone"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Append Data in to Synapse DW from Current State

# COMMAND ----------

sanctionedZoneNotebookPath = "../Framework/Sanctioned Zone Processing - Load Synapse DW Overwrite"
stageSchemaName = "stage"
stageTableName = "DimLoyaltyCustomerView"

run_with_retry(sanctionedZoneNotebookPath, 1200, {"parentPipeLineExecutionLogKey": notebookExecutionLogKey, "containerName": containerName, "schemaName": stageSchemaName, "tableName": stageTableName, "numPartitions": numPartitions})

# COMMAND ----------

execsp = "DELETE A \
          FROM brtl.DimLoyaltyCustomer AS A \
          INNER JOIN stage.DimLoyaltyCustomerView AS stg \
          ON A.LoyaltyCustomerCode = stg.LoyaltyCustomerCode"
try:
  execute_sqldw_stored_procedure_no_results(execsp)
except:
  sourceName = "Destination Table does not exist"

# COMMAND ----------

blob_storage_account_name = adlsGen2StorageAccountName
blob_storage_container_name = "temp"

tempDir = "abfss://{}@{}.dfs.core.windows.net/".format(blob_storage_container_name, blob_storage_account_name) + dbutils.widgets.get("tableName")

# COMMAND ----------

sqlDwUrlSmall, connectionProperties = build_sqldw_jdbc_url_and_connectionProperties(sqldwservername, sqldwdatabasename, sqldwusername, sqldwpassword)

# COMMAND ----------

try:
  stg_df \
    .write \
    .format("com.databricks.spark.sqldw") \
    .mode("append") \
    .option("url", sqlDwUrlSmall) \
    .option("dbtable", fullyQualifiedTableName) \
    .option("useAzureMSI","True") \
    .option("maxStrLength",2048) \
    .option("tempdir", tempDir) \
    .save()
except Exception as e:
  sourceName = "Sanctioned Zone Processing - Load Azure SQL DW: Load Synapse SQL Data Warehouse"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Drop Temporary Table and Views

# COMMAND ----------

dbutils.fs.rm(tempDir,True)

# COMMAND ----------

sql = """
DROP VIEW IF EXISTS {0}
""".format("brtl.DimLoyaltyCustomerView")
spark.sql(sql)

# COMMAND ----------

execsp = "IF OBJECT_ID('stage.DimLoyaltyCustomerView') IS NOT NULL DROP TABLE stage.DimLoyaltyCustomerView"
execute_sqldw_stored_procedure_no_results(execsp)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Optimize and Vacuum Table

# COMMAND ----------

sql="""OPTIMIZE {0}""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

if vacuumRetentionHours != '':
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", False)
  spark.sql("VACUUM " + databaseTableName + " RETAIN " + vacuumRetentionHours + " HOURS")
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", True)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Log Completion

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Completed
# MAGIC val logMessage = "Completed"
# MAGIC val notebookContext = ""
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

log_event_notebook_end(notebookExecutionLogKey=notebookExecutionLogKey, notebookStatus="SUCCEEDED", notebookName=notebookName, notebookExecutionGroupName="")
dbutils.notebook.exit("Succeeded")