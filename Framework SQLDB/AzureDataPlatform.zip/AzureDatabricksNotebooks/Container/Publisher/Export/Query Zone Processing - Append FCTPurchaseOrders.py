# Databricks notebook source
# MAGIC  
# MAGIC  
# MAGIC  
# MAGIC %md
# MAGIC # Query Zone Processing - Append FCTPurchase
# MAGIC ###### Author: Shubham S 22/12/2020
# MAGIC 
# MAGIC Data Lake pattern for tables that are staged and merged into the final enriched version.  Takes a file from the raw data path and overwrites the table in the Query zone.      
# MAGIC 
# MAGIC #### Usage
# MAGIC Supply the parameters above and run the notebook.  
# MAGIC 
# MAGIC #### Prerequisites
# MAGIC 1. Data must exist in the Data Lake /query zone (current State).   
# MAGIC 
# MAGIC #### Details

# COMMAND ----------

# MAGIC %md
# MAGIC #### Initialize Framework

# COMMAND ----------

# MAGIC %run ../Framework/Secrets_Databricks_Container

# COMMAND ----------

# MAGIC %run ../Framework/Neudesic_Framework_Functions

# COMMAND ----------

spark.conf.set("spark.databricks.delta.merge.joinBasedMerge.enabled", True)

# COMMAND ----------

dbutils.widgets.text(name="containerName", defaultValue="brtl", label="Container Name")
dbutils.widgets.text(name="parentPipeLineExecutionLogKey", defaultValue="-1", label="Parent Pipeline Execution Log Key")

# filePath is to pick up the schema of an actual file in the case of subfolders

dbutils.widgets.text(name="numPartitions", defaultValue="32", label="Number of Partitions")
dbutils.widgets.text(name="schemaName", defaultValue="brtl", label="Schema Name")
dbutils.widgets.text(name="tableName", defaultValue="FCTPurchaseOrders", label="Table Name")
dbutils.widgets.text(name="vacuumRetentionHours", defaultValue="", label="Vacuum Retention Hours")
dbutils.widgets.text(name="primaryKeyColumns", defaultValue="", label="Primary Key Columns")
dbutils.widgets.text(name="timestampColumns", defaultValue="", label="Timestamp Columns")

parentPipeLineExecutionLogKey = dbutils.widgets.get("parentPipeLineExecutionLogKey")
containerName = dbutils.widgets.get("containerName")
fullPathPrefix = "abfss://" + containerName + "@" + adlsGen2StorageAccountName + ".dfs.core.windows.net" 

numPartitions = int(dbutils.widgets.get("numPartitions"))

schemaName = dbutils.widgets.get("schemaName")
tableName = 'FCTPurchaseOrders'
fullyQualifiedTableName = schemaName + "." + tableName

primaryKeyColumns = dbutils.widgets.get("primaryKeyColumns")
timestampColumns = dbutils.widgets.get("timestampColumns")

currentStatePath = fullPathPrefix + "/Query/CurrentState/" + tableName
enrichedDestinationPath = fullPathPrefix + "/Query/Enriched/" + tableName

databaseTableName = containerName + "." + tableName
vacuumRetentionHours = dbutils.widgets.get("vacuumRetentionHours")

# COMMAND ----------

notebookName = "Query Zone Processing - Append FCTPurchaseOrders"
notebookExecutionLogKey = log_event_notebook_start(notebookName,parentPipeLineExecutionLogKey)
print("Notebook Execution Log Key: {0}".format(notebookExecutionLogKey))

# COMMAND ----------

print("Schema Name: {0}".format(schemaName))
print("Table Name: {0}".format(tableName))
print("Fully Qualified Table Name: {0}".format(fullyQualifiedTableName))
print("Number of Partitions: {0}".format(numPartitions))
print("Current State Path: {0}".format(currentStatePath))
print("Enriched State Path: {0}".format(enrichedDestinationPath))

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Starting
# MAGIC val notebookPath = dbutils.notebook.getContext.notebookPath.get
# MAGIC val logMessage = "Starting"
# MAGIC val notebookContext = dbutils.notebook.getContext().toJson
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read STG Data from Query Zone (CurrentState}

# COMMAND ----------

stageTableName1 = "PURCHLINE"

databaseStageTableName1 = containerName + "." + stageTableName1

currentStateStagePath1 = fullPathPrefix + "/Query/CurrentState/"  + stageTableName1

# COMMAND ----------

stageTableName2 = "VENDPACKINGSLIPJOUR"

databaseStageTableName2 = containerName + "." + stageTableName2

currentStateStagePath2 = fullPathPrefix + "/Query/CurrentState/"  + stageTableName2

# COMMAND ----------

stageTableName3 = "PARTITIONS"

databaseStageTableName3 = containerName + "." + stageTableName3

currentStateStagePath3 = fullPathPrefix + "/Query/CurrentState/"  + stageTableName3

# COMMAND ----------

stageTableName4 = "PURCHTABLE"

databaseStageTableName4 = containerName + "." + stageTableName4

currentStateStagePath4 = fullPathPrefix + "/Query/CurrentState/"  + stageTableName4

# COMMAND ----------

stageTableName5 = "INVENTDIM"

databaseStageTableName5 = containerName + "." + stageTableName5

currentStateStagePath5 = fullPathPrefix + "/Query/CurrentState/"  + stageTableName5

# COMMAND ----------

stageTableName6 = "INVENTTABLEMODULE"

databaseStageTableName6 = containerName + "." + stageTableName6

currentStateStagePath6 = fullPathPrefix + "/Query/CurrentState/"  + stageTableName6

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format(stageTableName1)
spark.sql(sql)

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format(stageTableName2)
spark.sql(sql)

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format(stageTableName3)
spark.sql(sql)

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format(stageTableName4)
spark.sql(sql)

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format(stageTableName5)
spark.sql(sql)

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format(stageTableName6)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE DATABASE IF NOT EXISTS {0}
""".format(containerName)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format(databaseStageTableName1, currentStateStagePath1)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format(databaseStageTableName2, currentStateStagePath2)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format(databaseStageTableName3, currentStateStagePath3)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format(databaseStageTableName4, currentStateStagePath4)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format(databaseStageTableName5, currentStateStagePath5)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format(databaseStageTableName6, currentStateStagePath6)
spark.sql(sql)

# COMMAND ----------

sql = """
SELECT *
FROM {0}
""".format(databaseStageTableName1)
spark.sql(sql)

# COMMAND ----------

sql = """
SELECT *
FROM {0}
""".format(databaseStageTableName2)
spark.sql(sql)

# COMMAND ----------

sql = """
SELECT *
FROM {0}
""".format(databaseStageTableName3)
spark.sql(sql)

# COMMAND ----------

sql = """
SELECT *
FROM {0}
""".format(databaseStageTableName4)
spark.sql(sql)

# COMMAND ----------

sql = """
SELECT *
FROM {0}
""".format(databaseStageTableName5)
spark.sql(sql)

# COMMAND ----------

sql = """
SELECT *
FROM {0}
""".format(databaseStageTableName6)
spark.sql(sql)

# COMMAND ----------

stgViewName1 =  "cteTemp_rawData"

sql="""
CREATE OR REPLACE VIEW {0} AS
SELECT *
,'Query Zone Processing - Append Purchase' AS Created_By
,cast(current_date() AS string) AS Last_Created
FROM {1}
""".format(stgViewName1,databaseStageTableName1)
display(spark.sql(sql))

# COMMAND ----------

stgViewName2 =  "tradeLineDivType"

sql="""
CREATE OR REPLACE VIEW {0} AS
SELECT 
CAST(0 AS int) AS Value, 
CAST('' AS string) AS Label
UNION ALL
SELECT 
CAST(1 AS int) AS Value, 
CAST('Direct delivery' AS string) AS Label
""".format(stgViewName2)
display(spark.sql(sql))

# COMMAND ----------

stgViewName3 =  "purchStatus"

sql="""
CREATE OR REPLACE VIEW {0} AS
SELECT 
CAST(0 AS int) AS Value, 
CAST('' AS string) AS Label
UNION ALL
SELECT 
CAST(1 AS int) AS Value, 
CAST('Open order' AS string) AS Label
UNION ALL
SELECT 
CAST(2 AS int) AS Value, 
CAST('Received' AS string) AS Label
UNION ALL
SELECT 
CAST(3 AS int) AS Value, 
CAST('Invoiced' AS string) AS Label
UNION ALL
SELECT 
CAST(4 AS int) AS Value, 
CAST('Cancelled' AS string) AS Label
""".format(stgViewName3)
display(spark.sql(sql))

# COMMAND ----------

stgViewName4 =  "returnStatusLine"

sql="""
CREATE OR REPLACE VIEW {0} AS
SELECT 
CAST(0 AS int) AS Value, 
CAST('None' AS string) AS Label
UNION ALL
SELECT 
CAST(1 AS int) AS Value, 
CAST('Expected' AS string) AS Label
UNION ALL
SELECT 
CAST(2 as int) AS Value, 
CAST('Registered' AS string) AS Label
UNION ALL
SELECT 
CAST(3 AS int) AS Value, 
CAST('Quarantine' AS string) AS Label
UNION ALL
SELECT 
CAST(4 AS int) AS Value, 
CAST('Received' AS string) AS Label
UNION ALL
SELECT 
CAST(5 AS int) AS Value, 
CAST('Invoiced' AS string) AS Label
UNION ALL
SELECT 
CAST(6 AS int) AS Value, 
CAST('Cancelled' AS string) AS Label
""".format(stgViewName4)
display(spark.sql(sql))

# COMMAND ----------

stgViewName5 =  "lastDeliveryDate"

sql="""
CREATE OR REPLACE VIEW {0} AS
SELECT
	 DATAAREAID
	,PARTITION
	,PURCHID
	,MAX(DELIVERYDATE) AS LASTDELIVERYDATE
FROM {1}
GROUP BY
	 DATAAREAID
	,PARTITION
	,PURCHID
""".format(stgViewName5,databaseStageTableName2)
display(spark.sql(sql))

# COMMAND ----------

stgViewName =  "brtl.Incremental_PurchaseOrders"

sql="""
CREATE OR REPLACE VIEW {9} AS
SELECT 
	 PL.RECID AS Record_ID
	,PL.DATAAREAID AS Company_Code
	,PH.INVOICEACCOUNT AS Invoice_Account
	,PH.ORDERACCOUNT AS Order_Account
	,current_date() AS PO_Date
	,PL.PURCHID AS PO_Number
	,PL.LINEAMOUNT AS PO_Amount
	,CASE 
		WHEN PL.CONFIRMEDDLV = '1900-01-01' THEN PL.DELIVERYDATE 
		ELSE PL.CONFIRMEDDLV END AS Delivery_Date
	,LDD.LASTDELIVERYDATE AS Last_Delivery_Date
	,PL.INVENTTRANSID AS Inventory_Transaction_ID
	,CAST(PL.LINEAMOUNT / NULLIF(PL.PURCHQTY,0.0) AS NUMERIC(32,6)) AS PO_Price
	,PL.PURCHUNIT AS PO_Unit
	,PL.PURCHQTY AS PO_Quantity 
	,PL.REMAINPURCHPHYSICAL AS PO_Committed_Quantity
	,CAST(PL.REMAINPURCHPHYSICAL * PL.LINEAMOUNT / NULLIF(PL.PURCHQTY,0.0) AS NUMERIC(32,6)) AS PO_Committed_Amount
	,PL.REMAINPURCHFINANCIAL AS PO_Accrual_Quantity
	,CAST(PL.REMAINPURCHFINANCIAL * PL.LINEAMOUNT / NULLIF(PL.PURCHQTY,0.0) AS NUMERIC(32,6)) AS PO_Accrual_Amount 
	,PL.CURRENCYCODE AS Currency_Code
	,PL.DEFAULTDIMENSION AS Default_Dimension_ID
    ,TLDT.Label AS Delivery_Type
	,CAST(CASE PL.ISINVOICEMATCHED 
				WHEN 0 THEN 'Not matched' 
				WHEN 1 THEN 'Matched' 
		END AS string) AS Invoice_Matched
	,PS.Label AS Purchase_Status
	,PL.QTYORDERED AS Inventory_Quantity
	,ITM.UNITID AS Inventory_Unit
	,RSL.Label AS Return_Status
	,PL.SHIPPINGDATEREQUESTED AS Shipping_Date_Requested
	,PL.SHIPPINGDATECONFIRMED AS Shipping_Date_Confirmed
	,CASE 
		WHEN PL.SHIPPINGDATECONFIRMED = '1900-01-01' THEN PL.SHIPPINGDATEREQUESTED 
		ELSE PL.SHIPPINGDATECONFIRMED END Shipping_Date
	,PL.SERVICEDATE AS Service_Date
	,CAST(CASE PL.STOCKEDPRODUCT  
			WHEN 0 THEN 'Non-stocked' 
			WHEN 1 THEN 'Stocked' 
	END AS string) AS Stocked_Product
	,PL.INVENTDIMID AS Inventory_Dimension_ID
	,PL.ITEMID AS Item_Code
	,PL.ISDELETED						   
FROM {0} PL 
INNER JOIN {5} P ON P.RECID = PL.PARTITION and P.PARTITIONKEY = 'initial'
INNER JOIN {6} PH ON ((PH.PARTITION = PL.PARTITION) and (PL.DATAAREAID = PH.DATAAREAID) AND (PL.PURCHID=PH.PURCHID))
LEFT JOIN {1} TLDT ON PL.DELIVERYTYPE = TLDT.Value 
LEFT JOIN {2} PS ON PL.PURCHSTATUS = PS.Value 
LEFT JOIN {3} RSL ON PL.RETURNSTATUS = RSL.Value
LEFT JOIN {8} ITM ON ((ITM.PARTITION = PL.PARTITION) and (ITM.MODULETYPE=0) AND (PL.ITEMID=ITM.ITEMID AND (PL.DATAAREAID = ITM.DATAAREAID) ))
LEFT JOIN {4} LDD
	ON LDD.DATAAREAID = PL.DATAAREAID
	AND LDD.PARTITION = PL.PARTITION
	AND LDD.PURCHID = PL.PURCHID
""".format(stgViewName1,stgViewName2,stgViewName3,stgViewName4,stgViewName5,databaseStageTableName3,databaseStageTableName4,databaseStageTableName5,databaseStageTableName6,stgViewName)
display(spark.sql(sql))

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*)
# MAGIC FROM brtl.Incremental_PurchaseOrders

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(DISTINCT Record_ID)
# MAGIC FROM brtl.Incremental_PurchaseOrders

# COMMAND ----------

sql="""
SELECT *
  FROM {0}
""".format(stgViewName)
stg_df=(spark.sql(sql))

# COMMAND ----------

try:
  #read enrichedPath into a dataframe if it exists, otherwise create it
  dst_df = spark.read \
    .format("delta") \
    .load(enrichedDestinationPath) \
    .dropDuplicates()
except Exception as e:
   (stg_df \
    .write \
    .mode("overwrite") \
    .format("delta") \
    .save(enrichedDestinationPath)
    )

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE {0}
USING delta
LOCATION '{1}'
""".format(databaseTableName, enrichedDestinationPath)
spark.sql(sql)

# COMMAND ----------

spark.conf.set("spark.sql.crossJoin.enabled", "true")

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC MERGE INTO brtl.FCTPurchaseOrders
# MAGIC USING brtl.Incremental_PurchaseOrders
# MAGIC ON brtl.FCTPurchaseOrders.Record_ID = brtl.Incremental_PurchaseOrders.Record_ID 
# MAGIC WHEN MATCHED THEN
# MAGIC   DELETE

# COMMAND ----------

# MAGIC %md
# MAGIC #### Append Data in Query Zone (Enriched)

# COMMAND ----------

try:
  queryTableExists = (spark.table(databaseTableName) is not None)
except:
  queryTableExists = False

# COMMAND ----------

queryTableExists

# COMMAND ----------

try:
  if queryTableExists:
    (stg_df.repartition(numPartitions) \
      .write \
      .mode("append") \
      .option("mergeSchema", True) \
      .format("delta") \
      .save(enrichedDestinationPath)
    )
  else:
    (stg_df.repartition(numPartitions) \
      .write \
      .mode("overwrite") \
      .format("delta") \
      .save(enrichedPath)
    )
    sql = """
    CREATE TABLE {0}
    USING delta
    LOCATION '{1}'
    """.format(tableName, enrichedDestinationPath)
    spark.sql(sql)
except Exception as e:
  sourceName = "Query Zone Processing - Append Databricks Delta: Write to Query Zone"
  errorCode = "400"
  errorDescription = "Error Occured"
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Append Data in Synapse DW from Current State

# COMMAND ----------

sanctionedZoneNotebookPath = "../Framework/Sanctioned Zone Processing - Load Synapse DW Overwrite"
stageSchemaName = "stage"
stageTableName = "Incremental_PurchaseOrders"

run_with_retry(sanctionedZoneNotebookPath, 0, {"parentPipeLineExecutionLogKey": notebookExecutionLogKey, "containerName": containerName, "schemaName": stageSchemaName, "tableName": stageTableName, "numPartitions": numPartitions})

# COMMAND ----------

execsp = "DELETE brtl.FCTPurchaseOrders WHERE [Record_ID] in (SELECT [Record_ID] from stage.Incremental_Purchase))"
try:
  execute_sqldw_stored_procedure_no_results(execsp)
except:
  sourceName = "Destination Table does not exist"

# COMMAND ----------

blob_storage_account_name = adlsGen2StorageAccountName
blob_storage_container_name = "temp"

tempDir = "abfss://{}@{}.dfs.core.windows.net/".format(blob_storage_container_name, blob_storage_account_name) + dbutils.widgets.get("tableName")

# COMMAND ----------

sqlDwUrlSmall, connectionProperties = build_sqldw_jdbc_url_and_connectionProperties(sqldwservername, sqldwdatabasename, sqldwusername, sqldwpassword)

# COMMAND ----------

try:
  stg_df \
    .write \
    .format("com.databricks.spark.sqldw") \
    .mode("append") \
    .option("url", sqlDwUrlSmall) \
    .option("dbtable", fullyQualifiedTableName) \
    .option("useAzureMSI","True") \
    .option("maxStrLength",2048) \
    .option("tempdir", tempDir) \
    .save()
except Exception as e:
  sourceName = "Sanctioned Zone Processing - Load Azure SQL DW: Load Synapse SQL Data Warehouse"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Drop Temporary Table and Views

# COMMAND ----------

dbutils.fs.rm(tempDir,True)

# COMMAND ----------

sql = """
DROP VIEW IF EXISTS {0}
""".format(stgViewName1)
spark.sql(sql)

# COMMAND ----------

execsp = "IF OBJECT_ID('stage.Incremental_Purchase') IS NOT NULL DROP TABLE stage.Incremental_Purchase"
execute_sqldw_stored_procedure_no_results(execsp)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Optimize and Vacuum Table

# COMMAND ----------

sql="""OPTIMIZE {0}""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

if vacuumRetentionHours != '':
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", False)
  spark.sql("VACUUM " + databaseTableName + " RETAIN " + vacuumRetentionHours + " HOURS")
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", True)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Log Completion

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Completed
# MAGIC val logMessage = "Completed"
# MAGIC val notebookContext = ""
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

log_event_notebook_end(notebookExecutionLogKey=notebookExecutionLogKey, notebookStatus="SUCCEEDED", notebookName=notebookName, notebookExecutionGroupName="")
dbutils.notebook.exit("Succeeded")