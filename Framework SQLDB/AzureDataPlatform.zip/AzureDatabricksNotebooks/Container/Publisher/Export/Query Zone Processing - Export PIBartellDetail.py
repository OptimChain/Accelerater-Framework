# MAGIC %md
# MAGIC # Query Zone Processing - Export PIBartellDetail
# MAGIC ###### Author: Ranga Bondada 02/01/2020
# MAGIC 
# MAGIC Data Lake pattern for master data or small tables that can be overwritten every time.  Takes a file from the raw data path and overwrites the table in the Query zone.      
# MAGIC 
# MAGIC #### Usage
# MAGIC Supply the parameters above and run the notebook.  
# MAGIC 
# MAGIC #### Prerequisites
# MAGIC 1. Data must exist in the Data Lake /query zone (current State).   
# MAGIC 
# MAGIC #### Details

# COMMAND ----------

# MAGIC %md
# MAGIC #### Initialize Framework

# COMMAND ----------

dbutils.widgets.text(name="containerName", defaultValue="brtl", label="Container Name")
containerName = dbutils.widgets.get("containerName")

# COMMAND ----------

# MAGIC %run ../Framework/Secrets_Databricks_Container

# COMMAND ----------

# MAGIC %run ../Framework/Neudesic_Framework_Functions

# COMMAND ----------

dbutils.widgets.text(name="parentPipeLineExecutionLogKey", defaultValue="-1", label="Parent Pipeline Execution Log Key")
dbutils.widgets.text(name="numPartitions", defaultValue="8", label="Number of Partitions")
dbutils.widgets.text(name="schemaName", defaultValue="", label="Schema Name")
dbutils.widgets.text(name="tableName", defaultValue="PointySalesData", label="Table Name")
dbutils.widgets.text(name="vacuumRetentionHours", defaultValue="", label="Vacuum Retention Hours")

parentPipeLineExecutionLogKey = dbutils.widgets.get("parentPipeLineExecutionLogKey")
fullPathPrefix = "abfss://" + containerName + "@" + adlsGen2StorageAccountName + ".dfs.core.windows.net" 

numPartitions = int(dbutils.widgets.get("numPartitions"))

schemaName = dbutils.widgets.get("schemaName")
tableName = dbutils.widgets.get("tableName")
fullyQualifiedTableName = schemaName + "." + tableName
currentStatePath = fullPathPrefix + "/Query/CurrentState/" + schemaName + "/" + tableName
enrichedPath = fullPathPrefix + "/Query/Enriched/Exports/" + tableName
databaseTableName = containerName + "." + tableName
vacuumRetentionHours = dbutils.widgets.get("vacuumRetentionHours")

# COMMAND ----------

notebookName = "Query Zone Processing - Export PointySalesData"
notebookExecutionLogKey = log_event_notebook_start(notebookName,parentPipeLineExecutionLogKey)
print("Notebook Execution Log Key: {0}".format(notebookExecutionLogKey))

# COMMAND ----------

print("Schema Name: {0}".format(schemaName))
print("Table Name: {0}".format(tableName))
print("Fully Qualified Table Name: {0}".format(fullyQualifiedTableName))
print("Number of Partitions: {0}".format(numPartitions))
print("Current State Path: {0}".format(currentStatePath))
print("Enriched State Path: {0}".format(enrichedPath))

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Starting
# MAGIC val notebookPath = dbutils.notebook.getContext.notebookPath.get
# MAGIC val logMessage = "Starting"
# MAGIC val notebookContext = dbutils.notebook.getContext().toJson
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

# MAGIC %md
# MAGIC #### Re-Order Columns
# MAGIC * re-Order Columns to match destination schema

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.BARTELL_AVALPHYSQTYBYITEMSTOREVIEW")
spark.sql(sql)

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.RETAILTRANSACTIONSALESTRANS")
spark.sql(sql)

# COMMAND ----------


sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.INVENTITEMBARCODE")
spark.sql(sql)


# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl.BARTELL_AVALPHYSQTYBYITEMSTOREVIEW", fullPathPrefix + "/Query/CurrentState/BARTELL_AVALPHYSQTYBYITEMSTOREVIEW")
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl.RETAILTRANSACTIONSALESTRANS", fullPathPrefix + "/Query/CurrentState/RETAILTRANSACTIONSALESTRANS")
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format("brtl.INVENTITEMBARCODE", fullPathPrefix + "/Query/CurrentState/INVENTITEMBARCODE")
spark.sql(sql)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE VIEW brtl.UPCCodes 
# MAGIC AS
# MAGIC SELECT DISTINCT ITEMID, ITEMBARCODE
# MAGIC   FROM brtl.INVENTITEMBARCODE
# MAGIC   WHERE USEFORPRINTING =1 
# MAGIC   AND RETAILSHOWFORITEM =1

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE VIEW brtl.VWRETAILTRANSACTIONSALESTRANS
# MAGIC AS
# MAGIC SELECT STORE,ITEMID,SUM(QTY) AS QTY
# MAGIC FROM brtl.RETAILTRANSACTIONSALESTRANS
# MAGIC WHERE TRANSDATE >= DATE_ADD(CURRENT_DATE(),-1)
# MAGIC AND TRANSDATE < CURRENT_DATE()
# MAGIC GROUP BY STORE,ITEMID

# COMMAND ----------

sql = """
SELECT 
      CAST(OHV.INVENTLOCATIONID AS VARCHAR(3)) AS StoreNumber
     , OHV.ITEMID AS ItemNumber
     , LEFT(rpad(STRING(IFNULL(uc.ITEMBARCODE,'')),20,' '),20) AS UPC
     , RIGHT( CONCAT('0000000', IFNULL(STRING(INT(OHV.SUMOFAVAILPHYSICAL)),'')) ,7) AS OnHandQtyUnits
     , CONCAT(RIGHT(CONCAT('0000000', IFNULL(STRING(INT(CASE WHEN PS.QTY < 0 THEN ABS(PS.QTY) WHEN PS.QTY > 0 THEN 0 END)),'0')),7),'|') SalesQtyUnits
  FROM brtl.BARTELL_AVALPHYSQTYBYITEMSTOREVIEW OHV
  INNER JOIN brtl.UPCCodes uc ON uc.ITEMID = OHV.ITEMID
  LEFT JOIN brtl.VWRETAILTRANSACTIONSALESTRANS PS ON PS.ITEMID = OHV.ITEMID AND OHV.INVENTLOCATIONID = PS.STORE
   UNION 
SELECT 
       CAST(PS.STORE AS VARCHAR(3)) AS StoreNumber
      , PS.ITEMID AS ItemNumber
      , LEFT(rpad(STRING(IFNULL(uc.ITEMBARCODE,'')),20,' '),20) AS UPC
      , RIGHT( CONCAT('0000000', IFNULL(STRING(INT(OHV.SUMOFAVAILPHYSICAL)),'')) ,7) AS OnHandQtyUnits
      , CONCAT(RIGHT(CONCAT('0000000', IFNULL(STRING(INT(CASE WHEN PS.QTY < 0 THEN ABS(PS.QTY) WHEN PS.QTY > 0 THEN 0 END)),'0')),7),'|') SalesQtyUnits
  FROM brtl.VWRETAILTRANSACTIONSALESTRANS PS 
  LEFT JOIN brtl.BARTELL_AVALPHYSQTYBYITEMSTOREVIEW OHV ON PS.ITEMID = OHV.ITEMID AND OHV.INVENTLOCATIONID = PS.STORE
  INNER JOIN brtl.UPCCodes uc ON uc.ITEMID = OHV.ITEMID
""".format()
df=spark.sql(sql)

# COMMAND ----------

display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Write Data to Query Zone (Enriched)

# COMMAND ----------

try:
  df \
    .repartition(numPartitions) \
    .write \
    .mode("overwrite") \
	.option("overwriteSchema","true") \
    .format("delta") \
    .save(enrichedPath)
except Exception as e:
  sourceName = "Query Zone Processing - Overwrite: Write to Query Zone"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Create Spark Table

# COMMAND ----------

display(spark.sql("CREATE DATABASE IF NOT EXISTS " + containerName))

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

  sql = """
  CREATE TABLE IF NOT EXISTS {0}
  USING delta
  LOCATION '{1}'
  """.format(databaseTableName, enrichedPath)
  spark.sql(sql)

# COMMAND ----------

sql="""OPTIMIZE {0}""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

if vacuumRetentionHours != '':
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", False)
  spark.sql("VACUUM " + databaseTableName + " RETAIN " + vacuumRetentionHours + " HOURS")
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", True)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Log Completion

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Completed
# MAGIC val logMessage = "Completed"
# MAGIC val notebookContext = ""
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

log_event_notebook_end(notebookExecutionLogKey=notebookExecutionLogKey, notebookStatus="SUCCEEDED", notebookName=notebookName, notebookExecutionGroupName="")
dbutils.notebook.exit("Succeeded")