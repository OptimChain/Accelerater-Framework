# Databricks notebook source
# MAGIC  
# MAGIC  
# MAGIC  
# MAGIC  
# MAGIC %md
# MAGIC # Query Zone Processing - Overwrite DIMCategoryHierarchy
# MAGIC ###### Author: Samir Patel 12/16/2020
# MAGIC 
# MAGIC Data Lake pattern for tables with change feeds of new or updated records.  Takes a file from the raw data path and applies the updates to the Query zone.      
# MAGIC 
# MAGIC #### Usage
# MAGIC Supply the parameters above and run the notebook.  
# MAGIC 
# MAGIC #### Prerequisites  
# MAGIC 
# MAGIC #### Details

# COMMAND ----------

# MAGIC %md
# MAGIC #### Initialize

# COMMAND ----------

# MAGIC %run ../Framework/Secrets_Databricks_Container

# COMMAND ----------

# MAGIC %run ../Framework/Neudesic_Framework_Functions

# COMMAND ----------

#dbutils.widgets.removeAll()


# COMMAND ----------

dbutils.widgets.text(name="containerName", defaultValue="brtl", label="Container Name")
dbutils.widgets.text(name="parentPipeLineExecutionLogKey", defaultValue="-1", label="Parent Pipeline Execution Log Key")

# filePath is to pick up the schema of an actual file in the case of subfolders

dbutils.widgets.text(name="numPartitions", defaultValue="8", label="Number of Partitions")
dbutils.widgets.text(name="schemaName", defaultValue="brtl", label="Schema Name")
dbutils.widgets.text(name="tableName", defaultValue="DIMCategoryHierarchy", label="Table Name")
dbutils.widgets.text(name="vacuumRetentionHours", defaultValue="", label="Vacuum Retention Hours")

parentPipeLineExecutionLogKey = dbutils.widgets.get("parentPipeLineExecutionLogKey")
containerName = dbutils.widgets.get("containerName")
fullPathPrefix = "abfss://" + containerName + "@" + adlsgen2storageaccountname + ".dfs.core.windows.net" 

numPartitions = int(dbutils.widgets.get("numPartitions"))

schemaName = dbutils.widgets.get("schemaName")
tableName = dbutils.widgets.get("tableName")
fullyQualifiedTableName = schemaName + "." + tableName

currentStateDestinationPath = fullPathPrefix + "/Query/Enriched/" + tableName

badRecordsPath = "/BadRecords/" + schemaName + "/" + tableName
fullBadRecordsPath = fullPathPrefix + badRecordsPath
databaseTableName = containerName + "." + tableName
vacuumRetentionHours = dbutils.widgets.get("vacuumRetentionHours")

# COMMAND ----------

notebookName = "Query Zone Processing - Overwrite DIMCategoryHierarchy"
notebookExecutionLogKey = log_event_notebook_start(notebookName,parentPipeLineExecutionLogKey)
print("Notebook Execution Log Key: {0}".format(notebookExecutionLogKey))

# COMMAND ----------

print("Schema Name: {0}".format(schemaName))
print("Table Name: {0}".format(tableName))
print("Fully Qualified Table Name: {0}".format(fullyQualifiedTableName))
print("Number of Partitions: {0}".format(numPartitions))
print("Current State Destination Path: {0}".format(currentStateDestinationPath))
print("Bad Records Path: {0}".format(fullBadRecordsPath))
print("Database Table Name: {0}".format(databaseTableName))

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Starting
# MAGIC val notebookPath = dbutils.notebook.getContext.notebookPath.get
# MAGIC val logMessage = "Starting"
# MAGIC val notebookContext = dbutils.notebook.getContext().toJson
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

CurrentStateECORESCATEGORYPath = fullPathPrefix + "/Query/CurrentState/ECORESCATEGORY"
CurrentStateECORESPRODUCTCATEGORYPath = fullPathPrefix + "/Query/CurrentState/ECORESPRODUCTCATEGORY"

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from brtl.ECORESPRODUCTCATEGORY

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read Data from Query Zone (CurrentState}

# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format('brtl.ECORESCATEGORY', CurrentStateECORESCATEGORYPath)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format('brtl.ECORESPRODUCTCATEGORY', CurrentStateECORESPRODUCTCATEGORYPath)
spark.sql(sql)

# COMMAND ----------

sql = """	
SELECT CH.*, PRODUCT
  FROM brtl.ECORESPRODUCTCATEGORY AS ERPC
  INNER JOIN
    
   (

			SELECT	 CAT1.Name AS Level1Name, CAT1.LEVEL_ as Level1, CAT2.Name AS Level2Name, CAT2.LEVEL_ AS Level2,
					 null AS Level3Name, null AS CAT3LEVEL,  NULL AS Level4Name, NULL AS CAT4LEVEL, NULL AS Level5Name, NULL AS CAT5LEVEL,
					 CAT2.RECID AS LevelRECID
			FROM brtl.ECORESCATEGORY AS CAT1
				 INNER JOIN brtl.ECORESCATEGORY AS CAT2 ON CAT2.PARENTCATEGORY = CAT1.RECID
				 --INNER JOIN brtl.ECORESCATEGORY AS CAT3 ON CAT3.PARENTCATEGORY = CAT2.RECID
				--INNER JOIN brtl.ECORESCATEGORY AS CAT4 ON CAT4.PARENTCATEGORY = CAT3.RECID
				--INNER JOIN brtl.ECORESCATEGORY AS CAT5 ON CAT5.PARENTCATEGORY = CAT4.RECID
			WHERE CAT1.NAME = 'All'

		UNION ALL

			SELECT	 CAT1.Name AS Level1Name, CAT1.LEVEL_ as Level1, CAT2.Name AS Level2Name, CAT2.LEVEL_ AS Level2,
					 CAT3.Name AS Level3Name, CAT3.LEVEL_ AS CAT3LEVEL,  NULL AS Level4Name, NULL AS CAT4LEVEL, NULL AS Level5Name, NULL AS CAT5LEVEL,
					 CAT3.RECID AS LevelRECID
			FROM brtl.ECORESCATEGORY AS CAT1
				 INNER JOIN brtl.ECORESCATEGORY AS CAT2 ON CAT2.PARENTCATEGORY = CAT1.RECID
				 INNER JOIN brtl.ECORESCATEGORY AS CAT3 ON CAT3.PARENTCATEGORY = CAT2.RECID
				--INNER JOIN brtl.ECORESCATEGORY AS CAT4 ON CAT4.PARENTCATEGORY = CAT3.RECID
				--INNER JOIN brtl.ECORESCATEGORY AS CAT5 ON CAT5.PARENTCATEGORY = CAT4.RECID
			WHERE CAT1.NAME = 'All'

		UNION ALL

			SELECT	 CAT1.Name AS Level1Name, CAT1.LEVEL_ as Level1, CAT2.Name AS Level2Name, CAT2.LEVEL_ AS Level2,
				 CAT3.Name AS Level3Name, CAT3.LEVEL_ AS CAT3LEVEL,  CAT4.Name AS Level4Name, CAT4.LEVEL_ AS CAT4LEVEL, NULL AS Level5Name, NULL AS CAT5LEVEL,
				 CAT4.RECID AS LevelRECID
			FROM brtl.ECORESCATEGORY AS CAT1
			 INNER JOIN brtl.ECORESCATEGORY AS CAT2 ON CAT2.PARENTCATEGORY = CAT1.RECID
			 INNER JOIN brtl.ECORESCATEGORY AS CAT3 ON CAT3.PARENTCATEGORY = CAT2.RECID
			 INNER JOIN brtl.ECORESCATEGORY AS CAT4 ON CAT4.PARENTCATEGORY = CAT3.RECID
			--INNER JOIN brtl.ECORESCATEGORY AS CAT5 ON CAT5.PARENTCATEGORY = CAT4.RECID
			WHERE CAT1.NAME = 'All'

		UNION ALL

			SELECT	 CAT1.Name AS Level1Name, CAT1.LEVEL_ as Level1, CAT2.Name AS Level2Name, CAT2.LEVEL_ AS Level2,
				 CAT3.Name AS Level3Name, CAT3.LEVEL_ AS CAT3LEVEL,  CAT4.Name AS Level4Name, CAT4.LEVEL_ AS CAT4LEVEL, CAT5.Name AS Level5Name, CAT5.LEVEL_ AS CAT5LEVEL,
				 CAT5.RECID AS LevelRECID
			FROM brtl.ECORESCATEGORY AS CAT1
			 INNER JOIN brtl.ECORESCATEGORY AS CAT2 ON CAT2.PARENTCATEGORY = CAT1.RECID
			 INNER JOIN brtl.ECORESCATEGORY AS CAT3 ON CAT3.PARENTCATEGORY = CAT2.RECID
			 INNER JOIN brtl.ECORESCATEGORY AS CAT4 ON CAT4.PARENTCATEGORY = CAT3.RECID
			 INNER JOIN brtl.ECORESCATEGORY AS CAT5 ON CAT5.PARENTCATEGORY = CAT4.RECID
			WHERE CAT1.NAME = 'All'		

			  ) 
		  
			  AS CH ON CH.LevelRECID = ERPC.CATEGORY
"""	
dest_df=spark.sql(sql)

# COMMAND ----------

display(dest_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Write Data to Query Zone (Enriched)

# COMMAND ----------

display(spark.sql("DROP TABLE IF EXISTS " + databaseTableName))

# COMMAND ----------

dbutils.fs.rm("dbfs:/user/hive/warehouse/cgs.db/DIMCategoryHierarchy", True)

# COMMAND ----------

try:
  queryTableExists = (spark.table(tableName) is not None)
  metadata = spark.sql("DESCRIBE DETAIL " + databaseTableName)
  format = metadata.collect()[0][0]
  if format != "delta":
    sourceName = "Query Zone Processing - Overwrite Delta Lake: Validate Query Table"
    errorCode = "400"
    errorDescription = "Table {0}.{1} exists but is not in Databricks Delta format.".format(schemaName, tableName)
    log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
    raise ValueError(errorDescription)
except:
  queryTableExists = False

# COMMAND ----------

queryTableExists

# COMMAND ----------

try:
  if queryTableExists:
    (dest_df \
      .write \
      .mode("overwrite") \
      .option("OverwriteSchema","true") \
      .format("delta") \
      .save(currentStateDestinationPath)
    )
  else:
    (dest_df \
      .write \
      .mode("overwrite") \
      .format("delta") \
      .option("OverwriteSchema","true") \
      .save(currentStateDestinationPath)
    )
    sql = """
    CREATE TABLE IF NOT EXISTS {0}
    USING delta
    LOCATION '{1}'
    """.format(databaseTableName, currentStateDestinationPath)
    spark.sql(sql)
except Exception as e:
  sourceName = "Query Zone Processing - Overwrite Delta Lake: Write to Query Zone"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

sql = """
SELECT * FROM {0}
""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Overwrite data into Synapse DW from Current State

# COMMAND ----------

execsp = "DELETE brtl.DIMCategoryHierarchy"
try:
  execute_sqldw_stored_procedure_no_results(execsp)
except:
  sourceName = "Destination Table does not exist"

# COMMAND ----------

if vacuumRetentionHours != '':
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", False)
  spark.sql("VACUUM " + databaseTableName + " RETAIN " + vacuumRetentionHours + " HOURS")
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", True)

# COMMAND ----------

blob_storage_account_name = adlsGen2StorageAccountName
blob_storage_container_name = "temp"

tempDir = "abfss://{}@{}.dfs.core.windows.net/".format(blob_storage_container_name, blob_storage_account_name) + dbutils.widgets.get("tableName")

# COMMAND ----------

sqlDwUrlSmall, connectionProperties = build_sqldw_jdbc_url_and_connectionProperties(sqldwservername, sqldwdatabasename, sqldwusername, sqldwpassword)

# COMMAND ----------

try:
  dest_df \
    .write \
    .format("com.databricks.spark.sqldw") \
    .mode("append") \
    .option("url", sqlDwUrlSmall) \
    .option("dbtable", fullyQualifiedTableName) \
    .option("useAzureMSI","True") \
    .option("maxStrLength",2048) \
    .option("tempdir", tempDir) \
    .save()
except Exception as e:
  sourceName = "Sanctioned Zone Processing - Load Azure SQL DW: Load Synapse SQL Data Warehouse"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Drop Temporary Tables and Views

# COMMAND ----------

dbutils.fs.rm(tempDir,True)

# COMMAND ----------

execsp = "IF OBJECT_ID('stage.RETAILCHANNELTABLE') IS NOT NULL DROP TABLE stage.RETAILCHANNELTABLE"
execute_sqldw_stored_procedure_no_results(execsp)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Optimize and Vacuum Table

# COMMAND ----------

sql="""OPTIMIZE {0}""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

if vacuumRetentionHours != '':
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", False)
  spark.sql("VACUUM " + databaseTableName + " RETAIN " + vacuumRetentionHours + " HOURS")
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", True)

# COMMAND ----------

try:
  dbutils.fs.ls(badRecordsPath)
  sourceName = "Query Zone Processing - Overwrite Delta Lake: Bad Records"
  errorCode = "500"
  errorDescription = "Processing completed, but rows were written to badRecordsPath: {0}.  Raw records do not comply with the current schema for table {1}.{2}.".format(badRecordsPath, schemaName, tableName)
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise ValueError(errorDescription)
except:
  print("success")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Log Completion

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Completed
# MAGIC val logMessage = "Completed"
# MAGIC val notebookContext = ""
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

log_event_notebook_end(notebookExecutionLogKey=notebookExecutionLogKey, notebookStatus="SUCCEEDED", notebookName=notebookName, notebookExecutionGroupName="")
dbutils.notebook.exit("Succeeded")