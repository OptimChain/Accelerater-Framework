# MAGIC %md
# MAGIC # Query Zone Processing - Export Incremental ProductInfo
# MAGIC ###### Author: Ranga Bondada 02/09/2020
# MAGIC 
# MAGIC Data Lake pattern for master data or small tables that can be overwritten every time.  Takes a file from the raw data path and overwrites the table in the Query zone.      
# MAGIC 
# MAGIC #### Usage
# MAGIC Supply the parameters above and run the notebook.  
# MAGIC 
# MAGIC #### Prerequisites
# MAGIC 1. Data must exist in the Data Lake /query zone (current State).   
# MAGIC 
# MAGIC #### Details

# COMMAND ----------

# MAGIC %md
# MAGIC #### Initialize Framework

# COMMAND ----------

dbutils.widgets.text(name="containerName", defaultValue="brtl", label="Container Name")
containerName = dbutils.widgets.get("containerName")

# COMMAND ----------

# MAGIC %run ../Framework/Secrets_Databricks_Container

# COMMAND ----------

# MAGIC %run ../Framework/Neudesic_Framework_Functions

# COMMAND ----------

dbutils.widgets.text(name="parentPipeLineExecutionLogKey", defaultValue="-1", label="Parent Pipeline Execution Log Key")
dbutils.widgets.text(name="numPartitions", defaultValue="8", label="Number of Partitions")
dbutils.widgets.text(name="schemaName", defaultValue="brtl", label="Schema Name")
dbutils.widgets.text(name="tableName", defaultValue="ProductInfo", label="Table Name")
dbutils.widgets.text(name="vacuumRetentionHours", defaultValue="", label="Vacuum Retention Hours")
dbutils.widgets.text(name="timestampColumns", defaultValue="", label="TimeStamp Columns")

timestampColumns = dbutils.widgets.get("timestampColumns")

parentPipeLineExecutionLogKey = dbutils.widgets.get("parentPipeLineExecutionLogKey")
fullPathPrefix = "abfss://" + containerName + "@" + adlsGen2StorageAccountName + ".dfs.core.windows.net" 

numPartitions = int(dbutils.widgets.get("numPartitions"))

schemaName = dbutils.widgets.get("schemaName")
tableName = dbutils.widgets.get("tableName")
fullyQualifiedTableName = schemaName + "." + tableName
currentStatePath = fullPathPrefix + "/Query/CurrentState/" + schemaName + "/" + tableName
enrichedPath = fullPathPrefix + "/Query/Enriched/Exports/" + tableName
trackingEnrichedPath = fullPathPrefix + "/Query/Enriched/Exports/Tracking/" + tableName + "Tracking"

databaseTableName = containerName + "." + tableName
vacuumRetentionHours = dbutils.widgets.get("vacuumRetentionHours")

# COMMAND ----------

notebookName = "Query Zone Processing - Export Incremental ProductInfo"
notebookExecutionLogKey = log_event_notebook_start(notebookName,parentPipeLineExecutionLogKey)
print("Notebook Execution Log Key: {0}".format(notebookExecutionLogKey))

# COMMAND ----------

print("Schema Name: {0}".format(schemaName))
print("Table Name: {0}".format(tableName))
print("ProcessingMode: {0}".format(timestampColumns))
print("Fully Qualified Table Name: {0}".format(fullyQualifiedTableName))
print("Number of Partitions: {0}".format(numPartitions))
print("Current State Path: {0}".format(currentStatePath))
print("Enriched State Path: {0}".format(enrichedPath))

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Starting
# MAGIC val notebookPath = dbutils.notebook.getContext.notebookPath.get
# MAGIC val logMessage = "Starting"
# MAGIC val notebookContext = dbutils.notebook.getContext().toJson
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

if timestampColumns == 'Full':
  dbutils.fs.rm(trackingEnrichedPath,True)

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.ECORESCATEGORY")
spark.sql(sql)

sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.ECORESPRODUCTCATEGORY")
spark.sql(sql)

sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.INVENTTABLE")
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.ECORESPRODUCT")
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.ECORESPRODUCTTRANSLATIONS")
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.RETAILINVENTTABLE")
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.INVENTTABLEMODULE")
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.INVENTITEMBARCODE")
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.WHSINVENTTABLE")
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.WHSUOMSEQGROUPLINE")
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.WHSPHYSDIMUOM")
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.CategoryLevels")
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.RETAILINVENTLINKEDITEM")
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS {0}
""".format("brtl.INVENTITEMGROUPITEM")
spark.sql(sql)


# COMMAND ----------

sql = """
CREATE TABLE {0}
USING delta
LOCATION '{1}'
""".format("brtl.ECORESCATEGORY",fullPathPrefix + "/Query/CurrentState/ECORESCATEGORY")
spark.sql(sql)

sql = """
CREATE TABLE {0}
USING delta
LOCATION '{1}'
""".format("brtl.ECORESPRODUCTCATEGORY",fullPathPrefix + "/Query/CurrentState/ECORESPRODUCTCATEGORY")
spark.sql(sql)

sql = """
CREATE TABLE {0}
USING delta
LOCATION '{1}'
""".format("brtl.INVENTTABLE",fullPathPrefix + "/Query/CurrentState/INVENTTABLE")
spark.sql(sql)
sql = """
CREATE TABLE {0}
USING delta
LOCATION '{1}'
""".format("brtl.ECORESPRODUCT",fullPathPrefix + "/Query/CurrentState/ECORESPRODUCT")
spark.sql(sql)
sql = """
CREATE TABLE {0}
USING delta
LOCATION '{1}'
""".format("brtl.ECORESPRODUCTTRANSLATIONS",fullPathPrefix + "/Query/CurrentState/ECORESPRODUCTTRANSLATIONS")
spark.sql(sql)
sql = """
CREATE TABLE {0}
USING delta
LOCATION '{1}'
""".format("brtl.RETAILINVENTTABLE",fullPathPrefix + "/Query/CurrentState/RETAILINVENTTABLE")
spark.sql(sql)
sql = """
CREATE TABLE {0}
USING delta
LOCATION '{1}'
""".format("brtl.INVENTTABLEMODULE",fullPathPrefix + "/Query/CurrentState/INVENTTABLEMODULE")
spark.sql(sql)
sql = """
CREATE TABLE {0}
USING delta
LOCATION '{1}'
""".format("brtl.INVENTITEMBARCODE",fullPathPrefix + "/Query/CurrentState/INVENTITEMBARCODE")
spark.sql(sql)
sql = """
CREATE TABLE {0}
USING delta
LOCATION '{1}'
""".format("brtl.WHSINVENTTABLE",fullPathPrefix + "/Query/CurrentState/WHSINVENTTABLE")
spark.sql(sql)
sql = """
CREATE TABLE {0}
USING delta
LOCATION '{1}'
""".format("brtl.WHSUOMSEQGROUPLINE",fullPathPrefix + "/Query/CurrentState/WHSUOMSEQGROUPLINE")
spark.sql(sql)
sql = """
CREATE TABLE {0}
USING delta
LOCATION '{1}'
""".format("brtl.WHSPHYSDIMUOM",fullPathPrefix + "/Query/CurrentState/WHSPHYSDIMUOM")
spark.sql(sql)

sql = """
CREATE TABLE {0}
USING delta
LOCATION '{1}'
""".format("brtl.RETAILINVENTLINKEDITEM",fullPathPrefix + "/Query/CurrentState/RETAILINVENTLINKEDITEM")
spark.sql(sql)
sql = """
CREATE TABLE {0}
USING delta
LOCATION '{1}'
""".format("brtl.INVENTITEMGROUPITEM",fullPathPrefix + "/Query/CurrentState/INVENTITEMGROUPITEM")
spark.sql(sql)


# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE brtl.CategoryLevels 
# MAGIC AS
# MAGIC SELECT CH.*, PRODUCT
# MAGIC FROM brtl.ECORESPRODUCTCATEGORY AS ERPC
# MAGIC INNER JOIN (
# MAGIC         SELECT CAT1.Name AS Level1Name, 
# MAGIC                CAT1.LEVEL_ as Level1, 
# MAGIC                CAT2.Name AS Level2Name, 
# MAGIC                CAT2.LEVEL_ AS Level2,
# MAGIC                null AS Level3Name, 
# MAGIC                null AS CAT3LEVEL,  
# MAGIC                NULL AS Level4Name, 
# MAGIC                NULL AS CAT4LEVEL, 
# MAGIC                NULL AS Level5Name, 
# MAGIC                NULL AS CAT5LEVEL,
# MAGIC                CAT2.RECID AS LevelRECID
# MAGIC         FROM brtl.ECORESCATEGORY AS CAT1
# MAGIC         INNER JOIN brtl.ECORESCATEGORY AS CAT2 ON CAT2.PARENTCATEGORY = CAT1.RECID
# MAGIC         WHERE CAT1.NAME = 'ALL'
# MAGIC         UNION ALL
# MAGIC         SELECT CAT1.Name AS Level1Name, 
# MAGIC                CAT1.LEVEL_ as Level1, 
# MAGIC                CAT2.Name AS Level2Name, 
# MAGIC                CAT2.LEVEL_ AS Level2,
# MAGIC                CAT3.Name AS Level3Name, 
# MAGIC                CAT3.LEVEL_ AS CAT3LEVEL,  
# MAGIC                NULL AS Level4Name, 
# MAGIC                NULL AS CAT4LEVEL, 
# MAGIC                NULL AS Level5Name, 
# MAGIC                NULL AS CAT5LEVEL,
# MAGIC                CAT3.RECID AS LevelRECID
# MAGIC         FROM brtl.ECORESCATEGORY AS CAT1
# MAGIC         INNER JOIN brtl.ECORESCATEGORY AS CAT2 ON CAT2.PARENTCATEGORY = CAT1.RECID
# MAGIC         INNER JOIN brtl.ECORESCATEGORY AS CAT3 ON CAT3.PARENTCATEGORY = CAT2.RECID
# MAGIC         WHERE CAT1.NAME = 'ALL'
# MAGIC 
# MAGIC         UNION ALL
# MAGIC         SELECT CAT1.Name AS Level1Name, 
# MAGIC                CAT1.LEVEL_ as Level1, 
# MAGIC                CAT2.Name AS Level2Name, 
# MAGIC                CAT2.LEVEL_ AS Level2,
# MAGIC                CAT3.Name AS Level3Name, 
# MAGIC                CAT3.LEVEL_ AS CAT3LEVEL,  
# MAGIC                CAT4.Name AS Level4Name, 
# MAGIC                CAT4.LEVEL_ AS CAT4LEVEL, 
# MAGIC                NULL AS Level5Name, 
# MAGIC                NULL AS CAT5LEVEL,
# MAGIC                CAT4.RECID AS LevelRECID
# MAGIC         FROM brtl.ECORESCATEGORY AS CAT1
# MAGIC         INNER JOIN brtl.ECORESCATEGORY AS CAT2 ON CAT2.PARENTCATEGORY = CAT1.RECID
# MAGIC         INNER JOIN brtl.ECORESCATEGORY AS CAT3 ON CAT3.PARENTCATEGORY = CAT2.RECID
# MAGIC         INNER JOIN brtl.ECORESCATEGORY AS CAT4 ON CAT4.PARENTCATEGORY = CAT3.RECID
# MAGIC         WHERE CAT1.NAME = 'ALL'
# MAGIC         UNION ALL
# MAGIC         SELECT CAT1.Name AS Level1Name, 
# MAGIC                CAT1.LEVEL_ as Level1, 
# MAGIC                CAT2.Name AS Level2Name, 
# MAGIC                CAT2.LEVEL_ AS Level2,
# MAGIC                CAT3.Name AS Level3Name, 
# MAGIC                CAT3.LEVEL_ AS CAT3LEVEL,  
# MAGIC                CAT4.Name AS Level4Name, 
# MAGIC                CAT4.LEVEL_ AS CAT4LEVEL, 
# MAGIC                CAT5.Name AS Level5Name, 
# MAGIC                CAT5.LEVEL_ AS CAT5LEVEL,
# MAGIC                CAT5.RECID AS LevelRECID
# MAGIC         FROM brtl.ECORESCATEGORY AS CAT1
# MAGIC         INNER JOIN brtl.ECORESCATEGORY AS CAT2 ON CAT2.PARENTCATEGORY = CAT1.RECID
# MAGIC         INNER JOIN brtl.ECORESCATEGORY AS CAT3 ON CAT3.PARENTCATEGORY = CAT2.RECID
# MAGIC         INNER JOIN brtl.ECORESCATEGORY AS CAT4 ON CAT4.PARENTCATEGORY = CAT3.RECID
# MAGIC         INNER JOIN brtl.ECORESCATEGORY AS CAT5 ON CAT5.PARENTCATEGORY = CAT4.RECID
# MAGIC         WHERE CAT1.NAME = 'ALL'                 
# MAGIC ) AS CH ON CH.LevelRECID = ERPC.CATEGORY

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS brtl.MainQuery

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM brtl.ECORESPRODUCTTRANSLATIONS

# COMMAND ----------

sql = """
CREATE TABLE brtl.MainQuery
AS
SELECT
         IT.ITEMID
       , IIB.ITEMBARCODE AS Barcode
       , IIB.BARCODESETUPID AS BarcodeType
       , '' AS SuppliedHow
       , EPT.ProductName
       , EP.SEARCHNAME AS ShelfLabelDescription
       , CASE
              WHEN EP.PRODUCTTYPE = 1 THEN 'Item'
              WHEN EP.PRODUCTTYPE = 2 THEN 'Service'
         END AS ProductType      
       , '' AS Shelflabeldescription2
       , '' AS Shelflabeldescription3
       , '' AS Size
       , '' AS SizeUOM
       , WIT.UOMSEQGROUPID AS WHSUnitSequnce
       , WGL.UNITID AS WHSInnerUnit
       , ITMI.UNITID AS InventoryUnit
       , ITMP.PRICE AS PurchasePrice
       , ITMP.UNITID AS PurchaseUnit
       , ITMP.PRICEUNIT AS PurchasePriceUnit
       , WPD.DEPTH * WPD.HEIGHT * WPD.WIDTH AS CubeVolume
       , 'CUBIC INCHES' AS CubeUOM
       , WPD.WEIGHT AS Weight
       , 'lb' AS DefaultWightUOM
       , '' AS UnitsInLayers
       , '' AS UnitsOnPallets
       , GTIN.ITEMBARCODE AS GTIN
       , IT.PRIMARYVENDORID AS PrimaryVendor
       , ITMS.PRICE AS SalePrice
       , ITMS.UNITID AS SalesUnit
       , ITMS.PRICEUNIT AS SalePriceUnit
       , RIL.LINKEDITEMID
       , CASE WHEN EIT.ECL_EBTELIGIBLE = 1 THEN 'Y' ELSE 'N' END AS EligibleForFoodStamp
       , IT.ECL_ITEMSTATUS
       , CASE WHEN IT.STANDARDCONFIGID = '' THEN 'No' ELSE 'Yes' END AS IsKit
       , CASE WHEN IT.STANDARDCONFIGID = '' THEN NULL ELSE IT.STANDARDCONFIGID END AS KitNumber
       , CASE WHEN IIG.ITEMGROUPID IS NULL THEN 'No' ELSE 'Yes' END AS IsCoupon
       , CL.Level5Name
       , CL.Level4Name
       , CL.Level3Name
       , CL.Level2Name
  FROM brtl.INVENTTABLE AS IT
  LEFT JOIN brtl.ECORESPRODUCT EP ON EP.DISPLAYPRODUCTNUMBER = IT.ITEMID
  LEFT JOIN brtl.ECORESPRODUCTTRANSLATIONS EPT ON EPT.PRODUCT = EP.RECID
  LEFT JOIN brtl.RETAILINVENTTABLE EIT ON EIT.ITEMID = IT.ITEMID
  LEFT JOIN brtl.INVENTTABLEMODULE ITMS ON ITMS.ITEMID = IT.ITEMID AND ITMS.MODULETYPE = 2
  LEFT JOIN brtl.INVENTTABLEMODULE ITMP ON ITMP.ITEMID = IT.ITEMID AND ITMP.MODULETYPE = 1
  LEFT JOIN brtl.INVENTTABLEMODULE ITMI ON ITMI.ITEMID = IT.ITEMID AND ITMI.MODULETYPE = 0
  LEFT JOIN brtl.INVENTITEMBARCODE IIB ON IIB.ITEMID = IT.ITEMID AND IIB.RETAILSHOWFORITEM = 1 AND IIB.USEFORPRINTING = 1 -- AND UPPER(IIB.UNITID) = 'EA'
  LEFT JOIN brtl.INVENTITEMBARCODE GTIN ON GTIN.ITEMID = IT.ITEMID AND GTIN.UNITID LIKE '%case%' AND ITMP.UNITID = GTIN.UNITID AND ITMP.MODULETYPE = 1 AND GTIN.USEFORPRINTING = 0
  LEFT JOIN brtl.WHSINVENTTABLE WIT ON WIT.ITEMID = IT.ITEMID
  LEFT JOIN brtl.WHSUOMSEQGROUPLINE WGL ON WGL.UOMSEQGROUPID = WIT.UOMSEQGROUPID AND WGL.UNITID LIKE '%inner%'
  LEFT JOIN brtl.WHSPHYSDIMUOM WPD ON WPD.ITEMID = IT.ITEMID AND UPPER(WPD.UOM) = UPPER(ITMP.UNITID)
  LEFT JOIN brtl.CategoryLevels CL ON CL.PRODUCT = EP.RECID
  LEFT JOIN brtl.RETAILINVENTLINKEDITEM RIL ON RIL.ITEMID = IT.ITEMID
  LEFT JOIN brtl.INVENTITEMGROUPITEM IIG ON IIG.ITEMID = IT.ITEMID AND IIG.ITEMGROUPID LIKE '1__'
  WHERE IT.PRIMARYVENDORID != 'V000754'
  AND  IT.PRIMARYVENDORID != 'V100971'
  AND IT.PRIMARYVENDORID <> 'V000767'
""".format()
spark.sql(sql)


# COMMAND ----------

IsFirstTime=file_exists(trackingEnrichedPath)

# COMMAND ----------

try:
  #read enrichedPath into a dataframe if it exists, otherwise create it
  dst_df = spark.read \
    .format("delta") \
    .load(trackingEnrichedPath) \
    .dropDuplicates()
except Exception as e:
  IsFirstTime = True
  

# COMMAND ----------

IsFirstTime

# COMMAND ----------

if not IsFirstTime:
  sql = """
  DROP TABLE IF EXISTS {0}
  """.format("brtl.ProductInfoTracking")
  spark.sql(sql)

# COMMAND ----------

if not IsFirstTime:
  sql = """
  CREATE TABLE {0}
  USING delta
  LOCATION '{1}'
  """.format("brtl.ProductInfoTracking",trackingEnrichedPath)
  spark.sql(sql)

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS brtl.NewProductInfo

# COMMAND ----------

sql = """
CREATE TABLE brtl.NewProductInfo
USING DELTA
AS
SELECT *, HASH( Barcode
                , BarcodeType
                , SuppliedHow
                , ProductName
                , ShelfLabelDescription
                , ProductType      
                , Shelflabeldescription2
                , Shelflabeldescription3
                , Size
                , SizeUOM
                , WHSUnitSequnce
                , WHSInnerUnit
                , InventoryUnit
                , PurchasePrice
                , PurchaseUnit
                , PurchasePriceUnit
                , CubeVolume
                , CubeUOM
                , Weight
                , DefaultWightUOM
                , UnitsInLayers
                , UnitsOnPallets
                , GTIN
                , PrimaryVendor
                , SalePrice
                , SalesUnit
                , SalePriceUnit
                , LINKEDITEMID
                , EligibleForFoodStamp
                , ECL_ITEMSTATUS
                , IsKit
                , KitNumber
                , IsCoupon
                , Level5Name
                , Level4Name
                , Level3Name
                , Level2Name
                ) HashValue
FROM brtl.MainQuery
""".format()
spark.sql(sql)

# COMMAND ----------

if not IsFirstTime:
  sql = """
  MERGE INTO brtl.NewProductInfo AS NPI
  USING  brtl.ProductInfoTracking as PIT ON NPI.ITEMID = PIT.ITEMID AND NPI.HashValue = PIT.HashValue
  WHEN MATCHED THEN DELETE"""
  spark.sql(sql)

# COMMAND ----------

sql = """
SELECT ITEMID
      , Barcode
      , BarcodeType
      , SuppliedHow
      , ProductName
      , ShelfLabelDescription
      , ProductType      
      , Shelflabeldescription2
      , Shelflabeldescription3
      , Size
      , SizeUOM
      , WHSUnitSequnce
      , WHSInnerUnit
      , InventoryUnit
      , PurchasePrice
      , PurchaseUnit
      , PurchasePriceUnit
      , CubeVolume
      , CubeUOM
      , Weight
      , DefaultWightUOM
      , UnitsInLayers
      , UnitsOnPallets
      , GTIN
      , PrimaryVendor
      , SalePrice
      , SalesUnit
      , SalePriceUnit
      , LINKEDITEMID
      , EligibleForFoodStamp
      , ECL_ITEMSTATUS
      , IsKit
      , KitNumber
      , IsCoupon
      , Level5Name
      , Level4Name
      , Level3Name
      , Level2Name
FROM brtl.NewProductInfo
"""
df = spark.sql(sql)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Write Data to Query Zone (Enriched)

# COMMAND ----------

try:
  df \
    .repartition(numPartitions) \
    .write \
    .mode("overwrite") \
	.option("overwriteSchema","true") \
    .format("delta") \
    .save(enrichedPath)
except Exception as e:
  sourceName = "Query Zone Processing - Overwrite: Write to Query Zone"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

if not IsFirstTime:
  sql = """
  MERGE INTO brtl.ProductInfoTracking AS PIT
  USING  brtl.NewProductInfo as NPI ON NPI.ITEMID = PIT.ITEMID AND NPI.HashValue = PIT.HashValue
  WHEN MATCHED THEN DELETE"""
  spark.sql(sql)

# COMMAND ----------

sql = """
SELECT ITEMID,HASH(
                 Barcode
                , BarcodeType
                , SuppliedHow
                , ProductName
                , ShelfLabelDescription
                , ProductType      
                , Shelflabeldescription2
                , Shelflabeldescription3
                , Size
                , SizeUOM
                , WHSUnitSequnce
                , WHSInnerUnit
                , InventoryUnit
                , PurchasePrice
                , PurchaseUnit
                , PurchasePriceUnit
                , CubeVolume
                , CubeUOM
                , Weight
                , DefaultWightUOM
                , UnitsInLayers
                , UnitsOnPallets
                , GTIN
                , PrimaryVendor
                , SalePrice
                , SalesUnit
                , SalePriceUnit
                , LINKEDITEMID
                , EligibleForFoodStamp
                , ECL_ITEMSTATUS
                , IsKit
                , KitNumber
                , IsCoupon
                , Level5Name
                , Level4Name
                , Level3Name
                , Level2Name
                ) HashValue
        ,CURRENT_TIMESTAMP() SENT_DATE FROM brtl.NewProductInfo
"""
tracking_df = spark.sql(sql)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Write Tracking Data to Query Zone (Enriched)

# COMMAND ----------

try:
  tracking_df \
    .repartition(numPartitions) \
    .write \
    .mode("append") \
	.option("overwriteSchema","true") \
    .format("delta") \
    .save(trackingEnrichedPath)
except Exception as e:
  sourceName = "Query Zone Processing - Overwrite: Write to Query Zone"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Create Spark Table

# COMMAND ----------

display(spark.sql("CREATE DATABASE IF NOT EXISTS " + containerName))

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

  sql = """
  CREATE TABLE IF NOT EXISTS {0}
  USING delta
  LOCATION '{1}'
  """.format(databaseTableName, enrichedPath)
  spark.sql(sql)

# COMMAND ----------

sql="""
select count(*) from {0}
""".format(databaseTableName)
display(spark.sql(sql))

# COMMAND ----------

if vacuumRetentionHours != '':
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", False)
  spark.sql("VACUUM " + databaseTableName + " RETAIN " + vacuumRetentionHours + " HOURS")
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", True)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Log Completion

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Completed
# MAGIC val logMessage = "Completed"
# MAGIC val notebookContext = ""
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

log_event_notebook_end(notebookExecutionLogKey=notebookExecutionLogKey, notebookStatus="SUCCEEDED", notebookName=notebookName, notebookExecutionGroupName="")
dbutils.notebook.exit("Succeeded")