# MAGIC  
# MAGIC  
# MAGIC %md
# MAGIC # Query Zone Processing - Overwrite DimCustomer
# MAGIC ###### Author: Ranga Bondada 12/30/2020
# MAGIC 
# MAGIC Data Lake pattern for tables with change feeds of new or updated records.  Takes a file from the raw data path and applies the updates to the Query zone.      
# MAGIC 
# MAGIC #### Usage
# MAGIC Supply the parameters above and run the notebook.  
# MAGIC 
# MAGIC #### Prerequisites
# MAGIC 1. Raw Data must exist in the Data Lake /raw zone in JSON format.  
# MAGIC 
# MAGIC #### Details

# COMMAND ----------

# MAGIC %md
# MAGIC #### Initialize

# COMMAND ----------

# MAGIC %run ../Framework/Secrets_Databricks_Container

# COMMAND ----------

# MAGIC %run ../Framework/Neudesic_Framework_Functions

# COMMAND ----------

dbutils.widgets.text(name="containerName", defaultValue="brtl", label="Container Name")
dbutils.widgets.text(name="parentPipeLineExecutionLogKey", defaultValue="-1", label="Parent Pipeline Execution Log Key")

# filePath is to pick up the schema of an actual file in the case of subfolders

dbutils.widgets.text(name="numPartitions", defaultValue="8", label="Number of Partitions")
dbutils.widgets.text(name="schemaName", defaultValue="brtl", label="Schema Name")
dbutils.widgets.text(name="tableName", defaultValue="DimCustomer", label="Table Name")
dbutils.widgets.text(name="vacuumRetentionHours", defaultValue="", label="Vacuum Retention Hours")

parentPipeLineExecutionLogKey = dbutils.widgets.get("parentPipeLineExecutionLogKey")
containerName = dbutils.widgets.get("containerName")
fullPathPrefix = "abfss://" + containerName + "@" + adlsgen2storageaccountname + ".dfs.core.windows.net" 

numPartitions = int(dbutils.widgets.get("numPartitions"))

schemaName = dbutils.widgets.get("schemaName")
tableName = dbutils.widgets.get("tableName")
fullyQualifiedTableName = schemaName + "." + tableName

currentStateDestinationPath = fullPathPrefix + "/Query/Enriched/" + tableName

badRecordsPath = "/BadRecords/" + schemaName + "/" + tableName
fullBadRecordsPath = fullPathPrefix + badRecordsPath
databaseTableName = containerName + "." + tableName
vacuumRetentionHours = dbutils.widgets.get("vacuumRetentionHours")

# COMMAND ----------

stageTableName = "CUSTTABLE"

databaseStageTableName = containerName + "." + stageTableName

currentStateStagePath = fullPathPrefix + "/Query/CurrentState/"  + stageTableName


# COMMAND ----------

notebookName = "Query Zone Processing - Overwrite DimCustomer"
notebookExecutionLogKey = log_event_notebook_start(notebookName,parentPipeLineExecutionLogKey)
print("Notebook Execution Log Key: {0}".format(notebookExecutionLogKey))

# COMMAND ----------

print("Schema Name: {0}".format(schemaName))
print("Stage Table Name: {0}".format(databaseStageTableName))
print("Table Name: {0}".format(tableName))
print("Fully Qualified Table Name: {0}".format(fullyQualifiedTableName))
print("Number of Partitions: {0}".format(numPartitions))
print("Current State Stage Path: {0}".format(currentStateStagePath))
print("Current State Destination Path: {0}".format(currentStateDestinationPath))
print("Bad Records Path: {0}".format(fullBadRecordsPath))
print("Database Table Name: {0}".format(databaseTableName))

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Starting
# MAGIC val notebookPath = dbutils.notebook.getContext.notebookPath.get
# MAGIC val logMessage = "Starting"
# MAGIC val notebookContext = dbutils.notebook.getContext().toJson
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read STG Data from Query Zone (CurrentState}

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS brtl.CUSTTABLE"""
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS brtl.PARTITIONS"""
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS brtl.COMMISSIONSALESGROUP"""
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS brtl.CUSTGROUP"""
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS brtl.DIRPARTYTABLE"""
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS brtl.LINEOFBUSINESS"""
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS brtl.SMMBUSRELSALESDISTRICTGROUP"""
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS brtl.DIRPARTYPOSTALADDRESSVIEW"""
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS brtl.CUSTCLASSIFICATIONGROUP"""
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS brtl.CUSTSTATISTICSGROUP"""
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS brtl.smmBusRelSegmentGroup"""
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS brtl.smmBusRelSubSegmentGroup"""
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS brtl.SALESPOOL"""
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS brtl.PAYMTERM"""
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS brtl.CUSTPAYMMODETABLE"""
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS brtl.DLVTERM"""
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS brtl.DLVMODE"""
spark.sql(sql)
sql = """
DROP TABLE IF EXISTS brtl.PRICEDISCGROUP"""
spark.sql(sql)


# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS brtl.CUSTTABLE
USING delta
LOCATION '{0}'
""".format(currentStateStagePath)
spark.sql(sql)
sql = """
CREATE TABLE IF NOT EXISTS brtl.PARTITIONS
USING delta
LOCATION '{0}'
""".format(fullPathPrefix + "/Query/CurrentState/"  + "PARTITIONS")
spark.sql(sql)

#sql = """
#CREATE TABLE IF NOT EXISTS brtl.COMMISSIONSALESGROUP
#USING delta
#LOCATION '{0}'
#""".format(fullPathPrefix + "/Query/CurrentState/"  + "COMMISSIONSALESGROUP")
#spark.sql(sql)

sql = """
CREATE TABLE IF NOT EXISTS brtl.CUSTGROUP
USING delta
LOCATION '{0}'
""".format(fullPathPrefix + "/Query/CurrentState/"  + "CUSTGROUP")
spark.sql(sql)
sql = """
CREATE TABLE IF NOT EXISTS brtl.DIRPARTYTABLE
USING delta
LOCATION '{0}'
""".format(fullPathPrefix + "/Query/CurrentState/"  + "DIRPARTYTABLE")
spark.sql(sql)

#sql = """
#CREATE TABLE IF NOT EXISTS brtl.LINEOFBUSINESS
#USING delta
#LOCATION '{0}'
#""".format(fullPathPrefix + "/Query/CurrentState/"  + "LINEOFBUSINESS")
#spark.sql(sql)

#sql = """
#CREATE TABLE IF NOT EXISTS brtl.SMMBUSRELSALESDISTRICTGROUP
#USING delta
#LOCATION '{0}'
#""".format(fullPathPrefix + "/Query/CurrentState/"  + "SMMBUSRELSALESDISTRICTGROUP")
#spark.sql(sql)

sql = """
CREATE TABLE IF NOT EXISTS brtl.DIRPARTYPOSTALADDRESSVIEW
USING delta
LOCATION '{0}'
""".format(fullPathPrefix + "/Query/CurrentState/"  + "DIRPARTYPOSTALADDRESSVIEW")
spark.sql(sql)

#sql = """
#CREATE TABLE IF NOT EXISTS brtl.CUSTCLASSIFICATIONGROUP
#USING delta
#LOCATION '{0}'
#""".format(fullPathPrefix + "/Query/CurrentState/"  + "CUSTCLASSIFICATIONGROUP")
#spark.sql(sql)

#sql = """
#CREATE TABLE IF NOT EXISTS brtl.CUSTSTATISTICSGROUP
#USING delta
#LOCATION '{0}'
#""".format(fullPathPrefix + "/Query/CurrentState/"  + "CUSTSTATISTICSGROUP")
#spark.sql(sql)

#sql = """
#CREATE TABLE IF NOT EXISTS brtl.smmBusRelSegmentGroup
#USING delta
#LOCATION '{0}'
#""".format(fullPathPrefix + "/Query/CurrentState/"  + "smmBusRelSegmentGroup")
#spark.sql(sql)

#sql = """
#CREATE TABLE IF NOT EXISTS brtl.smmBusRelSubSegmentGroup
#USING delta
#LOCATION '{0}'
#""".format(fullPathPrefix + "/Query/CurrentState/"  + "smmBusRelSubSegmentGroup")
#spark.sql(sql)

#sql = """
#CREATE TABLE IF NOT EXISTS brtl.SALESPOOL
#USING delta
#LOCATION '{0}'
#""".format(fullPathPrefix + "/Query/CurrentState/"  + "SALESPOOL")
#spark.sql(sql)

sql = """
CREATE TABLE IF NOT EXISTS brtl.PAYMTERM
USING delta
LOCATION '{0}'
""".format(fullPathPrefix + "/Query/CurrentState/"  + "PAYMTERM")
spark.sql(sql)

#sql = """
#CREATE TABLE IF NOT EXISTS brtl.CUSTPAYMMODETABLE
#USING delta
#LOCATION '{0}'
#""".format(fullPathPrefix + "/Query/CurrentState/"  + "CUSTPAYMMODETABLE")
#spark.sql(sql)

#sql = """
#CREATE TABLE IF NOT EXISTS brtl.DLVTERM
#USING delta
#LOCATION '{0}'
#""".format(fullPathPrefix + "/Query/CurrentState/"  + "DLVTERM")
#spark.sql(sql)

sql = """
CREATE TABLE IF NOT EXISTS brtl.DLVMODE
USING delta
LOCATION '{0}'
""".format(fullPathPrefix + "/Query/CurrentState/"  + "DLVMODE")
spark.sql(sql)
sql = """
CREATE TABLE IF NOT EXISTS brtl.PRICEDISCGROUP
USING delta
LOCATION '{0}'
""".format(fullPathPrefix + "/Query/CurrentState/"  + "PRICEDISCGROUP")
spark.sql(sql)



# COMMAND ----------

sql = """
SELECT *
FROM {0}
""".format(databaseStageTableName)
display(spark.sql(sql))

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP View if exists brtl.DimCustomerView

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE VIEW brtl.DimCustomerView 
# MAGIC AS
# MAGIC SELECT t1.RECID as CustomerKey,
# MAGIC        T1.DATAAREAID as CompanyCode,
# MAGIC        T1.ACCOUNTNUM AS CustomerCode,
# MAGIC        T4.NAME AS CustomerName,
# MAGIC        T3.CUSTGROUP AS CustomerGroupCode,
# MAGIC        T3.NAME AS CustomerGroup,
# MAGIC        --T8.CODE as ClassificationGroupCode,
# MAGIC        --T8.TXT as ClassificationGroup,
# MAGIC        STRING(case t4.ABC when 0 then 'None' when 1 then 'A' when 2 then 'B' when 3 then 'C' end) as ABCCode, 
# MAGIC        --T9.CUSTSTATISTICSGROUP AS StatisticsGroupCode,
# MAGIC        --T9.STATGROUPNAME as StatisticsGroup,
# MAGIC        --T5.LINEOFBUSINESSID AS LineofBusinessCode,
# MAGIC        --T5.DESCRIPTION AS LineofBusiness,
# MAGIC        --T10.SEGMENTID AS SegmentCode,
# MAGIC        --T10.DESCRIPTION AS Segment,
# MAGIC        --T11.SUBSEGMENTID AS SubsegmentCode,
# MAGIC        --T11.SUBSEGMENTDESCRIPTION AS Subsegment,
# MAGIC        --T6.SALESDISTRICTID as SalesDistrictCode,
# MAGIC        --T6.DESCRIPTION AS SalesDistrict,
# MAGIC        T1.CREDITMAX AS CreditLimit,
# MAGIC        T1.CREDITRATING as CreditRating,
# MAGIC        --T2.GROUPID AS SalesGroupCode,
# MAGIC        --T2.NAME AS SalesGroup,
# MAGIC        --T12.SALESPOOLID AS SalesPoolCode,
# MAGIC        --T12.NAME as SalesPool,
# MAGIC        T13.PAYMTERMID AS PaymentTermsCode,
# MAGIC        T13.DESCRIPTION as PaymenyTerms,
# MAGIC        --T14.PAYMMODE as MethodofPaymentCode,
# MAGIC        --T14.NAME as MethodofPayment,
# MAGIC        --T15.CODE as DeliveryTermsCode,
# MAGIC        --T15.TXT as DeliveryTerms, 
# MAGIC        T16.CODE as ModeofDeliveryCode,
# MAGIC        T16.TXT as ModeofDelivery, 
# MAGIC        T17.GROUPID AS PriceGroupCode,
# MAGIC        T17.NAME as PriceGroup, 
# MAGIC        T7.CITY AS CustomerCity,
# MAGIC        T7.STATE AS CustomerState,
# MAGIC        T7.ZIPCODE AS CustomerZipCode,
# MAGIC        T7.COUNTRYREGIONID AS CustomerCountryorRegion
# MAGIC FROM  brtl.CUSTTABLE T1 
# MAGIC INNER JOIN brtl.PARTITIONS p on p.RECID = T1.PARTITION and p.PARTITIONKEY = 'initial'
# MAGIC --LEFT JOIN brtl.COMMISSIONSALESGROUP T2 ON (T1.SALESGROUP=T2.GROUPID AND (T1.DATAAREAID = T2.DATAAREAID) AND (T1.PARTITION = T2.PARTITION)) 
# MAGIC LEFT JOIN brtl.CUSTGROUP T3 ON (T1.CUSTGROUP=T3.CUSTGROUP AND (T1.DATAAREAID = T3.DATAAREAID) AND (T1.PARTITION = T3.PARTITION)) 
# MAGIC LEFT JOIN brtl.DIRPARTYTABLE T4 ON (T1.PARTY=T4.RECID AND (T1.PARTITION = T4.PARTITION)) 
# MAGIC --LEFT JOIN brtl.LINEOFBUSINESS T5 ON (T1.LINEOFBUSINESSID=T5.LINEOFBUSINESSID AND (T1.DATAAREAID = T5.DATAAREAID) AND (T1.PARTITION = T5.PARTITION)) 
# MAGIC --LEFT JOIN brtl.SMMBUSRELSALESDISTRICTGROUP T6 ON (T1.SALESDISTRICTID=T6.SALESDISTRICTID AND (T1.DATAAREAID = T6.DATAAREAID) AND (T1.PARTITION = T6.PARTITION)) 
# MAGIC LEFT JOIN brtl.DIRPARTYPOSTALADDRESSVIEW T7 ON (((T7.ISPRIMARY=1) AND ((T7.VALIDTO>='2154-12-31T00:00:00') AND (T7.VALIDTO<='2154-12-31T23:59:59'))) AND (T4.RECID=T7.PARTY AND (T4.PARTITION = T7.PARTITION)))
# MAGIC --LEFT JOIN brtl.CUSTCLASSIFICATIONGROUP T8 on (T8.DATAAREAID = T1.DATAAREAID and T8.PARTITION = T1.PARTITION and T8.CODE = T1.CUSTCLASSIFICATIONID)
# MAGIC --LEFT JOIN brtl.CUSTSTATISTICSGROUP T9 on (T9.DATAAREAID = T1.DATAAREAID and T9.PARTITION = T1.PARTITION and T9.CUSTSTATISTICSGROUP = T1.STATISTICSGROUP)
# MAGIC --LEFT JOIN brtl.smmBusRelSegmentGroup T10 on (T10.DATAAREAID = T1.DATAAREAID and T10.PARTITION = T1.PARTITION and T10.SEGMENTID = T1.SEGMENTID)
# MAGIC --LEFT JOIN brtl.smmBusRelSubSegmentGroup T11 on (T11.DATAAREAID = T1.DATAAREAID and T11.PARTITION = T1.PARTITION  and T11.SEGMENTID = T1.SEGMENTID and T11.SUBSEGMENTID = T1.SUBSEGMENTID)
# MAGIC --LEFT JOIN brtl.SALESPOOL T12 on (T12.DATAAREAID = T1.DATAAREAID and T12.PARTITION = T1.PARTITION and T12.SALESPOOLID = T1.SALESPOOLID)
# MAGIC LEFT JOIN brtl.PAYMTERM T13 on (T13.DATAAREAID = T1.DATAAREAID and T13.PARTITION = T1.PARTITION and T13.PAYMTERMID = T1.PAYMTERMID)
# MAGIC --LEFT JOIN brtl.CUSTPAYMMODETABLE T14 on (T14.DATAAREAID = T1.DATAAREAID and T14.PARTITION = T1.PARTITION and T14.PAYMMODE = T1.PAYMMODE)
# MAGIC --LEFT JOIN brtl.DLVTERM T15 on (T15.DATAAREAID = T1.DATAAREAID and T15.PARTITION = T1.PARTITION and T15.CODE = T1.DLVTERM)
# MAGIC LEFT JOIN brtl.DLVMODE T16 on (T16.DATAAREAID = T1.DATAAREAID and T16.PARTITION = T1.PARTITION and T16.CODE = T1.DLVMODE)
# MAGIC LEFT JOIN brtl.PRICEDISCGROUP T17 on (T17.DATAAREAID = T1.DATAAREAID and T17.PARTITION = T1.PARTITION and T17.GROUPID = T1.PRICEGROUP and T17.MODULE=1 and T17.TYPE = 0)

# COMMAND ----------

sql="""
SELECT * FROM brtl.DimCustomerView
"""
stg_df=(spark.sql(sql))

# COMMAND ----------

display(stg_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Write Data to Query Zone (Enriched)

# COMMAND ----------

display(spark.sql("DROP TABLE IF EXISTS " + databaseTableName))

# COMMAND ----------

try:
  (stg_df \
   .write \
   .mode("overwrite") \
   .option("overwriteSchema", "true") \
   .format("delta") \
   .save(currentStateDestinationPath)
  )
  sql = """
  CREATE TABLE brtl.DimCustomer
  USING delta
  LOCATION '{0}'
  """.format(currentStateDestinationPath)
  spark.sql(sql)
except Exception as e:
  sourceName = "Query Zone Processing - Overwrite Delta Lake: Write to Query Zone"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

sql = """
SELECT * FROM {0}
""".format(databaseTableName)
dest_df = spark.sql(sql)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Overwrite data into Synapse DW from Current State

# COMMAND ----------

execsp = "TRUNCATE TABLE brtl.DimCustomer"
try:
  execute_sqldw_stored_procedure_no_results(execsp)
except:
  sourceName = "Destination Table does not exist"

# COMMAND ----------

if vacuumRetentionHours != '':
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", False)
  spark.sql("VACUUM " + databaseTableName + " RETAIN " + vacuumRetentionHours + " HOURS")
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", True)

# COMMAND ----------

blob_storage_account_name = adlsGen2StorageAccountName
blob_storage_container_name = "temp"

tempDir = "abfss://{}@{}.dfs.core.windows.net/".format(blob_storage_container_name, blob_storage_account_name) + dbutils.widgets.get("tableName")

# COMMAND ----------

sqlDwUrlSmall, connectionProperties = build_sqldw_jdbc_url_and_connectionProperties(sqldwservername, sqldwdatabasename, sqldwusername, sqldwpassword)

# COMMAND ----------

try:
  dest_df \
    .write \
    .format("com.databricks.spark.sqldw") \
    .mode("append") \
    .option("url", sqlDwUrlSmall) \
    .option("dbtable", fullyQualifiedTableName) \
    .option("useAzureMSI","True") \
    .option("maxStrLength",2048) \
    .option("tempdir", tempDir) \
    .save()
except Exception as e:
  sourceName = "Sanctioned Zone Processing - Load Azure SQL DW: Load Synapse SQL Data Warehouse"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Drop Temporary Tables and Views

# COMMAND ----------

dbutils.fs.rm(tempDir,True)

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP View if exists brtl.DimCustomerView

# COMMAND ----------

# MAGIC %md
# MAGIC #### Optimize and Vacuum Table

# COMMAND ----------

sql="""OPTIMIZE {0}""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

if vacuumRetentionHours != '':
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", False)
  spark.sql("VACUUM " + databaseTableName + " RETAIN " + vacuumRetentionHours + " HOURS")
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", True)

# COMMAND ----------

try:
  dbutils.fs.ls(badRecordsPath)
  sourceName = "Query Zone Processing - Overwrite Delta Lake: Bad Records"
  errorCode = "500"
  errorDescription = "Processing completed, but rows were written to badRecordsPath: {0}.  Raw records do not comply with the current schema for table {1}.{2}.".format(badRecordsPath, schemaName, tableName)
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise ValueError(errorDescription)
except:
  print("success")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Log Completion

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Completed
# MAGIC val logMessage = "Completed"
# MAGIC val notebookContext = ""
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

log_event_notebook_end(notebookExecutionLogKey=notebookExecutionLogKey, notebookStatus="SUCCEEDED", notebookName=notebookName, notebookExecutionGroupName="")
dbutils.notebook.exit("Succeeded")