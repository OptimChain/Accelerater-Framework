# MAGIC  
# MAGIC  
# MAGIC  
# MAGIC  
# MAGIC %md
# MAGIC # Query Zone Processing - Overwrite DIMInventoryConfig
# MAGIC ###### Author: Mike Sherrill 08/20/2020
# MAGIC 
# MAGIC Data Lake pattern for tables with change feeds of new or updated records.  Takes a file from the raw data path and applies the updates to the Query zone.      
# MAGIC 
# MAGIC #### Usage
# MAGIC Supply the parameters above and run the notebook.  
# MAGIC 
# MAGIC #### Prerequisites  
# MAGIC 
# MAGIC #### Details

# COMMAND ----------

# MAGIC %md
# MAGIC #### Initialize

# COMMAND ----------

# MAGIC %run ../Framework/Secrets_Databricks_Container

# COMMAND ----------

# MAGIC %run ../Framework/Neudesic_Framework_Functions

# COMMAND ----------

#dbutils.widgets.removeAll()


# COMMAND ----------

dbutils.widgets.text(name="containerName", defaultValue="brtl", label="Container Name")
dbutils.widgets.text(name="parentPipeLineExecutionLogKey", defaultValue="-1", label="Parent Pipeline Execution Log Key")

# filePath is to pick up the schema of an actual file in the case of subfolders

dbutils.widgets.text(name="numPartitions", defaultValue="8", label="Number of Partitions")
dbutils.widgets.text(name="schemaName", defaultValue="brtl", label="Schema Name")
dbutils.widgets.text(name="tableName", defaultValue="DIMInventoryConfig", label="Table Name")
dbutils.widgets.text(name="vacuumRetentionHours", defaultValue="", label="Vacuum Retention Hours")

parentPipeLineExecutionLogKey = dbutils.widgets.get("parentPipeLineExecutionLogKey")
containerName = dbutils.widgets.get("containerName")
fullPathPrefix = "abfss://" + containerName + "@" + adlsgen2storageaccountname + ".dfs.core.windows.net" 

numPartitions = int(dbutils.widgets.get("numPartitions"))

schemaName = dbutils.widgets.get("schemaName")
tableName = dbutils.widgets.get("tableName")
fullyQualifiedTableName = schemaName + "." + tableName

currentStateDestinationPath = fullPathPrefix + "/Query/Enriched/" + tableName

badRecordsPath = "/BadRecords/" + schemaName + "/" + tableName
fullBadRecordsPath = fullPathPrefix + badRecordsPath
databaseTableName = containerName + "." + tableName
vacuumRetentionHours = dbutils.widgets.get("vacuumRetentionHours")

# COMMAND ----------

notebookName = "Query Zone Processing - Overwrite DIMInventoryConfig"
notebookExecutionLogKey = log_event_notebook_start(notebookName,parentPipeLineExecutionLogKey)
print("Notebook Execution Log Key: {0}".format(notebookExecutionLogKey))

# COMMAND ----------

print("Schema Name: {0}".format(schemaName))
print("Table Name: {0}".format(tableName))
print("Fully Qualified Table Name: {0}".format(fullyQualifiedTableName))
print("Number of Partitions: {0}".format(numPartitions))
print("Current State Destination Path: {0}".format(currentStateDestinationPath))
print("Bad Records Path: {0}".format(fullBadRecordsPath))
print("Database Table Name: {0}".format(databaseTableName))

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Starting
# MAGIC val notebookPath = dbutils.notebook.getContext.notebookPath.get
# MAGIC val logMessage = "Starting"
# MAGIC val notebookContext = dbutils.notebook.getContext().toJson
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

CurrentStateECORESPRODUCTMASTERDIMENSIONVALUEPath = fullPathPrefix + "/Query/CurrentState/ECORESPRODUCTMASTERDIMENSIONVALUE"
CurrentStatePARTITIONSPath = fullPathPrefix + "/Query/CurrentState/PARTITIONS"
CurrentStateSQLDICTIONARYPath = fullPathPrefix + "/Query/CurrentState/SQLDICTIONARY"
CurrentStateECORESPRODUCTDIMENSIONATTRIBUTEPath = fullPathPrefix + "/Query/CurrentState/ECORESPRODUCTDIMENSIONATTRIBUTE"
CurrentStateECORESCONFIGURATIONPath = fullPathPrefix + "/Query/CurrentState/ECORESCONFIGURATION"
CurrentStateECORESPRODUCTPath = fullPathPrefix + "/Query/CurrentState/ECORESPRODUCT"
CurrentStateINVENTTABLEPath = fullPathPrefix + "/Query/CurrentState/INVENTTABLE"
CurrentStateECORESPRODUCTMASTERDIMVALUETRANSLATIONPath = fullPathPrefix + "/Query/CurrentState/ECORESPRODUCTMASTERDIMVALUETRANSLATION"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read Data from Query Zone (CurrentState}

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS brtl.ECORESPRODUCTMASTERDIMENSIONVALUE
"""
spark.sql(sql)

sql = """
DROP TABLE IF EXISTS brtl.PARTITIONS
"""
spark.sql(sql)

sql = """
DROP TABLE IF EXISTS brtl.SQLDICTIONARY
"""
spark.sql(sql)

sql = """
DROP TABLE IF EXISTS brtl.ECORESPRODUCTDIMENSIONATTRIBUTE
"""
spark.sql(sql)

sql = """
DROP TABLE IF EXISTS brtl.ECORESCONFIGURATION
"""
spark.sql(sql)

sql = """
DROP TABLE IF EXISTS brtl.ECORESPRODUCT
"""
spark.sql(sql)

sql = """
DROP TABLE IF EXISTS brtl.INVENTTABLE
"""
spark.sql(sql)

sql = """
DROP TABLE IF EXISTS brtl.ECORESPRODUCTMASTERDIMVALUETRANSLATION
"""
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format('brtl.ECORESPRODUCTMASTERDIMENSIONVALUE', CurrentStateECORESPRODUCTMASTERDIMENSIONVALUEPath)
spark.sql(sql)



# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format('brtl.PARTITIONS',CurrentStatePARTITIONSPath)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format('brtl.SQLDICTIONARY', CurrentStateSQLDICTIONARYPath)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format('brtl.ECORESPRODUCTDIMENSIONATTRIBUTE', CurrentStateECORESPRODUCTDIMENSIONATTRIBUTEPath)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format('brtl.ECORESCONFIGURATION', CurrentStateECORESCONFIGURATIONPath)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format('brtl.ECORESPRODUCT', CurrentStateECORESPRODUCTPath)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format('brtl.INVENTTABLE', CurrentStateINVENTTABLEPath)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format('brtl.ECORESPRODUCTMASTERDIMVALUETRANSLATION', CurrentStateECORESPRODUCTMASTERDIMVALUETRANSLATIONPath)
spark.sql(sql)

# COMMAND ----------

sql = """	
select coalesce(pmvt.RECID, erpmdv.RECID) as RecordId
	,lower(it.DATAAREAID) as CompanyCode
	,it.ITEMID as ItemCode
	,erc.NAME as InventoryConfigCode
	,nullif(pmvt.NAME,'') as InventoryConfig

from brtl.ECORESPRODUCTMASTERDIMENSIONVALUE erpmdv 
inner join brtl.PARTITIONS p on p.RECID = erpmdv.PARTITION and p.PARTITIONKEY = 'initial'
inner join brtl.SQLDICTIONARY sd on sd.NAME = 'ECORESCONFIGURATION' and sd.FIELDID = 0
inner join brtl.ECORESPRODUCTDIMENSIONATTRIBUTE erpda on erpda.RECID = erpmdv.CONFIGPRODUCTDIMENSIONATTRIBUTE and erpda.DIMENSIONTABLEID = sd.TABLEID
inner join brtl.ECORESCONFIGURATION erc on erc.RECID = erpmdv.CONFIGURATION
inner join brtl.ECORESPRODUCT erpm on erpm.RECID = erpmdv.ConfigPRODUCTMASTER
inner join brtl.INVENTTABLE it on it.PRODUCT = erpm.RECID
left join brtl.ECORESPRODUCTMASTERDIMVALUETRANSLATION pmvt on pmvt.PRODUCTMASTERDIMENSIONVALUE = erpmdv.RECID and pmvt.LANGUAGEID = 'en-us'
"""	
dest_df=spark.sql(sql)

# COMMAND ----------

display(dest_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Write Data to Query Zone (Enriched)

# COMMAND ----------

display(spark.sql("DROP TABLE IF EXISTS " + databaseTableName))

# COMMAND ----------

dbutils.fs.rm("dbfs:/user/hive/warehouse/brtl.db/DIMInventoryConfig", True)

# COMMAND ----------

try:
  queryTableExists = (spark.table(tableName) is not None)
  metadata = spark.sql("DESCRIBE DETAIL " + databaseTableName)
  format = metadata.collect()[0][0]
  if format != "delta":
    sourceName = "Query Zone Processing - Overwrite Delta Lake: Validate Query Table"
    errorCode = "400"
    errorDescription = "Table {0}.{1} exists but is not in Databricks Delta format.".format(schemaName, tableName)
    log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
    raise ValueError(errorDescription)
except:
  queryTableExists = False

# COMMAND ----------

queryTableExists

# COMMAND ----------

try:
  if queryTableExists:
    (dest_df \
      .write \
      .mode("overwrite") \
      .format("delta") \
      .save(currentStateDestinationPath)
    )
  else:
    (dest_df \
      .write \
      .mode("overwrite") \
      .format("delta") \
      .save(currentStateDestinationPath)
    )
    sql = """
    CREATE TABLE {0}
    USING delta
    LOCATION '{1}'
    """.format(databaseTableName, currentStateDestinationPath)
    spark.sql(sql)
except Exception as e:
  sourceName = "Query Zone Processing - Overwrite Delta Lake: Write to Query Zone"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

sql = """
SELECT * FROM {0}
""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Overwrite data into Synapse DW from Current State

# COMMAND ----------

execsp = "DELETE brtl.DIMInventoryConfig"
try:
  execute_sqldw_stored_procedure_no_results(execsp)
except:
  sourceName = "Destination Table does not exist"

# COMMAND ----------

if vacuumRetentionHours != '':
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", False)
  spark.sql("VACUUM " + databaseTableName + " RETAIN " + vacuumRetentionHours + " HOURS")
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", True)

# COMMAND ----------

blob_storage_account_name = adlsGen2StorageAccountName
blob_storage_container_name = "temp"

tempDir = "abfss://{}@{}.dfs.core.windows.net/".format(blob_storage_container_name, blob_storage_account_name) + dbutils.widgets.get("tableName")

# COMMAND ----------

sqlDwUrlSmall, connectionProperties = build_sqldw_jdbc_url_and_connectionProperties(sqldwservername, sqldwdatabasename, sqldwusername, sqldwpassword)

# COMMAND ----------

try:
  dest_df \
    .write \
    .format("com.databricks.spark.sqldw") \
    .mode("append") \
    .option("url", sqlDwUrlSmall) \
    .option("dbtable", fullyQualifiedTableName) \
    .option("useAzureMSI","True") \
    .option("maxStrLength",2048) \
    .option("tempdir", tempDir) \
    .save()
except Exception as e:
  sourceName = "Sanctioned Zone Processing - Load Azure SQL DW: Load Synapse SQL Data Warehouse"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Drop Temporary Tables and Views

# COMMAND ----------

dbutils.fs.rm(tempDir,True)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Optimize and Vacuum Table

# COMMAND ----------

sql="""OPTIMIZE {0}""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

if vacuumRetentionHours != '':
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", False)
  spark.sql("VACUUM " + databaseTableName + " RETAIN " + vacuumRetentionHours + " HOURS")
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", True)

# COMMAND ----------

try:
  dbutils.fs.ls(badRecordsPath)
  sourceName = "Query Zone Processing - Overwrite Delta Lake: Bad Records"
  errorCode = "500"
  errorDescription = "Processing completed, but rows were written to badRecordsPath: {0}.  Raw records do not comply with the current schema for table {1}.{2}.".format(badRecordsPath, schemaName, tableName)
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise ValueError(errorDescription)
except:
  print("success")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Log Completion

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Completed
# MAGIC val logMessage = "Completed"
# MAGIC val notebookContext = ""
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

log_event_notebook_end(notebookExecutionLogKey=notebookExecutionLogKey, notebookStatus="SUCCEEDED", notebookName=notebookName, notebookExecutionGroupName="")
dbutils.notebook.exit("Succeeded")