# MAGIC  
# MAGIC  
# MAGIC  
# MAGIC %md
# MAGIC # Query Zone Processing - Overwrite Market_Basket_Analysis
# MAGIC ###### Author: Shubham S 01/07/2021
# MAGIC 
# MAGIC Data Lake pattern for tables with change feeds of new or updated records.  Takes a file from the raw data path and applies the updates to the Query zone.      
# MAGIC 
# MAGIC #### Usage
# MAGIC Supply the parameters above and run the notebook.  
# MAGIC 
# MAGIC #### Prerequisites
# MAGIC 1. Raw Data must exist in the Data Lake /raw zone in JSON format.  

# COMMAND ----------

# MAGIC %md
# MAGIC #### Initialize

# COMMAND ----------

# MAGIC %run ../Framework/Secrets_Databricks_Container

# COMMAND ----------

# MAGIC %run ../Framework/Neudesic_Framework_Functions

# COMMAND ----------

dbutils.widgets.text(name="containerName", defaultValue="brtl", label="Container Name")
dbutils.widgets.text(name="parentPipeLineExecutionLogKey", defaultValue="-1", label="Parent Pipeline Execution Log Key")

# filePath is to pick up the schema of an actual file in the case of subfolders

dbutils.widgets.text(name="numPartitions", defaultValue="8", label="Number of Partitions")
dbutils.widgets.text(name="schemaName", defaultValue="brtl", label="Schema Name")
dbutils.widgets.text(name="tableName", defaultValue="Market_Basket_Analysis", label="Table Name")
dbutils.widgets.text(name="vacuumRetentionHours", defaultValue="", label="Vacuum Retention Hours")

parentPipeLineExecutionLogKey = dbutils.widgets.get("parentPipeLineExecutionLogKey")
containerName = dbutils.widgets.get("containerName")
fullPathPrefix = "abfss://" + containerName + "@" + adlsgen2storageaccountname + ".dfs.core.windows.net" 

numPartitions = int(dbutils.widgets.get("numPartitions"))

schemaName = dbutils.widgets.get("schemaName")
tableName = dbutils.widgets.get("tableName")
fullyQualifiedTableName = schemaName + "." + tableName

currentStateDestinationPath = fullPathPrefix + "/Query/Enriched/" + tableName

badRecordsPath = "/BadRecords/" + schemaName + "/" + tableName
fullBadRecordsPath = fullPathPrefix + badRecordsPath
databaseTableName = containerName + "." + tableName
vacuumRetentionHours = dbutils.widgets.get("vacuumRetentionHours")

# COMMAND ----------

stageTableName1 = "FCTSales"

databaseStageTableName1 = containerName + "." + stageTableName1

currentStateStagePath1 = fullPathPrefix + "/Query/Enriched/"  + stageTableName1

# COMMAND ----------

stageTableName2 = "DIMProduct"

databaseStageTableName2 = containerName + "." + stageTableName2

currentStateStagePath2 = fullPathPrefix + "/Query/Enriched/"  + stageTableName2

# COMMAND ----------

notebookName = "Query Zone Processing - Overwrite Market_Basket_Analysis"
notebookExecutionLogKey = log_event_notebook_start(notebookName,parentPipeLineExecutionLogKey)
print("Notebook Execution Log Key: {0}".format(notebookExecutionLogKey))

# COMMAND ----------

print("Schema Name: {0}".format(schemaName))
print("Stage Table Name: {0}".format(databaseStageTableName1))
print("Stage Table Name: {0}".format(databaseStageTableName2))
print("Table Name: {0}".format(tableName))
print("Fully Qualified Table Name: {0}".format(fullyQualifiedTableName))
print("Number of Partitions: {0}".format(numPartitions))
print("Current State Stage Path: {0}".format(currentStateStagePath1))
print("Current State Stage Path: {0}".format(currentStateStagePath2))
print("Current State Destination Path: {0}".format(currentStateDestinationPath))
print("Bad Records Path: {0}".format(fullBadRecordsPath))
print("Database Table Name: {0}".format(databaseTableName))

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Starting
# MAGIC val notebookPath = dbutils.notebook.getContext.notebookPath.get
# MAGIC val logMessage = "Starting"
# MAGIC val notebookContext = dbutils.notebook.getContext().toJson
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read STG Data from Query Zone (CurrentState}

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format(databaseStageTableName1)
spark.sql(sql)

# COMMAND ----------

sql = """
DROP TABLE IF EXISTS {0}
""".format(databaseStageTableName2)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE DATABASE IF NOT EXISTS {0}
""".format(containerName)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format(databaseStageTableName1, currentStateStagePath1)
spark.sql(sql)

# COMMAND ----------

sql = """
CREATE TABLE IF NOT EXISTS {0}
USING delta
LOCATION '{1}'
""".format(databaseStageTableName2, currentStateStagePath2)
spark.sql(sql)

# COMMAND ----------

stgViewName = "Market_Basket_Analysis"

sql="""
CREATE OR REPLACE VIEW  {0} AS
SELECT 
 FS.InvoiceDate AS Order_Date
,date_format(InvoiceDate, "E") AS Day_of_Week
,FS.InvoiceNumber AS Order_ID
,FS.Category AS Department
,DP.ECL_ItemStatus AS ProductStatus
,DP.ItemID AS Product_ID
,DP.ProductDesc AS Product_Name
FROM {1} FS
INNER JOIN {2} DP 
ON FS.ItemCode = DP.ItemID
WHERE 
      ProductDesc NOT LIKE '%Spirit Liter Tax%' 
  AND ProductDesc NOT LIKE '%Plastic Bag%'
  AND ProductDesc NOT LIKE '%Manufacturer Coupon%'
  AND ProductDesc NOT LIKE '%Prescriptions - Non-Taxable%'
  AND ProductDesc NOT LIKE '%CouponWA-15 off $50 Purchase%'
  AND ProductDesc NOT LIKE '%*DONATION* Salvation Army%'
  AND ProductDesc NOT LIKE '%Generic Non-Scannable%'
  AND ProductDesc NOT LIKE '%Everyday Card%'
  AND ProductDesc NOT LIKE '%SodaStrm Carbnatr Ex%'
  AND ProductDesc NOT LIKE '%SodaStrm Carbonator Ex%'
  AND ProductDesc NOT LIKE '%Nimble Payment%'
ORDER BY Order_ID, Product_ID
""".format(stgViewName,databaseStageTableName1,databaseStageTableName2)
display(spark.sql(sql))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exploratory Data Analysis

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM Market_Basket_Analysis

# COMMAND ----------

# DBTITLE 1,Orders by Day of Week
# MAGIC %sql
# MAGIC SELECT 
# MAGIC  COUNT(DISTINCT Order_ID) AS Total_Orders
# MAGIC ,Day_of_Week
# MAGIC FROM Market_Basket_Analysis
# MAGIC GROUP BY Day_of_Week
# MAGIC ORDER BY Total_Orders DESC

# COMMAND ----------

# DBTITLE 1,Top 10 Popular Items
# MAGIC %sql
# MAGIC SELECT 
# MAGIC COUNT(Order_ID) AS Orders, 
# MAGIC Product_Name AS Popular_Product
# MAGIC FROM Market_Basket_Analysis
# MAGIC GROUP BY Product_Name 
# MAGIC ORDER BY Orders DESC 
# MAGIC LIMIT 10

# COMMAND ----------

# DBTITLE 1,Top 10 Departments By Product Sold
# MAGIC %sql
# MAGIC SELECT
# MAGIC  Department
# MAGIC ,COUNT(DISTINCT Product_ID) AS Products
# MAGIC FROM Market_Basket_Analysis
# MAGIC GROUP BY 
# MAGIC Department
# MAGIC ORDER BY Products DESC
# MAGIC LIMIT 10

# COMMAND ----------

sql = """
SELECT *
FROM {0} 
""".format(stgViewName)
dest_df=spark.sql(sql)

# COMMAND ----------

order_products_prior, order_products_train =  dest_df.randomSplit([0.8, 0.2], 42)

# COMMAND ----------

order_products_prior.count()

# COMMAND ----------

order_products_train.count()

# COMMAND ----------

order_products_prior.createOrReplaceTempView("order_products_prior")
order_products_train.createOrReplaceTempView("order_products_train")

# COMMAND ----------

# DBTITLE 1,Organize Shopping Basket
# Organize the data by shopping basket
from pyspark.sql.functions import collect_set, col, count
rawData = spark.sql("SELECT Product_Name, Order_ID FROM order_products_train")
baskets = rawData.groupBy('Order_ID').agg(collect_set('Product_Name').alias('Items'))
baskets.createOrReplaceTempView('baskets')

# COMMAND ----------

# DBTITLE 1,View Shopping Baskets
display(baskets)

# COMMAND ----------

# DBTITLE 1,Train ML Model
# MAGIC %scala
# MAGIC import org.apache.spark.ml.fpm.FPGrowth
# MAGIC 
# MAGIC // Extract out the items 
# MAGIC val baskets_ds = spark.sql("SELECT Items FROM baskets").as[Array[String]].toDF("items")
# MAGIC 
# MAGIC // Use FPGrowth
# MAGIC val fpgrowth = new FPGrowth().setItemsCol("items").setMinSupport(0.001).setMinConfidence(0)
# MAGIC val model = fpgrowth.fit(baskets_ds)
# MAGIC 
# MAGIC // Calculate frequent itemsets
# MAGIC val mostPopularItemInABasket = model.freqItemsets
# MAGIC mostPopularItemInABasket.createOrReplaceTempView("mostPopularItemInABasket")

# COMMAND ----------

# DBTITLE 1,Most Frequent Itemsets
# MAGIC %sql
# MAGIC 
# MAGIC SELECT 
# MAGIC Items,Freq 
# MAGIC FROM mostPopularItemInABasket 
# MAGIC WHERE size(Items) > 2 
# MAGIC ORDER BY Freq DESC 
# MAGIC LIMIT 20

# COMMAND ----------

# DBTITLE 1,View Generated Association Rules
# MAGIC %scala
# MAGIC val ifThen = model.associationRules
# MAGIC ifThen.createOrReplaceTempView("ifThen")

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC SELECT 
# MAGIC Antecedent AS `Antecedent (if)`, 
# MAGIC Consequent AS `Consequent (THEN)`, 
# MAGIC Confidence 
# MAGIC FROM ifThen 
# MAGIC ORDER BY Confidence DESC 
# MAGIC LIMIT 20

# COMMAND ----------

sql = """
SELECT *
FROM {0} 
""".format("ifThen")
recommend_df=spark.sql(sql)

# COMMAND ----------

from pyspark.sql.functions import col, concat_ws
recommend_df = recommend_df.withColumn("antecedent",
   concat_ws(",",col("antecedent")))
recommend_df = recommend_df.withColumn("consequent",
   concat_ws(",",col("consequent")))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Write Data to Query Zone (Enriched)

# COMMAND ----------

display(spark.sql("DROP TABLE IF EXISTS " + databaseTableName))

# COMMAND ----------

dbutils.fs.rm("dbfs:/user/hive/warehouse/cgs.db/Market_Basket_Analysis", True)

# COMMAND ----------

try:
  queryTableExists = (spark.table(tableName) is not None)
  metadata = spark.sql("DESCRIBE DETAIL " + databaseTableName)
  format = metadata.collect()[0][0]
  if format != "delta":
    sourceName = "Query Zone Processing - Overwrite Delta Lake: Validate Query Table"
    errorCode = "400"
    errorDescription = "Table {0}.{1} exists but is not in Databricks Delta format.".format(schemaName, tableName)
    log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
    raise ValueError(errorDescription)
except:
  queryTableExists = False

# COMMAND ----------

queryTableExists

# COMMAND ----------

(recommend_df \
      .write \
      .mode("overwrite") \
      .format("delta") \
      .option("overWriteschema","true") \
      .save(currentStateDestinationPath)
)
sql = """
    CREATE TABLE {0}
    USING delta
    LOCATION '{1}'
""".format(databaseTableName, currentStateDestinationPath)
spark.sql(sql)

# COMMAND ----------

sql = """
SELECT * FROM {0}
""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Overwrite data into Synapse DW from Current State

# COMMAND ----------

execsp = "DELETE brtl.Market_Basket_Analysis"
try:
  execute_sqldw_stored_procedure_no_results(execsp)
except:
  sourceName = "Destination Table does not exist"

# COMMAND ----------

if vacuumRetentionHours != '':
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", False)
  spark.sql("VACUUM " + databaseTableName + " RETAIN " + vacuumRetentionHours + " HOURS")
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", True)

# COMMAND ----------

blob_storage_account_name = adlsGen2StorageAccountName
blob_storage_container_name = "temp"

tempDir = "abfss://{}@{}.dfs.core.windows.net/".format(blob_storage_container_name, blob_storage_account_name) + dbutils.widgets.get("tableName")

# COMMAND ----------

sqlDwUrlSmall, connectionProperties = build_sqldw_jdbc_url_and_connectionProperties(sqldwservername, sqldwdatabasename, sqldwusername, sqldwpassword)

# COMMAND ----------

try:
  recommend_df \
    .write \
    .format("com.databricks.spark.sqldw") \
    .mode("overwrite") \
    .option("url", sqlDwUrlSmall) \
    .option("dbtable", fullyQualifiedTableName) \
    .option("useAzureMSI","True") \
    .option("maxStrLength",2048) \
    .option("tempdir", tempDir) \
    .save()
except Exception as e:
  sourceName = "Sanctioned Zone Processing - Load Azure SQL DW: Load Synapse SQL Data Warehouse"
  errorCode = "400"
  errorDescription = e.message
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise(e)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Drop Temporary Tables and Views

# COMMAND ----------

dbutils.fs.rm(tempDir,True)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Optimize and Vacuum Table

# COMMAND ----------

sql="""OPTIMIZE {0}""".format(databaseTableName)
spark.sql(sql)

# COMMAND ----------

if vacuumRetentionHours != '':
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", False)
  spark.sql("VACUUM " + databaseTableName + " RETAIN " + vacuumRetentionHours + " HOURS")
  spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", True)

# COMMAND ----------

try:
  dbutils.fs.ls(badRecordsPath)
  sourceName = "Query Zone Processing - Overwrite Delta Lake: Bad Records"
  errorCode = "500"
  errorDescription = "Processing completed, but rows were written to badRecordsPath: {0}.  Raw records do not comply with the current schema for table {1}.{2}.".format(badRecordsPath, schemaName, tableName)
  log_event_notebook_error(notebookExecutionLogKey, sourceName, errorCode, errorDescription)
  raise ValueError(errorDescription)
except:
  print("success")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Log Completion

# COMMAND ----------

# MAGIC %scala
# MAGIC //Log Completed
# MAGIC val logMessage = "Completed"
# MAGIC log_to_framework_db_scala (notebookPath:String, logMessage:String, notebookContext:String) 

# COMMAND ----------

log_event_notebook_end(notebookExecutionLogKey=notebookExecutionLogKey, notebookStatus="SUCCEEDED", notebookName=notebookName, notebookExecutionGroupName="")
dbutils.notebook.exit("Succeeded")