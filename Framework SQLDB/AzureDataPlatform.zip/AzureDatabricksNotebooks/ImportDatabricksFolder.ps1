﻿# Run the Install only once
# Install-Module azure.databricks.cicd.tools
Import-Module azure.databricks.cicd.tools
#Install-Module Az.KeyVault

$VaultName = 'da-prd-wus2-analytics-kv'


$FrameworkBearerToken = (Get-AzKeyVaultSecret -vaultName $VaultName -name "DatabricksFrameworkAdminToken").SecretValueText
$ContainerBearerToken = (Get-AzKeyVaultSecret -vaultName $VaultName -name "DatabricksDataAdminToken").SecretValueText
$Region = "westus2"

#$FrameworkBearerToken 


Import-DatabricksFolder -BearerToken $FrameworkBearerToken -Region $Region -LocalPath 'C:\Users\mike.sherrill\source\repos\BRTL_DA_PLATFORM\AzureDataAnalytics\Solution\AzureDatabricksNotebooks\Framework' -DatabricksPath '/Framework'

Import-DatabricksFolder -BearerToken $ContainerBearerToken -Region $Region -LocalPath 'C:\Users\mike.sherrill\source\repos\BRTL_DA_PLATFORM\AzureDataAnalytics\Solution\AzureDatabricksNotebooks\Container\' -DatabricksPath '/brtl'

