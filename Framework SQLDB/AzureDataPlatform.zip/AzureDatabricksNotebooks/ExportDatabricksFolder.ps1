﻿# Run the Install only once
#Install-Module azure.databricks.cicd.tools -Scope CurrentUser
#Import-Module azure.databricks.cicd.tools
#Update-Module -Name azure.databricks.cicd.tools

$SubscriptionId = "a9736b54-71f3-4a19-bd5b-d3979b8ce04f"
Select-AzSubscription -SubscriptionId $SubscriptionId
Set-AzContext -Subscriptionid $SubscriptionId

$VaultName = 'da-dev-wus2-analytics-kv'
$Region = 'westus2'

#Connect-Databricks

$FrameworkBearerToken = (Get-AzKeyVaultSecret -vaultName $VaultName -name "DatabricksFrameworkAdminToken").SecretValueText
$ContainerBearerToken = (Get-AzKeyVaultSecret -vaultName $VaultName -name "DatabricksDataAdminToken").SecretValueText

Export-DatabricksFolder -BearerToken $FrameworkBearerToken -Region $Region -LocalOutputPath 'C:\Users\mike.sherrill\source\repos\BRTL_DA_PLATFORM\AzureDataAnalytics\Solution\AzureDatabricksNotebooks\Framework' -ExportPath '/Framework'

Export-DatabricksFolder -BearerToken $ContainerBearerToken -Region $Region -LocalOutputPath 'C:\Users\mike.sherrill\source\repos\BRTL_DA_PLATFORM\AzureDataAnalytics\Solution\AzureDatabricksNotebooks\Container' -ExportPath '/brtl'

