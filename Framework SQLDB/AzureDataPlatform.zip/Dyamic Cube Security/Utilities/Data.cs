﻿//This program will get the list of allowed attribute member values that a user is allowed to see in the cube.
//the "securitySPROC" stored procedure should return the member values that the user, as determined by the username,can see eg, a 
//column with a list of states in the "securityColumn".The "member" value specifies how the function should return the member value
//and should be put in as "[Dimension].[Hierarchy].[Level].[Attribute]".
//The output of the method will be in the format:
//{[Dimension].[Hierarchy].[Level].[Attribute].&[1],[Dimension].[Hierarchy].[Level].[Attribute].&[2],etc}


using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace NeudesicDynamicCubeSecurity
{
    public class Data
    {
        
        public string GetData(string sqlConnection, string ApplicationUserId, string DimensionName, string DimensionAttributeName, string DimensionMemberPermission, string member)
        {
            SqlConnection sqlConn = new SqlConnection(sqlConnection);
            SqlDataReader myReader = null;
            SqlCommand myCommand = new SqlCommand("EXEC uspGetDimensionMembers" + " '" + ApplicationUserId + "', '" + DimensionName + "', '" + DimensionAttributeName + "', '" + DimensionMemberPermission + "'", sqlConn);
            sqlConn.Open();
            myReader = myCommand.ExecuteReader();
            string output = "{";
            string securityColumn = "DimensionMemberName";

            if (myReader.HasRows)
            {
                while (myReader.Read())
                {
                    output = output + member + ".[" + myReader[securityColumn].ToString() + "],";
                }
            }

            output = output.Substring(0,output.Length-1) + "}";

            myReader.Close();
            myCommand.Dispose();
            sqlConn.Close();

            return output;
        }
    }
}
