-----------------------------------------------------------------------------------------
--
--  File:  scrViewBuilder.sql
--
--  Purpose:  Drop and Build Standard Views
--
--  Parameters:  None
-- 
--  Return Values:  None
--
--  Modification History:
--
--    Date		Author							Comment
--  ----------	------------------------------	-----------------------------------------
--  03/18/2016	Alan Campbell					Created for production.
--  10/02/2019  Mike Sherrill					Modified for Azure SQL DataWarehouse
--
-- Developed by Neudesic, LLC.
-----------------------------------------------------------------------------------------

CREATE TABLE #tbl
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
SELECT 
	ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) AS Sequence,
	o.name as 'TableName', 
	c.name as 'ColumnName'
  FROM 
	sysobjects o
	INNER JOIN syscolumns c on
		c.id = o.id
 WHERE 
	o.xtype = 'U' AND 
	o.name not like 'sys%' AND
	c.name not in ('IsCurrent','IsDeleted','EffectiveDate','ExpirationDate','ChangingHashbyte','HistoricalHashbyte','CreatedDate','ModifiedDate','InsertAuditKey','UpdateAuditKey')  
;

--select * from #tbl order by sequence

DECLARE @TableName AS varchar(max)
DECLARE @ColumnName AS varchar(max)
DECLARE @CurrentTableName AS varchar(max)

DECLARE @DropView AS varchar(max)
DECLARE @CreateView AS varchar(max)
DECLARE @Column AS varchar(max)
DECLARE @SQL AS varchar(max)

SET @TableName = ''
SET @ColumnName = ''
SET @CurrentTableName = ''

SET @DropView = ''
SET @CreateView = ''
SET @SQL = ''

PRINT 'SET ANSI_NULLS ON'
PRINT 'GO'
PRINT 'SET QUOTED_IDENTIFIER ON'
PRINT 'GO'

DECLARE @nbr_statements as INT = (SELECT COUNT(*) FROM #tbl)
DECLARE @i as INT = 1


WHILE   @i <= @nbr_statements
BEGIN
        SET @TableName = (SELECT TableName FROM #tbl WHERE Sequence = @i)
		SET @ColumnName = (SELECT ColumnName FROM #tbl WHERE Sequence = @i)
		
		IF (@CurrentTableName <> @TableName)
		BEGIN

			SET @DropView = char(13) + char(10) + 'IF EXISTS (SELECT name' + char(13) + char(10) + char(9) + char(9) + char(9) +
															   'FROM sysobjects' + char(13) + char(10) + char(9) + char(9) + char(9) +
															  'WHERE name = ' + char(39) + @TableName + 'View' + char(39) + char(13) + char(10) + char(9) + char(9) + char(9) +
																 'AND type = ' + char(39) + 'V' + char(39) + ')' + char(13) + char(10) +
												  'DROP VIEW ' + '[Definitive].[' + @TableName + 'View' + ']' + char(13) + char(10) + 'GO' + char(13) + char(10)
			SET @CreateView = 'CREATE VIEW ' + '[brtl].[' + @TableName + 'View' + ']' + ' AS' + char(13) + char(10) + 'SELECT ' + char(13) + char(10) + char(9) + ' ' + @ColumnName + char(13) + char(10) 
			
			IF @CurrentTableName <> ''
				SET @SQL = 'FROM ' + '[brtl].[' + @CurrentTableName + '] WITH (NOLOCK)' + char(13) + char(10) + 'GO' + char(13) + char(10) + @DropView + char(13) + char(10) + @CreateView
			ELSE
				SET @SQL = @DropView + char(13) + char(10) + @CreateView

		END
		ELSE
			BEGIN
				SET @Column = char(9) + ',' + @ColumnName 
				SET @SQL = @Column
			END

	PRINT @SQL

	SET @CurrentTableName = @TableName

SET     @i +=1
END

SET @SQL = 'FROM ' + '[brtl].[' + @CurrentTableName + '] NOLOCK' + char(13) + char(10) + 'GO'
PRINT @SQL

DROP TABLE #tbl
