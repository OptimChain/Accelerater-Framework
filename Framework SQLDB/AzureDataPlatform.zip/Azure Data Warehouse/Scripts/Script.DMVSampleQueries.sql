﻿-----------------------------------------------------------------------------------------
--
--  File:  Script.DMVSampleQueries.sql
--
--  Purpose:  Compiling a list of DMV Queries to evaluate workloads in Azure Data Warehouse.
--
--  Modification History:
--
--    Date		Author							Comment
--  ----------	------------------------------	-----------------------------------------
--  08/02/2018	Alan Campbell					Created.
--
--
-- Developed by Neudesic, LLC.
-----------------------------------------------------------------------------------------

-- Get the Distribution Schema for All Tables

SELECT 
	 o.name as TableName
	,ptdp.distribution_policy_desc
FROM sys.pdw_table_distribution_properties ptdp
	JOIN sys.objects o ON
		ptdp.object_id = o.object_ID

-- Sample Query

SELECT *
  FROM DimCustomer
OPTION (LABEL = 'CustomerQuery')

-- Get the Query Plan Steps

SELECT
	 step_index
	,operation_type
FROM sys.dm_pdw_exec_requests er
	JOIN sys.dm_pdw_request_steps rs ON
		er.request_id = rs.request_id
WHERE er.[label] = 'CustomerQuery'