﻿-----------------------------------------------------------------------------------------
--
--  File:  uspCreateStagingFromExternalTables.sql
--
--  Purpose:  Create Staging Tables from an External Table in Azure Data Warehouse.
--
--  Modification History:
--
--    Date		Author							Comment
--  ----------	------------------------------	-----------------------------------------
--  10/18/2017	Ken Mears						Created.
--	12/7/2017	Alan Campbell					Standardized for the Framework.
--  8/9/2018	Mike Sherrill					Updated for use in spg demo
--  9/17/2018	Alan Campbell					Updated to put these tables in the Retail
--                                              schema.
--
--
-- Developed by Neudesic, LLC.
-----------------------------------------------------------------------------------------

-- DROP PROC [dbo].[uspCreateStagingFromExternalTables]
-- Exec [uspCreateStagingFromExternalTables]

CREATE PROC [dbo].[uspCreateStagingFromExternalTables]
AS
BEGIN
    
    SET NOCOUNT ON
   
	IF OBJECT_ID('Retail.StgCustomer','U') IS NOT NULL DROP TABLE Retail.StgCustomer

	CREATE TABLE Retail.StgCustomer
	WITH
	(
		CLUSTERED INDEX(CustomerID),
		DISTRIBUTION = HASH(CustomerID)
	) AS
	SELECT *
	FROM Retail.StgCustomerExt
	PRINT '<<<CREATED StgCustomer TABLE>>>'

	EXEC [dbo].[uspCreateStatistics] 1, NULL,'Retail.StgCustomer'

	IF OBJECT_ID('Retail.StgProduct','U') IS NOT NULL DROP TABLE Retail.StgProduct

	CREATE TABLE Retail.StgProduct
	WITH
	(
		CLUSTERED INDEX(ProductID),
		DISTRIBUTION = HASH(ProductID)
	) AS
	SELECT *
	FROM Retail.StgProductExt
	PRINT '<<<CREATED StgProduct TABLE>>>'

	EXEC [dbo].[uspCreateStatistics] 1, NULL,'Retail.StgProduct'

	IF OBJECT_ID('Retail.StgSales','U') IS NOT NULL DROP TABLE Retail.StgSales

	CREATE TABLE Retail.StgSales
	WITH
	(
		CLUSTERED INDEX(SalesOrderNumber),
		DISTRIBUTION = HASH(SalesOrderNumber)
	) AS
	SELECT *
	FROM Retail.StgSalesExt
	PRINT '<<<CREATED StgSales TABLE>>>'

	EXEC [dbo].[uspCreateStatistics] 1, NULL,'Retail.StgSales'

	IF OBJECT_ID('Retail.StgStore','U') IS NOT NULL DROP TABLE Retail.StgStore

	CREATE TABLE Retail.StgStore
	WITH
	(
		CLUSTERED INDEX(StoreID),
		DISTRIBUTION = HASH(StoreID)
	) AS
	SELECT *
	FROM Retail.StgStoreExt
	PRINT '<<<CREATED StgStore TABLE>>>'

	EXEC [dbo].[uspCreateStatistics] 1, NULL,'Retail.StgStore'

END
GO
