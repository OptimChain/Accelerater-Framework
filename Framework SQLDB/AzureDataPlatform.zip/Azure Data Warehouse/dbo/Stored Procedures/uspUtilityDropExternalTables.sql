﻿-----------------------------------------------------------------------------------------
--
--  File:  uspUtlityDropExternalTables.sql
--
--  Purpose:  Drop External Tables as needed.
--
--  Modification History:
--
--    Date		Author							Comment
--  ----------	------------------------------	-----------------------------------------
--  10/18/2017	Ken Mears						Created.
--	12/7/2017	Alan Campbell					Standardized for the Framework.
--
--
-- Developed by Neudesic, LLC.
-----------------------------------------------------------------------------------------

-- DROP PROC [dbo].[uspUtilityDropExternalTables]
CREATE PROC [dbo].[uspUtilityDropExternalTables] AS
BEGIN
	DECLARE @SQL varchar(8000)
	SET @SQL = 'CREATE TABLE #stats_ddl
		WITH    (   DISTRIBUTION    = HASH([seq_nmbr])
				,   LOCATION        = USER_DB
				)
		AS
		WITH T
		AS
		(
		SELECT      t.[name]                        AS [table_name]
		,           s.[name]                        AS [table_schema_name]
		,           t.[object_id]                   AS [object_id]
		,           ROW_NUMBER()
					OVER(ORDER BY (SELECT NULL))    AS [seq_nmbr]
		FROM        sys.[tables] t
		JOIN        sys.[schemas] s         ON  t.[schema_id]       = s.[schema_id]
		LEFT JOIN    sys.[external_tables] e    ON    e.[object_id]        = t.[object_id]
		WHERE       e.[object_id] IS NOT NULL -- not an external table
		AND t.[name] LIKE ''Stg%''
		)
		SELECT  [table_schema_name]
		,       [table_name]
		,       [seq_nmbr]
		,       CAST(''DROP EXTERNAL TABLE ''+QUOTENAME(table_schema_name)+''.''+QUOTENAME(table_name)+'';'' AS VARCHAR(8000)) AS create_stat_ddl
		FROM T
		;

	DECLARE @i INT              = 1
	,       @t INT              = (SELECT COUNT(*) FROM #stats_ddl)
	,       @s NVARCHAR(4000)   = N''''
	;

	WHILE @i <= @t
	BEGIN
		SET @s=(SELECT DISTINCT create_stat_ddl FROM #stats_ddl WHERE seq_nmbr = @i);

		PRINT @s
		EXEC sp_executesql @s
		SET @i+=1;
	END

	DROP TABLE #stats_ddl;'
	EXECUTE(@SQL)
END
GO
