﻿CREATE PROC [dbo].[LoadDimTime] AS
BEGIN
	SET NOCOUNT ON;

	truncate table [brtl].[DimTime];

	declare @IntervalMins as int = 10;

	;with 
	TimeRange as
	(
		select cast(0 as int) as StartTime, 
			cast(86400 as int) as EndTime,
			cast(@IntervalMins*60 as int) as Interval
	),
	AllTimes AS 
	(
		select StartTime as [Time] 
		from TimeRange
		union all
		select [Time]+1
		from AllTimes 
		cross join TimeRange
		where ([Time]+1 < [EndTime])
	)     
	INSERT INTO [brtl].[DimTime]
	(
		[TimeKey],
		[Interval],
		[IntervalOrder],
		[Hour],
		[HourOrder]
	)
	select 
		tm.[Time] as [TimeKey],
		convert(nvarchar(5), dateadd(second, (tm.[Time]/tr.[Interval])*tr.[Interval], 0), 14) as [Interval],
		(tm.[Time]/tr.[Interval])*tr.[Interval] as [Interval Order],
		convert(nvarchar(5), dateadd(second, (tm.[Time]/3600)*3600, 0), 14) as [Hour],
		(tm.[Time]/3600)*3600 as [Hour Order]
	from AllTimes tm
	cross join TimeRange tr
	--option (maxrecursion 0);
END