﻿-----------------------------------------------------------------------------------------
--
--  File:  uspCreateExternalTables.sql
--
--  Purpose:  Check for existing External Tables and Create new External Table definitions 
--            for ADLS files.
--
--  Modification History:
--
--    Date		Author							Comment
--  ----------	------------------------------	-----------------------------------------
--  1/31/2018	Ken Mears						Created.
--	2/1/2018	Alan Campbell					Standardized for the Framework.
--  8/8/2018	Mike Sherrill					Updated for use in spg demo
--
-- Developed by Neudesic, LLC.
-----------------------------------------------------------------------------------------
--EXEC [uspCreateExternalTables] @Mode='Initial'

--DROP PROC [dbo].[uspCreateExternalTables]
ALTER PROC [dbo].[uspCreateExternalTables]
	@Mode [nvarchar](20)
AS
BEGIN
	DECLARE @SQL varchar(8000),
	@ADLSFolder nvarchar(50)

	IF (@Mode = 'Incremental')
		SET @ADLSFolder = ''
	ELSE
		SET @ADLSFolder = @Mode

	SET @SQL = 'IF EXISTS (SELECT * FROM sys.external_tables WHERE object_id = OBJECT_ID(''StgCustomerExt''))
		DROP EXTERNAL TABLE [StgCustomerExt]
	CREATE EXTERNAL TABLE [StgCustomerExt](
 		 [CustomerID] [nvarchar](20) NOT NULL
		,[CustomerFirstName] [nvarchar](50) NULL
		,[CustomerLastName] [nvarchar](50) NULL
		,[CustomerCity] [nvarchar](100) NOT NULL
		,[CustomerState] [nvarchar](50) NOT NULL
		,[CustomerBirthDate] [nvarchar] (20) NULL
		,[CustomerMaritalStatus] [nvarchar](50) NULL
		,[CustomerGender] [nvarchar](50) NULL
		,[CustomerYearlyIncome] [nvarchar](50) NULL
		,[CustomerEducation] [nvarchar](50) NULL
		,[CustomerOccupation] [nvarchar](50) NULL
		,[CustomerType] [nvarchar](50) NOT NULL
		,[CreatedDate] [nvarchar](20) NOT NULL
		,[UpdateDate] [nvarchar](20) NULL
	)
	WITH
	(
		LOCATION = ''/Demo/Retail/Customer/'+ LTRIM(RTRIM(@ADLSFolder)) + ''',
		DATA_SOURCE = AzureDataLakeStore,
		FILE_FORMAT = CSVFormatHeader
	);

	PRINT ''<<<CREATED StgCustomerExt TABLE>>>''

	IF EXISTS (SELECT * FROM sys.external_tables WHERE object_id = OBJECT_ID(''StgProductExt''))
		DROP EXTERNAL TABLE [StgProductExt]
	CREATE EXTERNAL TABLE [StgProductExt](
 		 [ProductID] [nvarchar](20) NULL
 		,[ProductLabel] [nvarchar](50) NULL
 		,[ProductName] [nvarchar](100) NULL
 		,[ProductSubcategoryName] [nvarchar](50) NULL
 		,[ProductCategoryName] [nvarchar](50) NULL
 		,[ProductColor] [nvarchar](50) NULL
 		,[ProductUnitCost] [nvarchar](50) NULL
 		,[ProductUnitPrice] [nvarchar](50) NULL
		,[CreatedDate] [nvarchar] (20) NULL
		,[UpdateDate] [nvarchar] (20) NULL
	)
	WITH
	(
		LOCATION = ''/Demo/Retail/Product/'+ LTRIM(RTRIM(@ADLSFolder)) + ''',
		DATA_SOURCE = AzureDataLakeStore,
		FILE_FORMAT = TABFormatHeader
	);
	PRINT ''<<<CREATED StgProductExt TABLE>>>''

	IF EXISTS (SELECT * FROM sys.external_tables WHERE object_id = OBJECT_ID(''StgStoreExt''))
		DROP EXTERNAL TABLE [StgStoreExt]
	CREATE EXTERNAL TABLE [StgStoreExt](
 		 [StoreID] [nvarchar](20) NULL
 		,[StoreName] [nvarchar](90) NULL
 		,[StoreCity] [nvarchar](100) NULL
 		,[StoreState] [nvarchar](50) NULL
 		,[StorePostalCode] [nvarchar](10) NULL
 		,[StoreType] [nvarchar](50) NULL
 		,[StoreStatus] [nvarchar](50) NULL
 		,[StoreSize] [int] NULL
		,[CreatedDate] [nvarchar] (20) NOT NULL
		,[UpdateDate] [nvarchar] (20) NULL
	)
	WITH
	(
		LOCATION = ''/Demo/Retail/Store/'+ LTRIM(RTRIM(@ADLSFolder)) + ''',
		DATA_SOURCE = AzureDataLakeStore,
		FILE_FORMAT = TABFormatHeader
	);
	PRINT ''<<<CREATED StgsStoreExt TABLE>>>''
	
	IF EXISTS (SELECT * FROM sys.external_tables WHERE object_id = OBJECT_ID(''StgSalesExt''))
	DROP EXTERNAL TABLE [StgSalesExt]
	CREATE EXTERNAL TABLE [StgSalesExt](
 		 [SalesOrderNumber] [nvarchar](50) NULL
 		,[SalesOrderLineNumber] [int] NULL
 		,[OrderDate] [nvarchar] (20) NULL
 		,[StoreID] [int] NULL
 		,[CustomerID] [int] NULL
 		,[ProductID] [int] NULL
 		,[SalesQuantity] [int] NULL
 		,[SalesUnitPrice] [money] NULL
 		,[SalesUnitCost] [money] NULL
 		,[SalesAmount] [money] NULL
		,[CreatedDate] [nvarchar] (20) NULL
		,[UpdateDate] [nvarchar] (20) NULL
	)
	WITH
	(
		LOCATION = ''/Demo/Retail/Sales/'+ LTRIM(RTRIM(@ADLSFolder)) + ''',
		DATA_SOURCE = AzureDataLakeStore,
		FILE_FORMAT = TABFormatHeader
	);
	PRINT ''<<<CREATED StgSalesExt TABLE>>>'''

	EXECUTE (@SQL)

END