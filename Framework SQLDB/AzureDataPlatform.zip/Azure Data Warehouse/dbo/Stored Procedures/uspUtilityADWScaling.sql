﻿-----------------------------------------------------------------------------------------
--
--  File:  uspUtlityADWScaling.sql
--
--  Purpose:  Scale Azure Data Warehouse DWUs.
--
--  Modification History:
--
--    Date		Author							Comment
--  ----------	------------------------------	-----------------------------------------
--  10/18/2017	Ken Mears						Created.
--	12/7/2017	Alan Campbell					Standardized for the Framework.
--
--
-- Developed by Neudesic, LLC.
-----------------------------------------------------------------------------------------

--DROP PROCEDURE [dbo].[uspUtilityADWScaling]
CREATE PROCEDURE [dbo].[uspUtilityADWScaling]
	@DWU varchar(10)
AS
EXEC ('ALTER DATABASE [neudesic-da-dev-eus2-adw] MODIFY (SERVICE_OBJECTIVE = ''' + @DWU + ''');')

/*
SELECT
    db.name [Database]
,   ds.edition [Edition]
,   ds.service_objective [Service Objective]
FROM
    sys.database_service_objectives ds
JOIN
    sys.databases db ON ds.database_id = db.database_id

SELECT *
FROM
    sys.dm_operation_status
WHERE
    resource_type_desc = 'Database'
AND 
    major_resource_id = 'e470-da-dev-eus2-adw'

EXEC sp_droprolemember 'xlargerc', 'loaduser'
EXEC sp_addrolemember 'largerc', 'loaduser'

/*
EXEC sp_droprolemember 'mediumrc', 'loaduser'
EXEC sp_droprolemember 'largerc', 'loaduser'
EXEC sp_droprolemember 'xlargerc', 'loaduser'
EXEC sp_addrolemember 'largerc', 'loaduser'
*/

DBCC SHOW_STATISTICS ([TCS.StgstbAdjType], tiAdjType)
*/
GO
