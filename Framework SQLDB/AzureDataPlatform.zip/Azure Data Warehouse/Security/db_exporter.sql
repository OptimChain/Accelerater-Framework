﻿--CREATE ROLE [db_exporter]
--    AUTHORIZATION [dbo];

