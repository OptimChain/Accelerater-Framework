﻿
--GO
--EXECUTE sp_addrolemember @rolename = N'xlargerc', @membername = N'srvc-DevLoaduser';


--GO
--EXECUTE sp_addrolemember @rolename = N'db_owner', @membername = N'srvc-DevLoaduser';

