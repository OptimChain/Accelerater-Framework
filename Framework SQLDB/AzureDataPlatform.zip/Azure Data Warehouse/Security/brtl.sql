﻿CREATE SCHEMA [brtl]
    AUTHORIZATION [dbo];











