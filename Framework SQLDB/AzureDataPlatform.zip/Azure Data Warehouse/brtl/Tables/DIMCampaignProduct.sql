﻿CREATE TABLE [brtl].[DIMCampaignProduct] (
    [CampaignKey]   INT             NULL,
    [Level1Name]    NVARCHAR (2048) NULL,
    [Level2Name]    NVARCHAR (2048) NULL,
    [Level3Name]    NVARCHAR (2048) NULL,
    [Level4Name]    NVARCHAR (2048) NULL,
    [Level5Name]    NVARCHAR (2048) NULL,
    [ProductKey]    BIGINT          NULL,
    [Category_Type] NVARCHAR (2048) NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

