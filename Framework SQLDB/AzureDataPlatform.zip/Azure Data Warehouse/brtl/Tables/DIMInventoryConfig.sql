﻿CREATE TABLE [brtl].[DIMInventoryConfig] (
    [RecordId]            BIGINT          NULL,
    [CompanyCode]         NVARCHAR (2048) NULL,
    [ItemCode]            NVARCHAR (2048) NULL,
    [InventoryConfigCode] NVARCHAR (2048) NULL,
    [InventoryConfig]     NVARCHAR (2048) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

