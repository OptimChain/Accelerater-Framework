﻿CREATE TABLE [brtl].[DIMOrganizationHierarchyStore] (
    [Level1]       BIGINT          NULL,
    [Organization] NVARCHAR (2048) NULL,
    [Level2]       BIGINT          NULL,
    [DistrictName] NVARCHAR (2048) NULL,
    [Level3]       BIGINT          NULL,
    [StoreName]    NVARCHAR (2048) NULL,
    [StoreNumber]  NVARCHAR (2048) NULL,
    [Active]       NVARCHAR (2048) NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

