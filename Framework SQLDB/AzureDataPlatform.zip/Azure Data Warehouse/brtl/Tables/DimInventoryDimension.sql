﻿CREATE TABLE [brtl].[DimInventoryDimension] (
    [InventoryDimensionKey] BIGINT          NULL,
    [CompanyCode]           NVARCHAR (2048) NULL,
    [InventoryDimensionId]  NVARCHAR (2048) NULL,
    [InventorySiteCode]     NVARCHAR (2048) NULL,
    [InventorySite]         NVARCHAR (2048) NULL,
    [WarehouseCode]         NVARCHAR (2048) NULL,
    [Warehouse]             NVARCHAR (2048) NULL,
    [SizeCode]              NVARCHAR (2048) NULL,
    [ColorCode]             NVARCHAR (2048) NULL,
    [StyleCode]             NVARCHAR (2048) NULL,
    [ConfigurationCode]     NVARCHAR (2048) NULL,
    [ItemBarCode]           NVARCHAR (2048) NOT NULL,
    [InventoryStatus]       NVARCHAR (2048) NULL,
    [InventoryLocation]     NVARCHAR (2048) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

