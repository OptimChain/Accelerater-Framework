﻿CREATE TABLE [brtl].[DimCostCenter] (
    [Key]         BIGINT          NULL,
    [Code]        NVARCHAR (2048) NULL,
    [Description] NVARCHAR (2048) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

