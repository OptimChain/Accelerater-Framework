﻿CREATE TABLE [brtl].[FCTTransferOrders] (
    [RecordID]              BIGINT          NULL,
    [TransferID]            NVARCHAR (2048) NULL,
    [LineNumber]            FLOAT (53)      NULL,
    [CompanyCode]           NVARCHAR (2048) NULL,
    [ItemCode]              NVARCHAR (2048) NULL,
    [InventoryDimensionId]  NVARCHAR (2048) NULL,
    [ShipDate]              NVARCHAR (2048) NULL,
    [ReceiveDate]           NVARCHAR (2048) NULL,
    [AutoCount]             BIGINT          NULL,
    [TransferUnit]          NVARCHAR (2048) NULL,
    [CrossDock]             NVARCHAR (2048) NOT NULL,
    [BuyerPush]             NVARCHAR (2048) NULL,
    [TransferStatus]        NVARCHAR (2048) NOT NULL,
    [WarehouseFrom]         NVARCHAR (2048) NULL,
    [WarehouseTo]           NVARCHAR (2048) NULL,
    [RequestedDeliveryDate] NVARCHAR (2048) NULL,
    [CreatedDate]           NVARCHAR (2048) NULL,
    [CategoryId]            BIGINT          NULL,
    [QTYTransfer]           FLOAT (53)      NULL,
    [QTYShipped]            FLOAT (53)      NULL,
    [QTYReceived]           FLOAT (53)      NULL,
    [WarehouseOnhand]       INT             NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

