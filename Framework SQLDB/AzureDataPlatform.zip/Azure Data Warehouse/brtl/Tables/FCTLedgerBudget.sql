﻿CREATE TABLE [brtl].[FCTLedgerBudget] (
    [CompanyKey]               BIGINT          NULL,
    [MainAccountKey]           NVARCHAR (2048) NOT NULL,
    [LedgerDimensionKey]       BIGINT          NULL,
    [CompanyCode]              NVARCHAR (2048) NOT NULL,
    [TransactionId]            NVARCHAR (2048) NOT NULL,
    [BudgetModel]              NVARCHAR (2048) NOT NULL,
    [BudgetSubModel]           NVARCHAR (2048) NOT NULL,
    [BudgetModelType]          NVARCHAR (2048) NOT NULL,
    [BudgetTransactionType]    NVARCHAR (2048) NOT NULL,
    [BudgetDate]               NVARCHAR (2048) NULL,
    [Quantity]                 INT             NOT NULL,
    [Price]                    FLOAT (53)      NULL,
    [Comments]                 NVARCHAR (2048) NOT NULL,
    [AccountingCurrencyAmount] FLOAT (53)      NULL,
    [BudgetType]               NVARCHAR (2048) NOT NULL,
    [MainAccount]              INT             NOT NULL,
    [Process_DateTime]         DATETIME2 (7)   NULL,
    [RetailChannelKey]         NVARCHAR (2048) NOT NULL,
    [Account_Type]             NVARCHAR (2048) NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

