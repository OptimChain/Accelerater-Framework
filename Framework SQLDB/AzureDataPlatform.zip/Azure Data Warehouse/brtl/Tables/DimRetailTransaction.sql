﻿CREATE TABLE [brtl].[DimRetailTransaction] (
    [RecordId]         BIGINT          NULL,
    [CompanyCode]      NVARCHAR (2048) NULL,
    [StoreCode]        NVARCHAR (2048) NULL,
    [TerminalCode]     NVARCHAR (2048) NULL,
    [TransactionCode]  NVARCHAR (2048) NULL,
    [ReceiptNumber]    NVARCHAR (2048) NULL,
    [StatementNumber]  NVARCHAR (2048) NULL,
    [StatementCode]    NVARCHAR (2048) NULL,
    [SalesOrderNumber] NVARCHAR (2048) NULL,
    [TransactionType]  NVARCHAR (2048) NULL,
    [EntryStatus]      NVARCHAR (2048) NULL,
    [Created_By]       NVARCHAR (2048) NULL,
    [Modified_By]      NVARCHAR (2048) NULL,
    [Last_Created]     NVARCHAR (2048) NULL,
    [Last_Modified]    NVARCHAR (2048) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

