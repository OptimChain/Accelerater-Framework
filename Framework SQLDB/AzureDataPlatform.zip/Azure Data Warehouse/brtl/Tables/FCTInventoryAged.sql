﻿CREATE TABLE [brtl].[FCTInventoryAged] (
    [CompanyCode]           NVARCHAR (2048) NULL,
    [CategoryId]            BIGINT          NULL,
    [InventorySiteCode]     NVARCHAR (2048) NULL,
    [WarehouseCode]         NVARCHAR (2048) NULL,
    [TransactionDate]       NVARCHAR (2048) NULL,
    [Quantity]              FLOAT (53)      NULL,
    [AvgUnitCost]           FLOAT (53)      NULL,
    [CostAmount]            FLOAT (53)      NULL,
    [InventorySite]         NVARCHAR (2048) NULL,
    [Warehouse]             NVARCHAR (2048) NULL,
    [InventoryDimensionKey] BIGINT          NULL,
    [DefaultDimensionKey]   INT             NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

