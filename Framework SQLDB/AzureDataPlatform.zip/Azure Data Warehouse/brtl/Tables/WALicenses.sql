﻿CREATE TABLE [brtl].[WALicenses] (
    [actiontaken]      NVARCHAR (2048) NULL,
    [birthyear]        NVARCHAR (2048) NULL,
    [ceduedate]        NVARCHAR (2048) NULL,
    [credentialnumber] NVARCHAR (2048) NULL,
    [credentialtype]   NVARCHAR (2048) NULL,
    [expirationdate]   NVARCHAR (2048) NULL,
    [firstissuedate]   NVARCHAR (2048) NULL,
    [firstname]        NVARCHAR (2048) NULL,
    [lastissuedate]    NVARCHAR (2048) NULL,
    [lastname]         NVARCHAR (2048) NULL,
    [middlename]       NVARCHAR (2048) NULL,
    [status]           NVARCHAR (2048) NULL,
    [dateLoaded]       DATETIME2 (7)   NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

