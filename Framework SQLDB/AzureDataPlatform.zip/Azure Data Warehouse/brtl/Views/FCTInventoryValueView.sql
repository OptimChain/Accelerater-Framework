﻿CREATE VIEW [brtl].[FCTInventoryValueView]
AS SELECT 

[RecordType] as[Record Type]
      ,[RecordId] as      [Record Id]
      ,[CompanyCode] as      [Company Code]
      ,[ItemCode] as      [Item Code]
      ,[InventoryDimensionId] as      [Inventory Dimension Id]
      ,Cast([TransactionDate]as date) as      [Transaction Date]
      ,[IssueStatus] as      [Issue Status]
      ,[ReceiptStatus] as      [Receipt Status]
      ,[TransactionType] as      [Transaction Type]
      ,[InventoryReference] as      [Inventory Reference]
      ,[UoM] as      [UoM]
      ,[Quantity] as      [Quantity]
      ,[CurrencyCode] as      [Currency Code]
      ,[CostAmount] as      [Cost Amount]
      ,[PostingType] as      [Posting Type]
      ,[VoucherNumber] as      [Voucher Number]
      ,[LedgerDimensionId] as      [Ledger Dimension Id]
      ,[DefaultDimensionId] as      [Default Dimension Id]
      ,[CategoryId] as      [Category Id]
      ,[TransferOrderRecordID] as      [Transfer Order Record ID]
      ,[Created_By] as      [Created_By]
      ,[Modified_By] as      [Modified_By]
      ,[Last_Created] as      [Last_Created]


  FROM [brtl].[FCTInventoryValue];