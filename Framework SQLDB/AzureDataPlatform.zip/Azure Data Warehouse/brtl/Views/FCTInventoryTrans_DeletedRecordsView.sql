﻿CREATE VIEW [brtl].[FCTInventoryTrans_DeletedRecordsView]
AS SELECT  
*
FROM [brtl].[FCTInventoryTrans_DeletedRecords] WITH (NOLOCK);