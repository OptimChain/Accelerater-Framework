﻿CREATE VIEW [brtl].[DIMSMMCampaignView]
AS SELECT  
*
FROM [brtl].[DIMSMMCampaign] WITH (NOLOCK);