﻿CREATE VIEW [brtl].[FCTInventoryJournalView]
AS SELECT  
*
FROM [brtl].[FCTInventoryJournal] WITH (NOLOCK);