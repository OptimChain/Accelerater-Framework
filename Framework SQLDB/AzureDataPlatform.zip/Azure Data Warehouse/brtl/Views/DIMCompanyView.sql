﻿CREATE VIEW [brtl].[DIMCompanyView]
AS SELECT
[CompanyKey] as [Company Key]
      ,[CompanyCode] as [Company Code]
      ,[CompanyName] as [Company Name]
      ,[Process_DateTime] as [Process_DateTime]
FROM [brtl].[DimCompany] WITH (NOLOCK);