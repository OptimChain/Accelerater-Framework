﻿CREATE VIEW [brtl].[DIMBusinessChannelView]
AS select [Key] as [_1_BusinessChannel Key],
       [Code] as [Business Channel Code],
    [Description] as [Business Channel Name]
    
from [brtl].[DimBusinessChannel]  WITH (NOLOCK);