﻿CREATE VIEW [brtl].[DIMTimeView]
AS SELECT
[Hour], 
[HourOrder] as [Hour Order] , 
[Interval],
[IntervalOrder] as [Interval Order] ,
[TimeKey],
[dateLoaded]
FROM [brtl].[DimTime] WITH (NOLOCK);