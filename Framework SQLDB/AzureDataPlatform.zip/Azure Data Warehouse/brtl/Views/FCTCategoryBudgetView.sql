﻿CREATE VIEW [brtl].[FCTCategoryBudgetView]
AS select 
[Level3], [COGS], [Date], [GP_Amt], [GP_Pct], [Sales], [ProcessedDate]
from [brtl].[FCTCategoryBudget];