﻿CREATE VIEW [brtl].[DIMCostCenterView]
AS select [Key] as [_3_CostCenter Key],
    
    [Code] as [Cost Center Code],
    [Description] as [Cost Center Name]
    
from [brtl].[DimCostCenter] WITH (NOLOCK);