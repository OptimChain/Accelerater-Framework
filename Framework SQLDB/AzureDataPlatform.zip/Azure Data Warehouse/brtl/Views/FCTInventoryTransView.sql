﻿CREATE VIEW [brtl].[FCTInventoryTransView]
AS SELECT  
*
FROM [brtl].[FCTInventoryTrans] WITH (NOLOCK);