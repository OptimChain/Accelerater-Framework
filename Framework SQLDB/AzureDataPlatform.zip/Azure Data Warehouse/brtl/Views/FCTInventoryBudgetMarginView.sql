﻿CREATE VIEW [brtl].[FCTInventoryBudgetMarginView]
AS SELECT  
*
FROM [brtl].[FCTInventoryBudgetMargin] WITH (NOLOCK);