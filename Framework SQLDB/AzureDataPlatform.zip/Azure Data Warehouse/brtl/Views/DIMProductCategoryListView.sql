﻿CREATE VIEW [brtl].[DIMProductCategoryListView]
AS SELECT  
*
FROM [brtl].[ProductCategoryList] NOLOCK;