﻿CREATE VIEW [brtl].[DIMCurrencyView]
AS select [$Table].[CurrencyKey] as [Currency Key],
    [$Table].[CurrencyCode] as [Currency Code],
    [$Table].[Currency] as [Currency],
    [$Table].[Process_DateTime] as [Date Loaded]
FROM [brtl].[DimCurrency] as [$Table] WITH (NOLOCK);