﻿CREATE VIEW [brtl].[DimCategoryItemView]
AS select 
[CategoryId] as [Category Id]
, [ProductNumber] as [Product Number]
, [ProductKey] as [Product Key]
, [CategoryHierarchyKey] as [Category Hierarchy Key]
from [brtl].[DimCategoryItem];