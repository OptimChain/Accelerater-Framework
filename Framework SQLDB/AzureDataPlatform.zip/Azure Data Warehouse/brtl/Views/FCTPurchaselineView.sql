﻿CREATE VIEW [brtl].[FCTPurchaseLineView]
AS SELECT  
*
FROM [brtl].[FCTPurchaseLine] WITH (NOLOCK);