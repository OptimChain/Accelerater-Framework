﻿CREATE VIEW [brtl].[DIMCampaignProductView] AS SELECT  
	C.CampaignKey, 
	CH.Level1Name, 
	CH.Level2Name, 
	CH.Level3Name, 
	CH.Level4Name, 
	CH.Level5Name, 
	CI.ProductKey, 
	'Campaign' AS Category_Type
FROM brtl.DimCampaigns C WITH (NOLOCK)
INNER JOIN brtl.DimCategoryItem CI WITH (NOLOCK) ON C.CampaignHierarchyKey = CI.CategoryHierarchyKey
INNER JOIN brtl.DimCategoryHierarchy CH WITH (NOLOCK) ON CI.ProductKey = CH.Product
UNION
SELECT 
	-1 AS Campaign_Key,
	CH.Level1Name, 
	CH.Level2Name, 
	CH.Level3Name, 
	CH.Level4Name, 
	CH.Level5Name, 
	PC.ProductKey
	,CASE 
		WHEN CH.Level1Name = 'All' THEN 'Retail' 
		WHEN CH.Level1Name LIKE 'S_%' THEN 'Supplemental' 
	ELSE 'Other' END AS Category_Type  
FROM brtl.DimProductCategory PC WITH (NOLOCK)
INNER JOIN  brtl.DimCategoryHierarchy CH WITH (NOLOCK) on CH.Product = PC.ProductKey
WHERE 
CH.Level2Name NOT IN (SELECT CampaignName FROM brtl.DimCampaigns WITH (NOLOCK));