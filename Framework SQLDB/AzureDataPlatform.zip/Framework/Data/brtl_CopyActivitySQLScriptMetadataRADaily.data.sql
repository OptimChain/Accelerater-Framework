DELETE [CopyActivityExecutionPlan]
   FROM [dbo].[CopyActivityExecutionPlan] p
  JOIN CopyActivitySink s
  on p.CopyActivitySinkKey = s.CopyActivitySinkKey
  JOIN CopyActivityExecutionGroup g on p.CopyActivityExecutionGroupKey = g.CopyActivityExecutionGroupKey
  where CopyActivityExecutionGroupName like
  '%RADaily Copy Process'

EXECUTE [dbo].[uspInsertSQLScriptCopyMetadata] @ContainerName = 'brtl',@CopyActivityExecutionGroupName = 'RADaily Copy Process',@CopyActivityDataName='AX_WHSINVENTTABLE',@CopyActivityParameterValue='AXConnectionString',@CopyActivityDataSQLScript=' select * from dbo.WHSINVENTTABLE WITH (NOLOCK)',@CopyActivityDataIncrementalSQLScript= ' select * from dbo.WHSINVENTTABLE WITH (NOLOCK)',@IsIncremental=0,@CopyActivityDataADLSFolderPath = '/Raw/AX/WHSINVENTTABLE',@CopyActivityDataADLSFileName ='WHSINVENTTABLE.json'
EXECUTE [dbo].[uspInsertSQLScriptCopyMetadata] @ContainerName = 'brtl',@CopyActivityExecutionGroupName = 'RADaily Copy Process',@CopyActivityDataName='AX_WHSUOMSEQGROUPLINE',@CopyActivityParameterValue='AXConnectionString',@CopyActivityDataSQLScript=' select * from dbo.WHSUOMSEQGROUPLINE WITH (NOLOCK)',@CopyActivityDataIncrementalSQLScript= ' select * from dbo.WHSUOMSEQGROUPLINE WITH (NOLOCK)',@IsIncremental=0,@CopyActivityDataADLSFolderPath = '/Raw/AX/WHSUOMSEQGROUPLINE',@CopyActivityDataADLSFileName ='WHSUOMSEQGROUPLINE.json'

EXECUTE [dbo].[uspInsertSQLScriptCopyMetadata] @ContainerName = 'brtl',@CopyActivityExecutionGroupName = 'RADaily Copy Process',@CopyActivityDataName='AX_INVENTITEMBARCODE',@CopyActivityParameterValue='AXConnectionString',@CopyActivityDataSQLScript=' select * from dbo.INVENTITEMBARCODE WITH (NOLOCK)',@CopyActivityDataIncrementalSQLScript= ' select * from dbo.INVENTITEMBARCODE WITH (NOLOCK)',@IsIncremental=0,@CopyActivityDataADLSFolderPath = '/Raw/AX/INVENTITEMBARCODE',@CopyActivityDataADLSFileName ='INVENTITEMBARCODE.json'

EXECUTE [dbo].[uspInsertSQLScriptCopyMetadata] @ContainerName = 'brtl',@CopyActivityExecutionGroupName = 'RADaily Copy Process',@CopyActivityDataName='AX_BARTELL_AVALPHYSQTYBYITEMSTOREVIEW',@CopyActivityParameterValue='BARTELL_AVALPHYSQTYBYITEMSTOREVIEW',@CopyActivityDataSQLScript='SELECT [SUMOFAVAILPHYSICAL]
      ,[DATAAREAID]
      ,[PARTITION]
      ,[RECID]
      ,[INVENTLOCATIONID]
      ,[DATAAREAID#2] as [DATAAREAID2]
      ,[PARTITION#2] as [PARTITION2]
      ,[ITEMID]
      ,[DATAAREAID#4] as [DATAAREAID4]
      ,[PARTITION#4] as [PARTITION4]
      ,[MAXOFRECID]
      ,[PARTITION#3] as [PARTITION3]
      ,[DATAAREAID#5] as [DATAAREAID5]
      ,[PARTITION#5] as [PARTITION5]
      ,[DATAAREAID#6] as [DATAAREAID6]
      ,[PARTITION#6] as [PARTITION6]
      ,[ITEMBARCODE]
      ,[MAXOFPRICE]
      ,[DATAAREAID#7] as [DATAAREAID7]
      ,[PARTITION#7] as [PARTITION7] FROM dbo.BARTELL_AVALPHYSQTYBYITEMSTOREVIEW WITH (NOLOCK)',@CopyActivityDataIncrementalSQLScript='SELECT [SUMOFAVAILPHYSICAL]
      ,[DATAAREAID]
      ,[PARTITION]
      ,[RECID]
      ,[INVENTLOCATIONID]
      ,[DATAAREAID#2] as [DATAAREAID2]
      ,[PARTITION#2] as [PARTITION2]
      ,[ITEMID]
      ,[DATAAREAID#4] as [DATAAREAID4]
      ,[PARTITION#4] as [PARTITION4]
      ,[MAXOFRECID]
      ,[PARTITION#3] as [PARTITION3]
      ,[DATAAREAID#5] as [DATAAREAID5]
      ,[PARTITION#5] as [PARTITION5]
      ,[DATAAREAID#6] as [DATAAREAID6]
      ,[PARTITION#6] as [PARTITION6]
      ,[ITEMBARCODE]
      ,[MAXOFPRICE]
      ,[DATAAREAID#7] as [DATAAREAID7]
      ,[PARTITION#7] as [PARTITION7] FROM dbo.BARTELL_AVALPHYSQTYBYITEMSTOREVIEW WITH (NOLOCK)',@IsIncremental=0,@CopyActivityDataADLSFolderPath = '/Raw/AX/BARTELL_AVALPHYSQTYBYITEMSTOREVIEW',@CopyActivityDataADLSFileName = 'BARTELL_AVALPHYSQTYBYITEMSTOREVIEW.json';

EXECUTE [dbo].[uspInsertSQLScriptCopyMetadata] @ContainerName = 'brtl',@CopyActivityExecutionGroupName = 'RADaily Copy Process',@CopyActivityDataName='AX_RETAILTRANSACTIONSALESTRANS',@CopyActivityParameterValue='AXConnectionString'
,@CopyActivityDataSQLScript='
   SELECT  CURRENCY
      ,TRANSACTIONID
      ,LINENUM
      ,RECEIPTID
      ,BARCODE
      ,ITEMID
      ,PRICE
      ,NETPRICE
      ,QTY
      ,TAXGROUP
      ,TRANSACTIONSTATUS
      ,DISCAMOUNT
      ,COSTAMOUNT
      ,TRANSDATE
      ,TRANSTIME
      ,SHIFT
      ,SHIFTDATE
      ,NETAMOUNT
      ,TAXAMOUNT
      ,DISCOFFERID
      ,STDNETPRICE
      ,DISCAMOUNTFROMSTDPRICE
      ,STATEMENTID
      ,CUSTACCOUNT
      ,SECTION
      ,SHELF
      ,STATEMENTCODE
      ,DISCGROUPID
      ,TRANSACTIONCODE
      ,STORE
      ,ITEMIDSCANNED
      ,KEYBOARDITEMENTRY
      ,PRICEINBARCODE
      ,PRICECHANGE
      ,WEIGHTMANUALLYENTERED
      ,LINEWASDISCOUNTED
      ,SCALEITEM
      ,WEIGHTITEM
      ,RETURNNOSALE
      ,ITEMCORRECTEDLINE
      ,LINKEDITEMNOTORIGINAL
      ,ORIGINALOFLINKEDITEMLIST
      ,TERMINALID
      ,ITEMPOSTINGGROUP
      ,TOTALROUNDEDAMOUNT
      ,COUNTER
      ,VARIANTID
      ,LINEDSCAMOUNT
      ,REPLICATED
      ,CUSTDISCAMOUNT
      ,INFOCODEDISCAMOUNT
      ,CUSTINVOICEDISCAMOUNT
      ,UNIT
      ,UNITQTY
      ,UNITPRICE
      ,TOTALDISCAMOUNT
      ,TOTALDISCPCT
      ,TOTALDISCINFOCODELINENUM
      ,PERIODICDISCTYPE
      ,PERIODICDISCAMOUNT
      ,DISCOUNTAMOUNTFORPRINTING
      ,STAFFID
      ,PERIODICDISCGROUP
      ,INVENTTRANSID
      ,INVENTDIMID
      ,PURCHID
      ,FILELOGID
      ,CONCESSIONCONTRACTID
      ,CONCESSIONSETTLEMENTID
      ,REPLICATIONCOUNTERFROMORIGIN
      ,CONSESSIONPARTPAYMENTID
      ,PRESCRIPTIONID
      ,COMMENT_
      ,PUMPID
      ,INVENTSTATUSSALES
      ,INVENTBATCHID
      ,GIFTCARD
      ,RFIDTAGID
      ,INVENTSERIALID
      ,RETURNTRANSACTIONID
      ,RETURNQTY
      ,TAXITEMGROUP
      ,ORIGINALTAXGROUP
      ,ORIGINALTAXITEMGROUP
      ,NETAMOUNTINCLTAX
      ,BLOCKQTY
      ,BUSINESSDATE
      ,CATALOG
      ,CATEGORYID
      ,CHANNEL
      ,DEFAULTDIMENSION
      ,DLVMODE
      ,ELECTRONICDELIVERYEMAIL
      ,ELECTRONICDELIVERYEMAILCONTENT
      ,INVENTLOCATIONID
      ,INVENTSITEID
      ,LINEMANUALDISCOUNTAMOUNT
      ,LINEMANUALDISCOUNTPERCENTAGE
      ,LISTINGID
      ,LOGISTICSPOSTALADDRESS
      ,LOYALTYDISCAMOUNT_RU
      ,LOYALTYDISCPCT_RU
      ,ORIGIN
      ,ORIGINALPRICE
      ,PERIODICPERCENTAGEDISCOUNT
      ,RECEIPTDATEREQUESTED
      ,RETURNLINENUM
      ,RETURNSTORE
      ,RETURNTERMINALID
      ,SHIPPINGDATEREQUESTED
      ,SKIPSALESLINE_RU
      ,ECL_GROUPHEALTHFLAG
      ,ECL_MANUALAGEVERIFIED
      ,ECL_MRN
      ,MODIFIEDDATETIME
      ,DEL_MODIFIEDTIME
      ,MODIFIEDBY
      ,MODIFIEDTRANSACTIONID
      ,CREATEDDATETIME
      ,DEL_CREATEDTIME
      ,CREATEDBY
      ,CREATEDTRANSACTIONID
      ,DATAAREAID
      ,RECVERSION
      ,PARTITION
      ,RECID
      ,ECL_AGGREGATEDFORK3S
      ,GIFTCARDBALANCE
      ,CUSTACCOUNTASYNC
      ,EXEMPT_IN
      ,HSNCODE_IN
      ,SERVICEACCOUNTINGCODE_IN
  FROM dbo.RETAILTRANSACTIONSALESTRANS WITH (NOLOCK)'
,@CopyActivityDataIncrementalSQLScript= 'SELECT  CURRENCY
      ,TRANSACTIONID
      ,LINENUM
      ,RECEIPTID
      ,BARCODE
      ,ITEMID
      ,PRICE
      ,NETPRICE
      ,QTY
      ,TAXGROUP
      ,TRANSACTIONSTATUS
      ,DISCAMOUNT
      ,COSTAMOUNT
      ,TRANSDATE
      ,TRANSTIME
      ,SHIFT
      ,SHIFTDATE
      ,NETAMOUNT
      ,TAXAMOUNT
      ,DISCOFFERID
      ,STDNETPRICE
      ,DISCAMOUNTFROMSTDPRICE
      ,STATEMENTID
      ,CUSTACCOUNT
      ,SECTION
      ,SHELF
      ,STATEMENTCODE
      ,DISCGROUPID
      ,TRANSACTIONCODE
      ,STORE
      ,ITEMIDSCANNED
      ,KEYBOARDITEMENTRY
      ,PRICEINBARCODE
      ,PRICECHANGE
      ,WEIGHTMANUALLYENTERED
      ,LINEWASDISCOUNTED
      ,SCALEITEM
      ,WEIGHTITEM
      ,RETURNNOSALE
      ,ITEMCORRECTEDLINE
      ,LINKEDITEMNOTORIGINAL
      ,ORIGINALOFLINKEDITEMLIST
      ,TERMINALID
      ,ITEMPOSTINGGROUP
      ,TOTALROUNDEDAMOUNT
      ,COUNTER
      ,VARIANTID
      ,LINEDSCAMOUNT
      ,REPLICATED
      ,CUSTDISCAMOUNT
      ,INFOCODEDISCAMOUNT
      ,CUSTINVOICEDISCAMOUNT
      ,UNIT
      ,UNITQTY
      ,UNITPRICE
      ,TOTALDISCAMOUNT
      ,TOTALDISCPCT
      ,TOTALDISCINFOCODELINENUM
      ,PERIODICDISCTYPE
      ,PERIODICDISCAMOUNT
      ,DISCOUNTAMOUNTFORPRINTING
      ,STAFFID
      ,PERIODICDISCGROUP
      ,INVENTTRANSID
      ,INVENTDIMID
      ,PURCHID
      ,FILELOGID
      ,CONCESSIONCONTRACTID
      ,CONCESSIONSETTLEMENTID
      ,REPLICATIONCOUNTERFROMORIGIN
      ,CONSESSIONPARTPAYMENTID
      ,PRESCRIPTIONID
      ,COMMENT_
      ,PUMPID
      ,INVENTSTATUSSALES
      ,INVENTBATCHID
      ,GIFTCARD
      ,RFIDTAGID
      ,INVENTSERIALID
      ,RETURNTRANSACTIONID
      ,RETURNQTY
      ,TAXITEMGROUP
      ,ORIGINALTAXGROUP
      ,ORIGINALTAXITEMGROUP
      ,NETAMOUNTINCLTAX
      ,BLOCKQTY
      ,BUSINESSDATE
      ,CATALOG
      ,CATEGORYID
      ,CHANNEL
      ,DEFAULTDIMENSION
      ,DLVMODE
      ,ELECTRONICDELIVERYEMAIL
      ,ELECTRONICDELIVERYEMAILCONTENT
      ,INVENTLOCATIONID
      ,INVENTSITEID
      ,LINEMANUALDISCOUNTAMOUNT
      ,LINEMANUALDISCOUNTPERCENTAGE
      ,LISTINGID
      ,LOGISTICSPOSTALADDRESS
      ,LOYALTYDISCAMOUNT_RU
      ,LOYALTYDISCPCT_RU
      ,ORIGIN
      ,ORIGINALPRICE
      ,PERIODICPERCENTAGEDISCOUNT
      ,RECEIPTDATEREQUESTED
      ,RETURNLINENUM
      ,RETURNSTORE
      ,RETURNTERMINALID
      ,SHIPPINGDATEREQUESTED
      ,SKIPSALESLINE_RU
      ,ECL_GROUPHEALTHFLAG
      ,ECL_MANUALAGEVERIFIED
      ,ECL_MRN
      ,MODIFIEDDATETIME
      ,DEL_MODIFIEDTIME
      ,MODIFIEDBY
      ,MODIFIEDTRANSACTIONID
      ,CREATEDDATETIME
      ,DEL_CREATEDTIME
      ,CREATEDBY
      ,CREATEDTRANSACTIONID
      ,DATAAREAID
      ,RECVERSION
      ,PARTITION
      ,RECID
      ,ECL_AGGREGATEDFORK3S
      ,GIFTCARDBALANCE
      ,CUSTACCOUNTASYNC
      ,EXEMPT_IN
      ,HSNCODE_IN
      ,SERVICEACCOUNTINGCODE_IN
  FROM dbo.RETAILTRANSACTIONSALESTRANS WITH (NOLOCK)
    WHERE Cast(MODIFIEDDATETIME as Date)  >= Cast(DATEADD(DD,@IncrementalDays,GETDATE()) as Date)',@IsIncremental=1,@CopyActivityDataADLSFolderPath = '/Raw/AX/RETAILTRANSACTIONSALESTRANS',@CopyActivityDataADLSFileName ='RETAILTRANSACTIONSALESTRANS.json'

EXECUTE [dbo].[uspInsertSQLScriptCopyMetadata] @ContainerName = 'brtl',@CopyActivityExecutionGroupName = 'RADaily Copy Process',@CopyActivityDataName='AX_RETAILTRANSACTIONTABLE',@CopyActivityParameterValue='AXConnectionString'
,@CopyActivityDataSQLScript='SELECT INVOICEID
      ,TRANSACTIONID
      ,TYPE
      ,RECEIPTID
      ,STORE
      ,TERMINAL
      ,STAFF
      ,TRANSDATE
      ,TRANSTIME
      ,SHIFT
      ,SHIFTDATE
      ,WRONGSHIFT
      ,INFOCODEDISCGROUP
      ,CUSTACCOUNT
      ,TRANSCODE
      ,SALESPAYMENTDIFFERENCE
      ,NETAMOUNT
      ,COSTAMOUNT
      ,GROSSAMOUNT
      ,PAYMENTAMOUNT
      ,DISCAMOUNT
      ,CUSTDISCAMOUNT
      ,TOTALDISCAMOUNT
      ,NUMBEROFITEMS
      ,AMOUNTTOACCOUNT
      ,ROUNDEDAMOUNT
      ,ENTRYSTATUS
      ,NUMBEROFINVOICES
      ,NUMBEROFITEMLINES
      ,STATEMENTCODE
      ,STATEMENTID
      ,REFUNDRECEIPTID
      ,INCOMEEXPENSEAMOUNT
      ,TOACCOUNT
      ,NUMBEROFPAYMENTLINES
      ,SALEISRETURNSALE
      ,COUNTER
      ,TIMEWHENTOTALPRESSED
      ,TIMEWHENTRANSCLOSED
      ,CURRENCY
      ,TRANSTABLEID
      ,OPENDRAWER
      ,REPLICATED
      ,INCLUDEDINSTATISTICS
      ,RETRIEVEDFROMRECEIPTID
      ,CREATEDONPOSTERMINAL
      ,POSTASSHIPMENT
      ,ITEMSPOSTED
      ,REPLICATIONCOUNTERFROMORIGIN
      ,SELLTOCONTACTID
      ,LOYALTYCARDID
      ,CUSTPURCHASEORDER
      ,COMMENT_
      ,SALESORDERAMOUNT
      ,SALESINVOICEAMOUNT
      ,RECEIPTEMAIL
      ,RECEIPTEMAILSENT
      ,EXCHRATE
      ,SALESORDERID
      ,BATCHID
      ,BATCHTERMINALID
      ,BUSINESSDATE
      ,CHANNEL
      ,CHANNELREFERENCEID
      ,CREATEDOFFLINE
      ,DEFAULTDIMENSION
      ,DESCRIPTION
      ,DLVMODE
      ,FISCALDOCUMENTID
      ,FISCALSERIALID
      ,INVENTLOCATIONID
      ,INVENTSITEID
      ,INVOICECOMMENT
      ,LOGISTICSPOSTALADDRESS
      ,LOYALTYDISCAMOUNT_RU
      ,ORIGIN
      ,RECEIPTDATEREQUESTED
      ,SHIPPINGDATEREQUESTED
      ,SKIPAGGREGATION
      ,TOTALMANUALDISCOUNTAMOUNT
      ,TOTALMANUALDISCOUNTPERCENTAGE
      ,MODIFIEDDATETIME
      ,DEL_MODIFIEDTIME
      ,MODIFIEDBY
      ,CREATEDDATETIME
      ,DEL_CREATEDTIME
      ,CREATEDBY
      ,DATAAREAID
      ,RECVERSION
      ,PARTITION
      ,RECID
      ,SUBTYPE
      ,CUSTEMAILADDRESS
      ,ECL_BCARINGEXPORTED
      ,LSCSIGCAPDATA3
      ,LSCSIGCAPDATA4
      ,LSCSIGCAPDATA1
      ,LSCSIGCAPDATA2
      ,CUSTOMERORDERMODE
      ,CUSTOMERORDERTYPE
      ,CUSTACCOUNTASYNC
      ,TAXCALCULATIONTYPE
  FROM dbo.RETAILTRANSACTIONTABLE WITH (NOLOCK)'
,@CopyActivityDataIncrementalSQLScript= 'SELECT INVOICEID
      ,TRANSACTIONID
      ,TYPE
      ,RECEIPTID
      ,STORE
      ,TERMINAL
      ,STAFF
      ,TRANSDATE
      ,TRANSTIME
      ,SHIFT
      ,SHIFTDATE
      ,WRONGSHIFT
      ,INFOCODEDISCGROUP
      ,CUSTACCOUNT
      ,TRANSCODE
      ,SALESPAYMENTDIFFERENCE
      ,NETAMOUNT
      ,COSTAMOUNT
      ,GROSSAMOUNT
      ,PAYMENTAMOUNT
      ,DISCAMOUNT
      ,CUSTDISCAMOUNT
      ,TOTALDISCAMOUNT
      ,NUMBEROFITEMS
      ,AMOUNTTOACCOUNT
      ,ROUNDEDAMOUNT
      ,ENTRYSTATUS
      ,NUMBEROFINVOICES
      ,NUMBEROFITEMLINES
      ,STATEMENTCODE
      ,STATEMENTID
      ,REFUNDRECEIPTID
      ,INCOMEEXPENSEAMOUNT
      ,TOACCOUNT
      ,NUMBEROFPAYMENTLINES
      ,SALEISRETURNSALE
      ,COUNTER
      ,TIMEWHENTOTALPRESSED
      ,TIMEWHENTRANSCLOSED
      ,CURRENCY
      ,TRANSTABLEID
      ,OPENDRAWER
      ,REPLICATED
      ,INCLUDEDINSTATISTICS
      ,RETRIEVEDFROMRECEIPTID
      ,CREATEDONPOSTERMINAL
      ,POSTASSHIPMENT
      ,ITEMSPOSTED
      ,REPLICATIONCOUNTERFROMORIGIN
      ,SELLTOCONTACTID
      ,LOYALTYCARDID
      ,CUSTPURCHASEORDER
      ,COMMENT_
      ,SALESORDERAMOUNT
      ,SALESINVOICEAMOUNT
      ,RECEIPTEMAIL
      ,RECEIPTEMAILSENT
      ,EXCHRATE
      ,SALESORDERID
      ,BATCHID
      ,BATCHTERMINALID
      ,BUSINESSDATE
      ,CHANNEL
      ,CHANNELREFERENCEID
      ,CREATEDOFFLINE
      ,DEFAULTDIMENSION
      ,DESCRIPTION
      ,DLVMODE
      ,FISCALDOCUMENTID
      ,FISCALSERIALID
      ,INVENTLOCATIONID
      ,INVENTSITEID
      ,INVOICECOMMENT
      ,LOGISTICSPOSTALADDRESS
      ,LOYALTYDISCAMOUNT_RU
      ,ORIGIN
      ,RECEIPTDATEREQUESTED
      ,SHIPPINGDATEREQUESTED
      ,SKIPAGGREGATION
      ,TOTALMANUALDISCOUNTAMOUNT
      ,TOTALMANUALDISCOUNTPERCENTAGE
      ,MODIFIEDDATETIME
      ,DEL_MODIFIEDTIME
      ,MODIFIEDBY
      ,CREATEDDATETIME
      ,DEL_CREATEDTIME
      ,CREATEDBY
      ,DATAAREAID
      ,RECVERSION
      ,PARTITION
      ,RECID
      ,SUBTYPE
      ,CUSTEMAILADDRESS
      ,ECL_BCARINGEXPORTED
      ,LSCSIGCAPDATA3
      ,LSCSIGCAPDATA4
      ,LSCSIGCAPDATA1
      ,LSCSIGCAPDATA2
      ,CUSTOMERORDERMODE
      ,CUSTOMERORDERTYPE
      ,CUSTACCOUNTASYNC
      ,TAXCALCULATIONTYPE
  FROM dbo.RETAILTRANSACTIONTABLE WITH (NOLOCK)
   WHERE Cast(MODIFIEDDATETIME as Date)  >= Cast(DATEADD(DD,@IncrementalDays,GETDATE()) as Date)',@IsIncremental=1,@CopyActivityDataADLSFolderPath = '/Raw/AX/RETAILTRANSACTIONTABLE',@CopyActivityDataADLSFileName ='RETAILTRANSACTIONTABLE.json'

EXECUTE [dbo].[uspInsertSQLScriptCopyMetadata] @ContainerName = 'brtl',@CopyActivityExecutionGroupName = 'RADaily Copy Process',@CopyActivityDataName='AX_PRICEDISCTABLE',@CopyActivityParameterValue='AXConnectionString',@CopyActivityDataSQLScript=' select * from dbo.PRICEDISCTABLE WITH (NOLOCK)',@CopyActivityDataIncrementalSQLScript= ' select * from dbo.PRICEDISCTABLE WITH (NOLOCK)',@IsIncremental=0,@CopyActivityDataADLSFolderPath = '/Raw/AX/PRICEDISCTABLE',@CopyActivityDataADLSFileName ='PRICEDISCTABLE.json'

EXECUTE [dbo].[uspInsertSQLScriptCopyMetadata] @ContainerName = 'brtl',@CopyActivityExecutionGroupName = 'RADaily Copy Process',@CopyActivityDataName='AX_CUSTVENDEXTERNALITEM',@CopyActivityParameterValue='AXConnectionString',@CopyActivityDataSQLScript=' select * from dbo.CUSTVENDEXTERNALITEM WITH (NOLOCK)',@CopyActivityDataIncrementalSQLScript= ' select * from dbo.CUSTVENDEXTERNALITEM WITH (NOLOCK)',@IsIncremental=0,@CopyActivityDataADLSFolderPath = '/Raw/AX/CUSTVENDEXTERNALITEM',@CopyActivityDataADLSFileName ='CUSTVENDEXTERNALITEM.json'
EXECUTE [dbo].[uspInsertSQLScriptCopyMetadata] @ContainerName = 'brtl',@CopyActivityExecutionGroupName = 'RADaily Copy Process',@CopyActivityDataName='AX_WHSINVENTTABLE',@CopyActivityParameterValue='AXConnectionString',@CopyActivityDataSQLScript=' select * from dbo.WHSINVENTTABLE WITH (NOLOCK)',@CopyActivityDataIncrementalSQLScript= ' select * from dbo.WHSINVENTTABLE WITH (NOLOCK)',@IsIncremental=0,@CopyActivityDataADLSFolderPath = '/Raw/AX/WHSINVENTTABLE',@CopyActivityDataADLSFileName ='WHSINVENTTABLE.json'
EXECUTE [dbo].[uspInsertSQLScriptCopyMetadata] @ContainerName = 'brtl',@CopyActivityExecutionGroupName = 'RADaily Copy Process',@CopyActivityDataName='AX_WHSUOMSEQGROUPLINE',@CopyActivityParameterValue='AXConnectionString',@CopyActivityDataSQLScript=' select * from dbo.WHSUOMSEQGROUPLINE WITH (NOLOCK)',@CopyActivityDataIncrementalSQLScript= ' select * from dbo.WHSUOMSEQGROUPLINE WITH (NOLOCK)',@IsIncremental=0,@CopyActivityDataADLSFolderPath = '/Raw/AX/WHSUOMSEQGROUPLINE',@CopyActivityDataADLSFileName ='WHSUOMSEQGROUPLINE.json'
EXECUTE [dbo].[uspInsertSQLScriptCopyMetadata] @ContainerName = 'brtl',@CopyActivityExecutionGroupName = 'RADaily Copy Process',@CopyActivityDataName='AX_WHSPHYSDIMUOM',@CopyActivityParameterValue='AXConnectionString',@CopyActivityDataSQLScript=' select * from dbo.WHSPHYSDIMUOM WITH (NOLOCK)',@CopyActivityDataIncrementalSQLScript= ' select * from dbo.WHSPHYSDIMUOM WITH (NOLOCK)',@IsIncremental=0,@CopyActivityDataADLSFolderPath = '/Raw/AX/WHSPHYSDIMUOM',@CopyActivityDataADLSFileName ='WHSPHYSDIMUOM.json'
EXECUTE [dbo].[uspInsertSQLScriptCopyMetadata] @ContainerName = 'brtl',@CopyActivityExecutionGroupName = 'RADaily Copy Process',@CopyActivityDataName='AX_RETAILINVENTLINKEDITEM',@CopyActivityParameterValue='AXConnectionString',@CopyActivityDataSQLScript=' select * from dbo.RETAILINVENTLINKEDITEM WITH (NOLOCK)',@CopyActivityDataIncrementalSQLScript= ' select * from dbo.RETAILINVENTLINKEDITEM WITH (NOLOCK)',@IsIncremental=0,@CopyActivityDataADLSFolderPath = '/Raw/AX/RETAILINVENTLINKEDITEM',@CopyActivityDataADLSFileName ='RETAILINVENTLINKEDITEM.json'

EXECUTE [dbo].[uspInsertSQLScriptCopyMetadata] @ContainerName = 'brtl',@CopyActivityExecutionGroupName = 'RADaily Copy Process',@CopyActivityDataName='AX_PDSAPPROVEDVENDORLIST',@CopyActivityParameterValue='AXConnectionString',@CopyActivityDataSQLScript=' select * from dbo.PDSAPPROVEDVENDORLIST WITH (NOLOCK)',@CopyActivityDataIncrementalSQLScript= ' select * from dbo.PDSAPPROVEDVENDORLIST WITH (NOLOCK)',@IsIncremental=0,@CopyActivityDataADLSFolderPath = '/Raw/AX/PDSAPPROVEDVENDORLIST',@CopyActivityDataADLSFileName ='PDSAPPROVEDVENDORLIST.json'


EXECUTE [dbo].[uspInsertSQLScriptCopyMetadata] @ContainerName = 'brtl',@CopyActivityExecutionGroupName = 'RADaily Copy Process',@CopyActivityDataName='AX_VENDTABLE',@CopyActivityParameterValue='AXConnectionString',@CopyActivityDataSQLScript=' select * from dbo.VENDTABLE WITH (NOLOCK)',@CopyActivityDataIncrementalSQLScript= ' select * from dbo.VENDTABLE WITH (NOLOCK)',@IsIncremental=0,@CopyActivityDataADLSFolderPath = '/Raw/AX/VENDTABLE',@CopyActivityDataADLSFileName ='VENDTABLE.json'
EXECUTE [dbo].[uspInsertSQLScriptCopyMetadata] @ContainerName = 'brtl',@CopyActivityExecutionGroupName = 'RADaily Copy Process',@CopyActivityDataName='AX_DIRPARTYTABLE',@CopyActivityParameterValue='AXConnectionString',@CopyActivityDataSQLScript='SELECT * FROM dbo.DIRPARTYTABLE WITH (NOLOCK) ',@CopyActivityDataIncrementalSQLScript='SELECT * FROM dbo.DIRPARTYTABLE WITH (NOLOCK) ',@IsIncremental=0,@CopyActivityDataADLSFolderPath = '/Raw/AX/DIRPARTYTABLE',@CopyActivityDataADLSFileName = 'DIRPARTYTABLE.json';
EXECUTE [dbo].[uspInsertSQLScriptCopyMetadata] @ContainerName = 'brtl',@CopyActivityExecutionGroupName = 'RADaily Copy Process',@CopyActivityDataName='AX_DIRPARTYPOSTALADDRESSVIEW',@CopyActivityParameterValue='AXConnectionString'
,@CopyActivityDataSQLScript='SELECT PARTY
      ,PARTYLOCATION
      ,ISPRIMARY
      ,ISLOCATIONOWNER
      ,ISPRIMARYTAXREGISTRATION
      ,PARTITION
      ,RECID
	  ,PARTITION#2 as PARTITION2
      ,LOCATIONNAME
      ,ADDRESS
      ,STREETNUMBER
      ,STREET
      ,CITY
      ,ZIPCODE
      ,STATE
      ,COUNTY
      ,COUNTRYREGIONID
      ,DISTRICT
      ,POSTBOX
      ,BUILDINGCOMPLIMENT
      ,TIMEZONE
	  ,CAST(LONGITUDE as decimal(29,4)) as LONGITUDE
      ,CAST(LATITUDE as decimal(29,4)) as LATITUDE
      ,LOCATION
      ,VALIDFROM
      ,VALIDTO
      ,COUNTRYCURRENCYCODE
      ,ISPRIVATE
      ,DISTRICTNAME
      ,POSTALADDRESS
      ,ISOCODE
      ,STREETID_RU
      ,HOUSEID_RU
      ,FLATID_RU
      ,BUILDING_RU
      ,APARTMENT_RU
      ,PRIVATEFORPARTY
      ,XRECID_LOGISTICSPOSTALADDRESS
      ,XRECVERSION_LOGISTICSPOSTALADDRESS
      ,CITYRECID
      ,BISEANCODEID
  FROM dbo.DIRPARTYPOSTALADDRESSVIEW WITH (NOLOCK)'
,@CopyActivityDataIncrementalSQLScript= ' SELECT PARTY
      ,PARTYLOCATION
      ,ISPRIMARY
      ,ISLOCATIONOWNER
      ,ISPRIMARYTAXREGISTRATION
      ,PARTITION
      ,RECID
	  ,PARTITION#2 as PARTITION2
      ,LOCATIONNAME
      ,ADDRESS
      ,STREETNUMBER
      ,STREET
      ,CITY
      ,ZIPCODE
      ,STATE
      ,COUNTY
      ,COUNTRYREGIONID
      ,DISTRICT
      ,POSTBOX
      ,BUILDINGCOMPLIMENT
      ,TIMEZONE
	  ,CAST(LONGITUDE as decimal(29,4)) as LONGITUDE
      ,CAST(LATITUDE as decimal(29,4)) as LATITUDE
      ,LOCATION
      ,VALIDFROM
      ,VALIDTO
      ,COUNTRYCURRENCYCODE
      ,ISPRIVATE
      ,DISTRICTNAME
      ,POSTALADDRESS
      ,ISOCODE
      ,STREETID_RU
      ,HOUSEID_RU
      ,FLATID_RU
      ,BUILDING_RU
      ,APARTMENT_RU
      ,PRIVATEFORPARTY
      ,XRECID_LOGISTICSPOSTALADDRESS
      ,XRECVERSION_LOGISTICSPOSTALADDRESS
      ,CITYRECID
      ,BISEANCODEID
  FROM dbo.DIRPARTYPOSTALADDRESSVIEW WITH (NOLOCK)'
,@IsIncremental=0,@CopyActivityDataADLSFolderPath = '/Raw/AX/DIRPARTYPOSTALADDRESSVIEW',@CopyActivityDataADLSFileName ='DIRPARTYPOSTALADDRESSVIEW.json'

EXECUTE [dbo].[uspInsertSQLScriptCopyMetadata] @ContainerName = 'brtl',@CopyActivityExecutionGroupName = 'RADaily Copy Process',@CopyActivityDataName='AX_DIRPARTYLOCATIONROLESVIEW',@CopyActivityParameterValue='AXConnectionString',
@CopyActivityDataSQLScript='SELECT [PARTY]
      ,[LOCATION]
      ,[PARTITION]
      ,[RECID]
      ,[PARTITION#2] as [PARTITION2]
      ,[LOCATIONROLE]
      ,[VALIDFROM]
      ,[VALIDTO]
  FROM [dbo].[DIRPARTYLOCATIONROLESVIEW] WITH (NOLOCK)'
  ,@CopyActivityDataIncrementalSQLScript='SELECT [PARTY]
      ,[LOCATION]
      ,[PARTITION]
      ,[RECID]
      ,[PARTITION#2] as [PARTITION2]
      ,[LOCATIONROLE]
      ,[VALIDFROM]
      ,[VALIDTO]
  FROM [dbo].[DIRPARTYLOCATIONROLESVIEW] WITH (NOLOCK)',@IsIncremental=0,@CopyActivityDataADLSFolderPath = '/Raw/AX/DIRPARTYLOCATIONROLESVIEW',@CopyActivityDataADLSFileName = 'DIRPARTYLOCATIONROLESVIEW.json';

EXECUTE [dbo].[uspInsertSQLScriptCopyMetadata] @ContainerName = 'brtl',@CopyActivityExecutionGroupName = 'RADaily Copy Process',@CopyActivityDataName='AX_LOGISTICSLOCATIONROLE',@CopyActivityParameterValue='AXConnectionString',@CopyActivityDataSQLScript='SELECT * FROM dbo.LOGISTICSLOCATIONROLE WITH (NOLOCK)',@CopyActivityDataIncrementalSQLScript='SELECT * FROM dbo.LOGISTICSLOCATIONROLE WITH (NOLOCK)',@IsIncremental=0,@CopyActivityDataADLSFolderPath = '/Raw/AX/LOGISTICSLOCATIONROLE',@CopyActivityDataADLSFileName = 'LOGISTICSLOCATIONROLE.json';
EXECUTE [dbo].[uspInsertSQLScriptCopyMetadata] @ContainerName = 'brtl',@CopyActivityExecutionGroupName = 'RADaily Copy Process',@CopyActivityDataName='AX_VendGroup',@CopyActivityParameterValue='AXConnectionString',@CopyActivityDataSQLScript=' select * from dbo.VendGroup WITH (NOLOCK)',@CopyActivityDataIncrementalSQLScript= ' select * from dbo.VendGroup WITH (NOLOCK)',@IsIncremental=0,@CopyActivityDataADLSFolderPath = '/Raw/AX/VendGroup',@CopyActivityDataADLSFileName ='VendGroup.json'

EXECUTE [dbo].[uspInsertSQLScriptCopyMetadata] @ContainerName = 'brtl',@CopyActivityExecutionGroupName = 'RADaily Copy Process',@CopyActivityDataName='AX_LOGISTICSELECTRONICADDRESS',@CopyActivityParameterValue='AXConnectionString',@CopyActivityDataSQLScript=' select * from dbo.LOGISTICSELECTRONICADDRESS WITH (NOLOCK)',@CopyActivityDataIncrementalSQLScript= ' select * from dbo.LOGISTICSELECTRONICADDRESS WITH (NOLOCK)',@IsIncremental=0,@CopyActivityDataADLSFolderPath = '/Raw/AX/LOGISTICSELECTRONICADDRESS',@CopyActivityDataADLSFileName ='LOGISTICSELECTRONICADDRESS.json'


