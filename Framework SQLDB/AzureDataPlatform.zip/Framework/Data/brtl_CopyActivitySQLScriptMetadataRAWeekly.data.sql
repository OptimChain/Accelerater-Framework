DELETE [CopyActivityExecutionPlan]
   FROM [dbo].[CopyActivityExecutionPlan] p
  JOIN CopyActivitySink s
  on p.CopyActivitySinkKey = s.CopyActivitySinkKey
  JOIN CopyActivityExecutionGroup g on p.CopyActivityExecutionGroupKey = g.CopyActivityExecutionGroupKey
  where CopyActivityExecutionGroupName like
  'RAWeekly Copy Process'

