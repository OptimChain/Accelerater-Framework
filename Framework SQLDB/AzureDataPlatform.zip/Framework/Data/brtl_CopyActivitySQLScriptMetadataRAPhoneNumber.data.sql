
--Copy Metadata
--McKesson
EXECUTE [dbo].[uspInsertSQLScriptCopyMetadata] @ContainerName = 'brtl',@CopyActivityExecutionGroupName = 'RAPhoneNumber Copy Process',@CopyActivityDataName='RAPhoneNumber_PATIENT_PHONE',@CopyActivityParameterValue='AXConnectionString',@CopyActivityDataSQLScript='SELECT * FROM TREXONE_DW_DATA.PATIENT_PHONE WHERE EFF_END_DATE >= TO_TIMESTAMP (''2999-12-31 00:00:00'',''YYYY-MM-DD HH24:MI:SS'') AND PATP_USAGE = 1 AND PATP_PHONE_USAGE = 1',@CopyActivityDataIncrementalSQLScript= 'SELECT * FROM TREXONE_DW_DATA.PATIENT_PHONE WHERE PATP_USAGE = 1',@IsIncremental=0,@CopyActivityDataADLSFolderPath = '/Raw/McKesson/PATIENT_PHONE',@CopyActivityDataADLSFileName ='PATIENT_PHONE.json'

--Notebook Metadata
--Ingest
EXECUTE [dbo].[uspInsertNotebookMetadata] @NotebookZone = 'Ingest', @ContainerExecutionGroupName = 'RAPhoneNumber' ,@ContainerName = 'brtl' ,@DataFactoryName = 'TBD' ,@NotebookName =   'RaPhoneNumber_PATIENT_PHONE'  ,@NotebookOrder = '10'  ,@NumPartitions = '16' ,@QueryZoneSchemaName = 'brtl' ,@QueryZoneTableName = 'PATIENT_PHONE' ,@ExternalDataPath = '' ,@RawDataPath = '/Raw/McKesson/PATIENT_PHONE' ,@QueryZoneNotebookPath='/Framework/Query Zone Processing - Overwrite Delta Lake',@PrimaryKeyColumns = '';
--Export
EXECUTE [dbo].[uspInsertNotebookMetadata] @NotebookZone = 'Export', @ContainerExecutionGroupName = 'RAPhoneNumber' ,@ContainerName = 'brtl' ,@DataFactoryName = 'TBD' ,@NotebookName = 'RAPhoneNumber_PatientPhoneNumber'  ,@NotebookOrder = '10'  ,@NumPartitions = '16' ,@QueryZoneSchemaName = 'brtl' ,@QueryZoneTableName = 'PatientPhoneNumber',@RawDataPath = '',@ExternalDataPath = '/Summary/Export/RiteAid/' ,@QueryZoneNotebookPath = '/Export/Query Zone Processing - Export Incremental PatientPhoneNumber', @PrimaryKeyColumns = '' ,@TimeStampColumns = 'Full' ,@SummaryZoneNotebookPath='/Framework/Summary Zone Processing - Export TXT Pipe NoSpaces',@SanctionedZoneNotebookPath='',@VacuumRetentionHours=168;

--SFTP
EXECUTE dbo.uspInsertFileSystemCopyMetadata @ContainerName = 'brtl', @CopyActivityExecutionGroupName = 'RAPhoneNumber_Export Copy Process',@CopyActivityDataName = 'PatientPhoneNumber', @CopyActivityParameterValue = 'AXConnectionString', @CopyActivityDataFileSystemFolderPath = '/RiteAid_TEST/RX/PhoneNumbers/Outbound', @CopyActivityDataFileSystemFileName = '*.txt', @CopyActivityDataADLSFolderPath = 'Summary\Export\RiteAid\PatientPhoneNumber', @CopyActivityDataADLSFileName = '*'
