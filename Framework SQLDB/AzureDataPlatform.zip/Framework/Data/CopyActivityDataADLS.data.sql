﻿


SET IDENTITY_INSERT  dbo.CopyActivityDataADLS ON;

MERGE dbo.CopyActivityDataADLS AS t
  USING (
   VALUES
-- AX
(100,'AX_INVENTJOURNALTABLE','/Raw/AX/INVENTJOURNALTABLE','INVENTJOURNALTABLE.json',1,Getdate(),Getdate(),Getdate(),Current_user),
(101,'AX_INVENTJOURNALTRANS','/Raw/AX/INVENTJOURNALTRANS','INVENTJOURNALTRANS.json',1,Getdate(),Getdate(),Getdate(),Current_user),
(102,'AX_InventTransferTable','/Raw/AX/InventTransferTable','InventTransferTable.json',1,Getdate(),Getdate(),Getdate(),Current_user),
(103,'AX_InventTransferLine','/Raw/AX/InventTransferLine','InventTransferLine.json',1,Getdate(),Getdate(),Getdate(),Current_user),
(104,'AX_BTLTransferReleaseHistoryLog','/Raw/AX/BTLTransferReleaseHistoryLog','BTLTransferReleaseHistoryLog.json',1,Getdate(),Getdate(),Getdate(),Current_user),
(105,'AX_PurchTable','/Raw/AX/PurchTable','PurchTable.json',1,Getdate(),Getdate(),Getdate(),Current_user),
(106,'AX_Purchline','/Raw/AX/Purchline','Purchline.json',1,Getdate(),Getdate(),Getdate(),Current_user),
(107,'AX_INVENTTRANS','/Raw/AX/INVENTTRANS','INVENTTRANS.json',1,Getdate(),Getdate(),Getdate(),Current_user),
(108,'AX_INVENTTRANSPOSTING','/Raw/AX/INVENTTRANSPOSTING','INVENTTRANSPOSTING.json',1,Getdate(),Getdate(),Getdate(),Current_user),
(109,'AX_REQTRANS','/Raw/AX/REQTRANS','REQTRANS.json',1,Getdate(),Getdate(),Getdate(),Current_user),
(110,'AX_RETAILCHANNELTABLE','/Raw/AX/RETAILCHANNELTABLE','RETAILCHANNELTABLE.json',1,Getdate(),Getdate(),Getdate(),Current_user),
(111,'AX_INVENTTABLE','/Raw/AX/INVENTTABLE','INVENTTABLE.json',1,Getdate(),Getdate(),Getdate(),Current_user),
(112,'AX_SMMCAMPAIGNTABLE','/Raw/AX/SMMCAMPAIGNTABLE','SMMCAMPAIGNTABLE.json',1,Getdate(),Getdate(),Getdate(),Current_user),
(113,'AX_RETAILCAMPAIGNDISCOUNT','/Raw/AX/RETAILCAMPAIGNDISCOUNT','RETAILCAMPAIGNDISCOUNT.json',1,Getdate(),Getdate(),Getdate(),Current_user),
(114,'AX_ECORESCATEGORY','/Raw/AX/ECORESCATEGORY','ECORESCATEGORY.json',1,Getdate(),Getdate(),Getdate(),Current_user),
(115,'AX_ECORESPRODUCT','/Raw/AX/ECORESPRODUCT','ECORESPRODUCT.json',1,Getdate(),Getdate(),Getdate(),Current_user),
(116,'AX_ECORESPRODUCTCATEGORY','/Raw/AX/ECORESPRODUCTCATEGORY','ECORESPRODUCTCATEGORY.json',1,Getdate(),Getdate(),Getdate(),Current_user),
(117,'AX_OMHIERARCHYRELATIONSHIP','/Raw/AX/OMHIERARCHYRELATIONSHIP','OMHIERARCHYRELATIONSHIP.json',1,Getdate(),Getdate(),Getdate(),Current_user),
(118,'AX_DIRORGANIZATIONNAME','/Raw/AX/DIRORGANIZATIONNAME','DIRORGANIZATIONNAME.json',1,Getdate(),Getdate(),Getdate(),Current_user),
(119,'AX_REQTRANSFIRMLOG','/Raw/AX/REQTRANSFIRMLOG','REQTRANSFIRMLOG.json',1,Getdate(),Getdate(),Getdate(),Current_user),
(120,'AX_UNITOFMEASURE','/Raw/AX/UNITOFMEASURE','UNITOFMEASURE.json',1,Getdate(),Getdate(),Getdate(),Current_user),
(121,'AX_UNITOFMEASURECONVERSION','/Raw/AX/UNITOFMEASURECONVERSION','UNITOFMEASURECONVERSION.json',1,Getdate(),Getdate(),Getdate(),Current_user),
(122,'AX_INVENTTABLEMODULE','/Raw/AX/INVENTTABLEMODULE','INVENTTABLEMODULE.json',1,Getdate(),Getdate(),Getdate(),Current_user),
(123,'AX_INVENTTRANSFERJOUR','/Raw/AX/INVENTTRANSFERJOUR','INVENTTRANSFERJOUR.json',1,Getdate(),Getdate(),Getdate(),Current_user),
(124,'AX_INVENTTRANSFERJOURLINE','/Raw/AX/INVENTTRANSFERJOURLINE','INVENTTRANSFERJOURLINE.json',1,Getdate(),Getdate(),Getdate(),Current_user),
(125,'AX_DIRPARTYTABLE','/Raw/AX/DIRPARTYTABLE','DIRPARTYTABLE.json',1,Getdate(),Getdate(),Getdate(),Current_user),


--K3S
(200,'K3S_AssistedOrders','/Raw/K3S/AssistedOrders','',1,Getdate(),Getdate(),Getdate(),Current_user),

--McKesson
(400,'McKesson_FILL_FACT','/Raw/McKesson/FILL_FACT','FILL_FACT.json',1,Getdate(),Getdate(),Getdate(),Current_user)


) as  s
		(   [CopyActivityDataADLSKey]
		   ,[CopyActivityDataADLSName]
           ,[CopyActivityDataADLSFolderPath]
           ,[CopyActivityDataADLSFileName]
           ,[IsActive]
           ,[LastRunDate]
           ,[CreateDate]
           ,[ModifiedDate]
           ,[ModifiedUser])
ON ( t.[CopyActivityDataADLSKey] = s.[CopyActivityDataADLSKey] )
WHEN MATCHED THEN 
	UPDATE SET   
		   [CopyActivityDataADLSName] = s.[CopyActivityDataADLSName]
           ,[CopyActivityDataADLSFolderPath] = s.[CopyActivityDataADLSFolderPath]
           ,[CopyActivityDataADLSFileName] = s.[CopyActivityDataADLSFileName]
           ,[IsActive] =s.[IsActive]
           ,[LastRunDate] = s.[LastRunDate]
           ,[CreateDate] = s.[CreateDate]
           ,[ModifiedDate] = s.[ModifiedDate]
           ,[ModifiedUser] = s.[ModifiedUser]
WHEN NOT MATCHED BY TARGET THEN
    INSERT(
			[CopyActivityDataADLSKey]
		   ,[CopyActivityDataADLSName]
           ,[CopyActivityDataADLSFolderPath]
           ,[CopyActivityDataADLSFileName]
           ,[IsActive]
           ,[LastRunDate]
           ,[CreateDate]
           ,[ModifiedDate]
           ,[ModifiedUser]
		  )	
    VALUES(
			 s.[CopyActivityDataADLSKey]
		   ,s.[CopyActivityDataADLSName]
           ,s.[CopyActivityDataADLSFolderPath]
           ,s.[CopyActivityDataADLSFileName]
           ,s.[IsActive]
           ,s.[LastRunDate]
           ,s.[CreateDate]
           ,s.[ModifiedDate]
           ,s.[ModifiedUser]
		  );
GO

SET IDENTITY_INSERT dbo.CopyActivityDataADLS OFF;